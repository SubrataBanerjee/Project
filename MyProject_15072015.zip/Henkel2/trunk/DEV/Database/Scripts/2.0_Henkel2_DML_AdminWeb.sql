BEGIN TRAN

---System Table entries-----------------

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = 'B83FC588-CFB8-49DB-8CF4-1ED15FF4A98A')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('B83FC588-CFB8-49DB-8CF4-1ED15FF4A98A', 'Home', 'Home','Home', 1, 1, 1, 1, 1, 0, 1)
END

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = '719CFF4D-EC1B-4939-9306-5CC9D358A29B')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('719CFF4D-EC1B-4939-9306-5CC9D358A29B', 'Dashboard', 'Home','Dashboard', 1, 1, 1, 1, 1, 0, 1)
END

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = '9FD24010-8CD7-4C34-83B5-315CE7D0FABA')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('9FD24010-8CD7-4C34-83B5-315CE7D0FABA', 'CONFIG', 'CONFIG', 'CONFIG', 0, 0, 0, 0, 0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = '1E2ACC6A-725A-47DB-AE61-A030F5B85E66')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('1E2ACC6A-725A-47DB-AE61-A030F5B85E66', 'Customer', 'CONFIG','Customer', 0, 0, 0, 0, 0, 1, 0)
END

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = '2D529637-3174-4C04-BF69-07854ABAB4DE')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('2D529637-3174-4C04-BF69-07854ABAB4DE', 'Security', 'CONFIG','Security', 0, 0, 0, 0, 0, 1, 0)
END

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = 'EE9C8823-9C14-4C4A-B249-37D74B325A9C')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module],[FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('EE9C8823-9C14-4C4A-B249-37D74B325A9C', 'Role', 'Security','Role', 1, 1, 1, 1, 1, 0, 1)
END

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = '836A8C0F-A754-4101-A6D4-0B2B4E13A668')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [FeatureGroup], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('836A8C0F-A754-4101-A6D4-0B2B4E13A668', 'User', 'Security','User', 1, 1, 1, 1, 1, 0, 1)
END
--Kernel table entries-----------------------

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerInfo WHERE Id = '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313')
BEGIN
INSERT INTO Cust_CustomerInfo (Id, [GroupCompanyName], [Address_Line1], [Address_Line2], [Address_Line3], [Address_City], [Address_State], [Address_CountryId], [Address_Pin], [Contact_PersonName_Prefix], [Contact_PersonName_FirstName], [Contact_PersonName_MiddleName], [Contact_PersonName_LastName], [Contact_PhoneNumber], [Contact_Email], [CreatedBy], [CreatedOn], [LastModifiedBy], [LastModifiedOn], [IsActive], [IsDeleted] ) 
VALUES ('4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'Henkel', 'Line1','Line2',NULL,'Mumbai','Maharashtra', NULL, NULL, NULL, 'Henkel', NULL, 'Admin', '8789065760', 'abc@xyz.com', 'system', GETDATE(),'system', GETDATE(), 1, 0)  
END

--******CustomerInfo Config entries****************************
IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '50244644-1890-46C9-A03C-BF37CBA836FA')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('50244644-1890-46C9-A03C-BF37CBA836FA', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313', 'CacheTimeOut', '5')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '57EE4153-3B07-4547-A258-C1B85246C16C')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('57EE4153-3B07-4547-A258-C1B85246C16C', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313', 'SmtpHost', '')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '21F7AC19-171D-403D-A82E-DAABA7C616BD')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('21F7AC19-171D-403D-A82E-DAABA7C616BD', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'SmtpPort', '')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = 'D0C69D3A-B956-4C98-9D96-91E5455FB5CF')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('D0C69D3A-B956-4C98-9D96-91E5455FB5CF', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'FromEmailId', 'abc@xyz.com')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '8487C1D8-761E-4FEC-85A1-638CF5A15913')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('8487C1D8-761E-4FEC-85A1-638CF5A15913', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'UploadPath', '')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '89610707-6906-4016-BBD5-1213D8DBC400')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('89610707-6906-4016-BBD5-1213D8DBC400', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'FailureLoginAttemptLimit', '3')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = 'F2EC6F5A-0963-4A9C-AEA9-9DD4E20E6963')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('F2EC6F5A-0963-4A9C-AEA9-9DD4E20E6963', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'DefaultUserPassword', 'password@123')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '38248526-0882-4DFA-95F3-BA83CD34B7FF')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('38248526-0882-4DFA-95F3-BA83CD34B7FF', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'PasswordPolicy', '^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W)\S{8,15}$|Should be 8-15 characters in length\n\rShould have atleast one lowercase character\n\rShould have atleast one uppercase character\n\rShould have atleast one number\n\rShould have atleast one special character\n\rShould not have spaces.')
END

IF NOT EXISTS (SELECT 1 FROM Cust_CustomerConfigDetail WHERE Id = '4CEBA4B1-F13E-4912-80D0-0ADFC4E5B1B1')
BEGIN
INSERT INTO Cust_CustomerConfigDetail (Id, CustomerInfoId, ConfigKey, ConfigValue)
VALUES ('4CEBA4B1-F13E-4912-80D0-0ADFC4E5B1B1', '4D3CCFAE-C1C2-44CA-B55A-A21C739DB313',  'PasswordHistoryLimit', 3)
END


--- Infrastructure table entries

IF NOT EXISTS (SELECT 1 FROM Infra_EmailTemplate WHERE Id = 'D9767197-DA3A-4B38-AA98-17E281658979')
BEGIN
INSERT INTO Infra_EmailTemplate (Id, [Name], [From], [To], [CC], [BCC], [Subject], Body, EmailTokenProviderName, IsActive) 
VALUES ('D9767197-DA3A-4B38-AA98-17E281658979',  'NewUser', 'abc@xyz.com', 'abc@xyz.com',null, null, 'New User %User.Username% has been created.', 'Dear %User.Username%, Your account has been created in the system. Your will shortly get the One Time password to Login into the system. Thank You for register with us.', 'UserEmailTokenProvider', 1)
END

IF NOT EXISTS (SELECT 1 FROM Infra_EmailTemplate WHERE Id = '3FDBE728-19A9-4D41-A3ED-B2DE6BCB3945')
BEGIN
INSERT INTO Infra_EmailTemplate (Id, [Name], [From], [To], [CC], [BCC], [Subject], Body, EmailTokenProviderName, IsActive) 
VALUES ('3FDBE728-19A9-4D41-A3ED-B2DE6BCB3945',  'ResetPassword', 'abc@xyz.com', 'abc@xyz.com',null, null, 'A new Password has been generated.', 'Dear %User.Username%, Your newly generated one time Password is: %User.Password%. You can now LogIn into the system using this password and after successful LogIn system will prompt you for Password Change. Thanks for Business with us.', 'UserEmailTokenProvider', 1)
END

IF NOT EXISTS (SELECT 1 FROM Infra_EmailTemplate WHERE Id = 'E92E650C-24BF-403D-83FC-519361F4D6D1')
BEGIN
INSERT INTO Infra_EmailTemplate (Id, [Name], [From], [To], [CC], [BCC], [Subject], Body, EmailTokenProviderName, IsActive) 
VALUES ('E92E650C-24BF-403D-83FC-519361F4D6D1',  'ChangePassword', 'abc@xyz.com', 'abc@xyz.com',null, null, 'Your Password Has been changed.', 'Dear %User.Username%, Your Password has been changed successfully. Thanks for business with us.', 'UserEmailTokenProvider', 1)
END


--- Security Table entries

IF NOT EXISTS (SELECT 1 FROM Sec_User WHERE Id = '4027CCFF-6B04-4D0D-B2D5-143CCDDFB3A1')
BEGIN
--Password= 'abc@1234'
INSERT INTO Sec_User (Id, [LoginId], [Password], [IsActive], [Locked], [ChangePwdOnLogin], [FailureLoginAttempt], [IsSuperAdmin], [CreatedBy], [CreatedOn],[LastModifiedBy],[LastModifiedOn],[IsDeleted]) 
VALUES ('4027CCFF-6B04-4D0D-B2D5-143CCDDFB3A1',  'admin', 'g6D+bEA71S0hqf7ZmPSMekzYfVndkt8tZ4rW16CPH48=', 1, 0, 0, 0, 1, 'system', GETDATE(),'system', GETDATE(), 0)
END

IF NOT EXISTS (SELECT 1 FROM Sec_Resource WHERE Id = 'EE9981FD-D2B5-4C64-927F-2A52C3A6F4A0')
BEGIN
INSERT INTO Sec_Resource (Id, [Code], [UserId], [Address_Line1], [Address_Line2], [Address_Line3], [Address_City], [Address_State], [Address_CountryId], [Address_Pin], [Contact_PersonName_Prefix], [Contact_PersonName_FirstName], [Contact_PersonName_MiddleName], [Contact_PersonName_LastName], [Contact_PhoneNumber], [Contact_Email], [CreatedBy], [CreatedOn], [LastModifiedBy], [LastModifiedOn], [IsActive], [IsDeleted] ) 
VALUES ('EE9981FD-D2B5-4C64-927F-2A52C3A6F4A0',  'Admin', '4027CCFF-6B04-4D0D-B2D5-143CCDDFB3A1','Line1','Line2',NULL,'Mumbai','Maharashtra', NULL, NULL, NULL, 'Subrata', NULL, 'Banerjee', '8789065760', 'abc@xyz.com', 'system', GETDATE(),'system', GETDATE(), 1, 0)  
END

IF NOT EXISTS (SELECT 1 FROM Sec_User WHERE Id = 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9')
BEGIN
--Password= 'abc@1234'
INSERT INTO Sec_User (Id, [LoginId], [Password], [IsActive], [Locked], [ChangePwdOnLogin], [FailureLoginAttempt], [IsSuperAdmin], [CreatedBy], [CreatedOn],[LastModifiedBy],[LastModifiedOn],[IsDeleted]) 
VALUES ('D3CC5041-E498-4DC9-9C4C-786A5E6689E9',  'abc', 'g6D+bEA71S0hqf7ZmPSMekzYfVndkt8tZ4rW16CPH48=', 1, 0, 0, 0, 0, 'system', GETDATE(),'system', GETDATE(), 0)
END

IF NOT EXISTS (SELECT 1 FROM Sec_Resource WHERE Id = '3B935562-DF85-4F59-8716-CF5C6970B2F9')
BEGIN
INSERT INTO Sec_Resource (Id, [Code], [UserId], [Address_Line1], [Address_Line2], [Address_Line3], [Address_City], [Address_State], [Address_CountryId], [Address_Pin], [Contact_PersonName_Prefix], [Contact_PersonName_FirstName], [Contact_PersonName_MiddleName], [Contact_PersonName_LastName], [Contact_PhoneNumber], [Contact_Email], [CreatedBy], [CreatedOn], [LastModifiedBy], [LastModifiedOn], [IsActive], [IsDeleted] ) 
VALUES ('3B935562-DF85-4F59-8716-CF5C6970B2F9',  'abc', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9','Line 111','Line 112',NULL,'Mumbai','Maharashtra', NULL, NULL, NULL, 'Amit', NULL, 'Shah', '9087890789', 'mno@pqr.com', 'system', GETDATE(),'system', GETDATE(), 1, 0)  
END


IF NOT EXISTS (SELECT 1 FROM Sec_Role WHERE Id = 'E0F36DBD-7C97-42F5-A6BD-4135A2617B81')
BEGIN
INSERT INTO Sec_Role (Id, [Name], [CreatedBy], [CreatedOn],[LastModifiedBy],[LastModifiedOn],[IsActive], [IsDeleted]) 
VALUES ('E0F36DBD-7C97-42F5-A6BD-4135A2617B81',  'admin', 'system', GETDATE(),'system', GETDATE(), 1, 0)
END

IF NOT EXISTS (SELECT 1 FROM Sec_RoleUserMap WHERE Id = '0F937243-4E57-40F8-8153-F886518015E4')
BEGIN
INSERT INTO Sec_RoleUserMap (Id, RoleId, UserId) 
VALUES ('0F937243-4E57-40F8-8153-F886518015E4',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9')
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = '7C852726-EB12-4564-A76C-DE446EC6813A')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('7C852726-EB12-4564-A76C-DE446EC6813A',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'B83FC588-CFB8-49DB-8CF4-1ED15FF4A98A', 0,0,1,0,0, 0, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = '3ABBC99C-7E29-4B80-AB40-5666F4359EDA')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('3ABBC99C-7E29-4B80-AB40-5666F4359EDA',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', '719CFF4D-EC1B-4939-9306-5CC9D358A29B', 0,0,1,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = '1DBC3407-CE20-4E5D-AAA6-2C602443206A')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('1DBC3407-CE20-4E5D-AAA6-2C602443206A',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', '9FD24010-8CD7-4C34-83B5-315CE7D0FABA', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = '812CD529-BC51-4F5A-B667-E304C354E0D7')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('812CD529-BC51-4F5A-B667-E304C354E0D7',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', '1E2ACC6A-725A-47DB-AE61-A030F5B85E66', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = '1AF6E249-8B20-4D09-9D7D-B531AFB2946D')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('1AF6E249-8B20-4D09-9D7D-B531AFB2946D',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', '2D529637-3174-4C04-BF69-07854ABAB4DE', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = 'B615E4A0-8183-4030-A5D3-60685E81C36B')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('B615E4A0-8183-4030-A5D3-60685E81C36B',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'EE9C8823-9C14-4C4A-B249-37D74B325A9C', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureMap WHERE Id = '4B76A4FC-B79A-4298-9D3E-D356EAD14B88')
BEGIN
INSERT INTO Sec_RoleFeatureMap (Id, RoleId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('4B76A4FC-B79A-4298-9D3E-D356EAD14B88',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', '836A8C0F-A754-4101-A6D4-0B2B4E13A668', 0,0,0,0,0, 1, 0)
END


----------------
IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = '054B7A7A-3487-41A7-AF86-BE44DAE30396')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('054B7A7A-3487-41A7-AF86-BE44DAE30396',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', 'B83FC588-CFB8-49DB-8CF4-1ED15FF4A98A', 0,0,1,0,0, 0, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = 'F3967EF2-A5B0-4F21-98C3-2C856E2D54FC')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('F3967EF2-A5B0-4F21-98C3-2C856E2D54FC',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', '719CFF4D-EC1B-4939-9306-5CC9D358A29B', 0,0,1,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = '9939DAF5-8572-444B-B8B8-7D67BE2E4814')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('9939DAF5-8572-444B-B8B8-7D67BE2E4814',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', '9FD24010-8CD7-4C34-83B5-315CE7D0FABA', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = '02EC95C0-0385-4632-9A90-34E67A5D0200')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('02EC95C0-0385-4632-9A90-34E67A5D0200',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', '1E2ACC6A-725A-47DB-AE61-A030F5B85E66', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = '575EF312-C93A-4C80-9AD5-E4D7AE3126A5')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('575EF312-C93A-4C80-9AD5-E4D7AE3126A5',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', '2D529637-3174-4C04-BF69-07854ABAB4DE', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = '40ECD347-FA87-4917-A8B2-6E591E9F9446')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('40ECD347-FA87-4917-A8B2-6E591E9F9446',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', 'EE9C8823-9C14-4C4A-B249-37D74B325A9C', 0,0,0,0,0, 1, 0)
END


IF NOT EXISTS (SELECT 1 FROM Sec_RoleFeatureUserMap WHERE Id = '6CB5DE48-AB44-4313-9E54-131EED808B9E')
BEGIN
INSERT INTO Sec_RoleFeatureUserMap (Id, RoleId, UserId, FeatureId, [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate]) 
VALUES ('6CB5DE48-AB44-4313-9E54-131EED808B9E',  'E0F36DBD-7C97-42F5-A6BD-4135A2617B81', 'D3CC5041-E498-4DC9-9C4C-786A5E6689E9', '836A8C0F-A754-4101-A6D4-0B2B4E13A668', 0,0,0,0,0, 1, 0)
END

--ROLLBACK TRAN
COMMIT TRAN