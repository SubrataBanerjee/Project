﻿using System;
using System.Threading;

namespace Henkel.Common.Core.API.Utils
{
    public class ThreadUtils
    {
        public static void SetThreadData(Guid? userId = null, string userName = null, string ipAddress = null, string customData = null)
        {
            if (userId.HasValue && userId.Value != Guid.Empty)
                SetDataInThreadSlot("Context_UserId", userId.Value);

            if(userName != null)
                SetDataInThreadSlot("Context_UserName", userName);
            
            if(ipAddress != null)
                SetDataInThreadSlot("Context_IPAddress", ipAddress);

            if(customData != null)
                SetDataInThreadSlot("Context_CustomData", customData);
        }

        private static void SetDataInThreadSlot(string slotName, object data)
        {
            var threadDataStoreSlot = Thread.GetNamedDataSlot(slotName);
            Thread.SetData(threadDataStoreSlot, data);
        }
    }
}
