﻿using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Resources;
using System;
using System.Configuration;

namespace Henkel.Common.Core.API.Utils
{
    public static class CoreHelper
    {
        public static double GetCacheTimeOut()
        {
            var cacheTimeOutString = ConfigurationManager.AppSettings[GlobalConstant.DEFAULT_CACHE_TIMEOUT_KEY];

            double cacheTimeOut;
            if (!string.IsNullOrWhiteSpace(cacheTimeOutString) && Double.TryParse(cacheTimeOutString, out cacheTimeOut))
                return cacheTimeOut;

            return GlobalConstant.DEFAULT_CACHE_TIMEOUT;
        }

        public static CacheType GetCacheType()
        {
            var cacheTypeString = ConfigurationManager.AppSettings[GlobalConstant.DEFAULT_CACHE_TYPE_KEY];
            CacheType cacheType;
            if (!string.IsNullOrWhiteSpace(cacheTypeString) && Enum.TryParse<CacheType>(cacheTypeString, true, out cacheType))
                return cacheType;

            return GlobalConstant.DEFAULT_CACHE_TYPE;
        }
    }
}
