﻿using Henkel.Common.Core.API.Model;
using System.Collections.Specialized;

namespace Henkel.Common.Core.API.Events.Model
{
    public interface IPreEventHandler<in T> where T : IEntity
    {
        void Handle(string eventType, T obj, NameValueCollection formCollection = null);
    }
}
