﻿
namespace Henkel.Common.Core.API.Events.Model
{
    public interface IEventHandler<out T> where T : BaseEvent
    {
        void Handle(object @event);
    }
}
