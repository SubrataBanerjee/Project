﻿
namespace Henkel.Common.Core.API.Events.Model
{
    public interface IEvent
    {
    }
}
