﻿using Henkel.Common.Core.API.Events.Model;
using Henkel.Common.Core.API.Services;

namespace Henkel.Common.Core.API.Events.Services
{
    public interface IEventDispatcherService : IBusinessService
    {
        void DispatchEvent(BaseEvent evt);
    }
}
