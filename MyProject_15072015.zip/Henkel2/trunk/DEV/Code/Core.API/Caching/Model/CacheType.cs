﻿
namespace Henkel.Common.Core.API.Caching.Model
{
    public enum CacheType
    {
        Local,
        Distributed
    }
}
