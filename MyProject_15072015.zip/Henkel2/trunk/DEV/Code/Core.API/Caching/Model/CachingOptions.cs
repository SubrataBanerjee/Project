﻿using System.Runtime.Caching;

namespace Henkel.Common.Core.API.Caching.Model
{
    public class CachingOptions
    {
        public CacheType CacheType { get; set; }
        public CacheItemPolicy CachePolicy { get; set; }
    }
}
