﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Henkel.Common.Core.API.DTO.ComplexType
{
    [ComplexType]
    public class Contact
    {
        #region Fields

        public virtual PersonName PersonName { get; set; }
        public virtual string PhoneNumber { get; set; }
        public virtual string Email { get; set; }

        #endregion

        #region Constructors

        public Contact()
        {
            PersonName = new PersonName();
        }

        #endregion

        #region Methods

        public virtual bool Equals(Contact other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return Equals(other.PersonName, PersonName) && (other.PhoneNumber == PhoneNumber) && Equals(other.Email, Email);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != typeof(Contact)) return false;
            return Equals((Contact)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int result = (PersonName != null ? PersonName.GetHashCode() : 0);
                //result = (result * 397) ^ (Address != null ? Address.GetHashCode() : 0);
                result = (result * 397) ^ (PhoneNumber != null ? PhoneNumber.GetHashCode() : 0);
                result = (result * 397) ^ (Email != null ? Email.GetHashCode() : 0);
                return result;
            }
        }

        #endregion
    }
}
