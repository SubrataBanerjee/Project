﻿using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Henkel.Common.Core.API.DTO.ComplexType
{
    [ComplexType]
    public class Address
    {
        public virtual string Line1 { get; set; }
        public virtual string Line2 { get; set; }
        public virtual string Line3 { get; set; }
        public virtual string City { get; set; }
        public virtual string State { get; set; }
        //public virtual Guid? CountryId { get; set; }
        public virtual string CountryId { get; set; }
        public virtual string Pin { get; set; }

        public virtual bool Equals(Address other)
        {
            if (ReferenceEquals(null, other)) return false;
            if (ReferenceEquals(this, other)) return true;
            return Equals(other.Line1, Line1) && Equals(other.Line2, Line2) && Equals(other.Line3, Line3)
                && Equals(other.City, City) && Equals(other.State, State) && Equals(other.CountryId, CountryId) && Equals(other.Pin, Pin);
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj as Address == null) return false;
            return Equals((Address)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int result = 0;
                var line1Code = Line1 == null ? 0 : Line1.GetHashCode();
                var line2Code = Line2 == null ? 0 : Line2.GetHashCode();
                var line3Code = Line3 == null ? 0 : Line3.GetHashCode();
                var cityCode = City == null ? 0 : City.GetHashCode();
                var stateCode = State == null ? 0 : State.GetHashCode();
                var countryCode = CountryId == null ? 0 : CountryId.GetHashCode();
                var postalCode = Pin == null ? 0 : Pin.GetHashCode();
                result = (result * 397) ^ (line1Code ^ line2Code ^ line3Code ^ cityCode
                    ^ stateCode ^ countryCode ^ postalCode);
                return result;
            }
        }

        public override string ToString()
        {
            var fullAddress = new StringBuilder();

            if (!string.IsNullOrEmpty(Line1))
                fullAddress.AppendFormat("{0}, ", Line1);
            if (!string.IsNullOrEmpty(Line2))
                fullAddress.AppendFormat("{0}, ", Line2);
            if (!string.IsNullOrEmpty(Line3))
                fullAddress.AppendFormat("{0}, ", Line3);

            fullAddress.AppendFormat(Environment.NewLine);

            if (!string.IsNullOrEmpty(City))
                fullAddress.AppendFormat("{0}, ", City);

            if (!string.IsNullOrEmpty(State))
                fullAddress.AppendFormat("{0}, ", State);

            if (!string.IsNullOrEmpty(CountryId))
                fullAddress.AppendFormat("{0}, ", CountryId);

            if (!string.IsNullOrEmpty(Pin))
                fullAddress.AppendFormat("{0}, ", Pin);

            return fullAddress.Length > 3 ? fullAddress.ToString().Substring(0, fullAddress.Length - 3) : fullAddress.ToString();
        }
    }

}
