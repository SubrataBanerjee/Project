﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace Henkel.Common.Core.API.DTO.ComplexType
{
    [ComplexType]
    public class PersonName
    {
        public virtual string Prefix { get; set; }
        public virtual string FirstName { get; set; }
        public virtual string MiddleName { get; set; }
        public virtual string LastName { get; set; }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != typeof(PersonName)) return false;
            return Equals((PersonName)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                int result = (Prefix != null ? Prefix.GetHashCode() : 0);
                result = (result * 397) ^ (FirstName != null ? FirstName.GetHashCode() : 0);
                result = (result * 397) ^ (MiddleName != null ? MiddleName.GetHashCode() : 0);
                result = (result * 397) ^ (LastName != null ? LastName.GetHashCode() : 0);
                return result;
            }
        }

        public override string ToString()
        {
            var fullName = new StringBuilder();
            if (!string.IsNullOrEmpty(Prefix))
                fullName.AppendFormat("{0} ", Prefix);

            if (!string.IsNullOrEmpty(FirstName))
                fullName.AppendFormat("{0} ", FirstName);

            if (!string.IsNullOrEmpty(MiddleName))
                fullName.AppendFormat("{0} ", MiddleName);

            if (!string.IsNullOrEmpty(LastName))
                fullName.AppendFormat("{0} ", LastName);

            var fullNameStr = fullName.ToString();
            if(fullNameStr.Length > 0)
                return fullNameStr.Substring(0, fullName.Length - 1);
            return fullNameStr;
        }
    }
}
