﻿
namespace Henkel.Common.Core.API.DTO.SearchCriteria
{
    public interface ISearchCriteria
    {
    }
}
