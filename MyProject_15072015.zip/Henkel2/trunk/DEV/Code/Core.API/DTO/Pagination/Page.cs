﻿using System.Collections.Generic;

namespace Henkel.Common.Core.API.DTO.Pagination
{
    public class Page<T> where T : class
    {
        #region Fields

        public int TotalRecord { get; private set; }

        public IList<T> Data { get; private set; }

        #endregion

        #region Constructors

        public Page(int totalRecord, IList<T> data)
        {
            TotalRecord = totalRecord;
            Data = data;
        }

        #endregion

    }
}
