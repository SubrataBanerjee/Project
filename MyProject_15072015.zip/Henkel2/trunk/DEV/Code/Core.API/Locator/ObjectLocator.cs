﻿using Henkel.Common.Core.API.Integration.Services;
using Henkel.Common.Core.API.Services;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;

namespace Henkel.Common.Core.API.Locator
{
    public class ObjectLocator
    {
        #region private fields

        private static IObjectResolver _objectResolver;

        #endregion

        #region Constructors

        static ObjectLocator()
        {
            SetObjectResolver(ObjectResolverType.Unity);
        }

        #endregion

        public static void SetObjectResolver(ObjectResolverType objectResolverType)
        {
            var objectResolverFactoryType = Type.GetType("Henkel.Common.Core.Locator.Services.Impl.ObjectResolverFactory, Henkel.Common.Core");
            if (objectResolverFactoryType != null)
            {
                var objectResolverFactory = Activator.CreateInstance(objectResolverFactoryType) as IObjectResolverFactory;
                if (objectResolverFactory != null)
                {
                    _objectResolver = objectResolverFactory.CreateInstance(objectResolverType);
                }
            }
        }

        public static void RegisterObject<T>(T service, string name = null) where T : class
        {
            _objectResolver.RegisterObject<T>(service, name);
        }

        public static void RegisterUnityTypes<T>(IEnumerable<T> unityServices) where T : class, IRegisterWithUnityService
        {
            _objectResolver.RegisterUnityTypes<T>(unityServices);
        }

        public static void ClearAllObjects()
        {
            _objectResolver.ClearAllObjects();
        }

        public static void ClearObject<T>()
        {
            _objectResolver.ClearObject<T>();
        }

        public static T GetService<T>() where T : class, IBusinessService
        {
            return _objectResolver.GetService<T>();
        }

        public static T GetService<T>(string name) where T : class, IBusinessService
        {
            return _objectResolver.GetService<T>(name);
        }

        public static T TryGetService<T>() where T : class, IBusinessService
        {
            try
            {
                return _objectResolver.GetService<T>();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static T TryGetService<T>(string name) where T : class, IBusinessService
        {
            try
            {
                return _objectResolver.GetService<T>(name);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets all the objects that implements the specified Type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static IEnumerable<T> GetAllService<T>() where T : class, IBusinessService
        {
            return _objectResolver.GetAll<T>();
        }


        public static T GetObject<T>() where T : class
        {
            return _objectResolver.GetType<T>();
        }

        public static T GetObject<T>(string name) where T : class
        {
            return _objectResolver.GetType<T>(name);
        }

        public static T TryGetObject<T>() where T : class
        {
            try
            {
                return _objectResolver.GetType<T>();
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static T TryGetObject<T>(string name) where T : class
        {
            try
            {
                return _objectResolver.GetType<T>(name);
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Gets all the objects that implements the specified Type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public static IEnumerable<T> GetAllObject<T>() where T : class
        {
            return _objectResolver.GetAll<T>();
        }

        public static IUnityContainer UnityContainer
        {
            get 
            {
                return _objectResolver.UnityContainer;
            }
        }
    }
}
