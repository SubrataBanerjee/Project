﻿
namespace Henkel.Common.Core.API.Locator
{
    public enum ObjectResolverType
    {
        InMemory,
        Composite,
        Unity
    }
}
