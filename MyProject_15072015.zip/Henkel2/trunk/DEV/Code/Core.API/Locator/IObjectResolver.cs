﻿using Henkel.Common.Core.API.Integration.Services;
using Henkel.Common.Core.API.Services;
using Microsoft.Practices.Unity;
using System.Collections.Generic;

namespace Henkel.Common.Core.API.Locator
{
    public interface IObjectResolver
    {
        void RegisterObject<T>(T service, string name);

        void RegisterUnityTypes<T>(IEnumerable<T> unityServices) where T : class, IRegisterWithUnityService;

        void ClearAllObjects();

        void ClearObject<T>();

        T GetService<T>() where T : class, IBusinessService;

        T GetService<T>(string name) where T : class, IBusinessService;

        T GetType<T>() where T : class;

        T GetType<T>(string name) where T : class;

        IEnumerable<T> GetAll<T>();

        IUnityContainer UnityContainer { get; }
    }
}
