﻿
namespace Henkel.Common.Core.API.Locator
{
    public interface IObjectResolverFactory
    {
        IObjectResolver CreateInstance(ObjectResolverType resolverType);
    }
}
