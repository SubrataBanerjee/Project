﻿using System;
using System.Diagnostics;

namespace Henkel.Common.Core.API.Logging.Model
{
    [DebuggerDisplay("Status: {Status}")]
    public class OperationStatus
    {
        public bool Status { get; set; }
        public int RecordsAffected { get; set; }
        public Object OperationId { get; set; }
        public string ExceptionMessage { get; set; }
        public string ExceptionStackTrace { get; set; }
        public string Message { get; set; }
        public OperationStatus InnerOperationStatus { get; set; }

        public static OperationStatus CreateFromException(string message, Exception ex)
        {
            var opStatus = new OperationStatus
            {
                Status = false,
                OperationId = null,
                Message = message
            };

            if (ex != null)
            {
                opStatus.ExceptionMessage = ex.Message;
                opStatus.ExceptionStackTrace = ex.StackTrace;
                if (ex.InnerException != null)
                    opStatus.InnerOperationStatus = CreateFromException(message, ex.InnerException);
            }
            return opStatus;
        }
    }
}
