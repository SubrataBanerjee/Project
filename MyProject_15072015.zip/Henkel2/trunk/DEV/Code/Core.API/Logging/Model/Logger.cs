﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Services;
using System;

namespace Henkel.Common.Core.API.Logging.Model
{
    /// <summary>
    /// Logger class providing logging utility functions
    /// </summary>
    public static class Logger
    {
        private static readonly ILoggingService _loggingService;

        static Logger()
        {
            try
            {
                _loggingService = ObjectLocator.GetService<ILoggingService>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Logs Critical messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="messageParameters">The message parameters.</param>
        public static void Critical(string module, string message, params object[] messageParameters)
        {
            _loggingService.Critical(module, message, messageParameters);
        }

        /// <summary>
        /// Logs Errors for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="messageParameters">The message parameters.</param>
        public static void Error(string module, string message, params object[] messageParameters)
        {
            _loggingService.Error(module, message, messageParameters);
        }

        /// <summary>
        /// Logs Warnings for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="messageParameters">The message parameters.</param>
        public static void Warning(string module, string message, params object[] messageParameters)
        {
            _loggingService.Warning(module, message, messageParameters);
        }

        /// <summary>
        /// Logs Informational messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="messageParameters">The message parameters.</param>
        public static void Info(string module, string message, params object[] messageParameters)
        {
            _loggingService.Info(module, message, messageParameters);
        }

        /// <summary>
        /// Logs Verbose messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="messageParameters">The message parameters.</param>
        public static void Verbose(string module, string message, params object[] messageParameters)
        {
            _loggingService.Verbose(module, message, messageParameters);
        }

        /// <summary>
        /// Logs Exceptions for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="stackTrace">The stack trace.</param>
        /// <param name="messageParameters">The message parameters.</param>
        public static void Exception(string module, string message, string stackTrace, params object[] messageParameters)
        {
            _loggingService.Exception(module, message, stackTrace, messageParameters);
        }

        /// <summary>
        /// Logs Exceptions for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="operationStatus">The operation status.</param>
        public static void Exception(string module, OperationStatus operationStatus)
        {
            _loggingService.Exception(module, operationStatus);
        }

    }
}
