﻿using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Services;

namespace Henkel.Common.Core.API.Logging.Services
{
    /// <summary>
    /// Logging Service providing framework for logging messages at verious Logging levels
    /// </summary>
    public interface ILoggingService : IBusinessService
    {
        /// <summary>
        /// Logs Critical messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        void Critical(string module, string message, params object[] args);

        /// <summary>
        /// Logs Errors for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        void Error(string module, string message, params object[] args);

        /// <summary>
        /// Logs Warnings for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        void Warning(string module, string message, params object[] args);

        /// <summary>
        /// Logs Informational messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        void Info(string module, string message, params object[] args);
        /// <summary>
        /// Logs Verbose messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        void Verbose(string module, string message, params object[] args);
        /// <summary>
        /// Logs Exceptions for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="stackTrace">The stack trace.</param>
        /// <param name="args">The args.</param>
        void Exception(string module, string message, string stackTrace, params object[] args);

        /// <summary>
        ///  Logs Exceptions for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="operationStatus">The operation status.</param>
        void Exception(string module, OperationStatus operationStatus);
    }
}
