﻿using Henkel.Common.Core.API.Caching.Model;

namespace Henkel.Common.Core.API.Resources
{
    public static class GlobalConstant
    {
        public const double DEFAULT_CACHE_TIMEOUT = 60;
        public const CacheType DEFAULT_CACHE_TYPE = CacheType.Local;

        public const string CUSTOMERINFO_CACHE_KEY = "CustomerInfoCacheKey";
        public const string CUSTOMER_CONFIG_DETAIL_CACHE_KEY = "CustomerConfigDetailCacheKey";
        public const string SYS_FEATURE_CACHE_KEY = "SysFeatureCacheKey";
        public const string EMAILTEMPLATE_CACHE_KEY = "EmailTemplateCacheKey";
        public const string DEFAULT_CACHE_TYPE_KEY = "DefaultCacheType";
        public const string DEFAULT_CACHE_TIMEOUT_KEY = "DefaultCacheTimeOut";
    }
}
