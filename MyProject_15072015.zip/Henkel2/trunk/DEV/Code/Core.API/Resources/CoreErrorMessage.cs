﻿
namespace Henkel.Common.Core.API.Resources
{
    public class CoreErrorMessage
    {
        public const string KeyErrorProcessingRequest = "Key_ErrorProcessingRequest"; // "Internal Error occurred to Process Request."
        public const string ExceptionOccurred = "Exception occourred !!!";
        public const string KeyCustomerNotRegisteredIntoSystem = "Key_CustomerNotRegisteredIntoSystem"; //"Customer not registered into the System."
        public const string KeyCustomerNotFoundForUpdate = "Key_CustomerNotFoundForUpdate"; //No Customer found for Update operation.
    }
}
