﻿
namespace Henkel.Common.Core.API.Resources
{
    public static class CoreAdminConfigKey
    {
        public const string UploadPath = "UploadPath";
        public const string StorageContainerDirectory = "StorageContainerDirectory";
        public const string StorageContainerDirectoryCredential = "StorageContainerDirectoryCredential";
        public const string CacheTimeOut = "CacheTimeOut";
    }
}
