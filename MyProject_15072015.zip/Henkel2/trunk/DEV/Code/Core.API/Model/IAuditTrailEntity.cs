﻿
namespace Henkel.Common.Core.API.Model
{
    public enum AuditAction
    {
        Insert,
        Modify,
        Delete
    }

    public interface IAuditTrailEntity
    {
        void CreateAuditTrail(AuditAction auditAction);
    }
}
