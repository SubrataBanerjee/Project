﻿using System;

namespace Henkel.Common.Core.API.Model
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}
