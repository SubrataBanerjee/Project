﻿
namespace Henkel.Common.Core.API.Model
{
    public interface ISupportSoftDelete
    {
        bool IsDeleted { get; set; }

        void MarkAsDelete();
    }
}
