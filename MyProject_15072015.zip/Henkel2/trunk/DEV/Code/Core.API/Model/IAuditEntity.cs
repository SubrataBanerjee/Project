﻿using System;

namespace Henkel.Common.Core.API.Model
{
    public interface IAuditEntity
    {
        string CreatedBy { get; set; }

        DateTime? CreatedOn { get; set; }

        string LastModifiedBy { get; set; }

        DateTime? LastModifiedOn { get; set; }

        void SetCreationInfo();

        void SetModificationInfo();
    }
}
