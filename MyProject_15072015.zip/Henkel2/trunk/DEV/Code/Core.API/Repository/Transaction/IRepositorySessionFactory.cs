﻿using System.Data;

namespace Henkel.Common.Core.API.Repository.Transaction
{
    public interface IRepositorySessionFactory
    {
        IRepositorySession GetNewSession(bool isReadWrite, IsolationLevel isolationLevel = IsolationLevel.ReadCommitted);
        bool RepositorySessionExists();
        void Unbind();
    }
}
