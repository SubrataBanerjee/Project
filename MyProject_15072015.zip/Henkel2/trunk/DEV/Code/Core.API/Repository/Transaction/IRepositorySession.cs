﻿using System;

namespace Henkel.Common.Core.API.Repository.Transaction
{
    public interface IRepositorySession : IDisposable
    {
        void Rollback();

        void Flush();
    }
}
