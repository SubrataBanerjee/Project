﻿using Henkel.Common.Core.API.Model;

namespace Henkel.Common.Core.API.Repository
{
    public interface IRepository<T> where T : class, IEntity
    {
    }
}
