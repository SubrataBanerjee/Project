﻿using System.IO;

namespace Henkel.Common.Core.API.Services
{
    public interface IFileService : IBusinessService
    {
        /// <summary>
        /// Saves the file.
        /// </summary>
        /// <param name="fileStream">The file stream.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="path">The path.</param>
        /// <param name="contentType">Type of the content.</param>
        /// <returns>File Full path with name</returns>
        string SaveFile(Stream fileStream, string fileName, string path, string contentType);


        /// <summary>
        /// Deletes the file.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        void DeleteFile(string pathWithFileName);


        /// <summary>
        /// Renames the file.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        /// <param name="newFileName">New name of the file.</param>
        void RenameFile(string pathWithFileName, string newFileName);


        /// <summary>
        /// Gets the file.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        /// <returns></returns>
        Stream GetFile(string pathWithFileName);


        /// <summary>
        /// Gets the file.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        /// <returns></returns>
        string GetFilePath(string pathWithFileName);


        /// <summary>
        /// Verify if file Exist.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        /// <returns></returns>
        bool FileExists(string pathWithFileName);


        /// <summary>
        /// Move the file.
        /// </summary>
        /// <param name="fileToMove">File to Move in some other place</param>
        /// <param name="existingPath">Existing Path of the file</param>
        /// <param name="newPath">New Path of the file</param>
        void MoveFile(string fileToMove, string existingPath, string newPath);
    }
}
