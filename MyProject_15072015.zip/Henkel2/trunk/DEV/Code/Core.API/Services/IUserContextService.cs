﻿using System;
using System.Net;

namespace Henkel.Common.Core.API.Services
{
    public interface IUserContextService : IBusinessService
    {
        /// <summary>
        /// Gets the current user id.
        /// </summary>
        Guid CurrentUserId { get; }

        /// <summary>
        /// Gets the name of the current user.
        /// </summary>
        /// <value>
        /// The name of the current user.
        /// </value>
        string CurrentUserName { get; }

        /// <summary>
        /// Gets the IP address.
        /// </summary>
        IPAddress IPAddress { get; }

        /// <summary>
        /// Gets the current time.
        /// </summary>
        DateTime CurrentTime { get; }

        /// <summary>
        /// Gets the custom data.
        /// </summary>
        string CustomData { get; }
    }
}
