﻿
namespace Henkel.Common.Core.API.Services
{
    public interface IBusinessService
    {
    }
}
