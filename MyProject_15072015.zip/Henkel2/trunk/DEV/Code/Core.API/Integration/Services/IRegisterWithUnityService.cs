﻿using Microsoft.Practices.Unity;

namespace Henkel.Common.Core.API.Integration.Services
{
    public interface IRegisterWithUnityService
    {
        void RegisterTypes(IUnityContainer container);
    }
}
