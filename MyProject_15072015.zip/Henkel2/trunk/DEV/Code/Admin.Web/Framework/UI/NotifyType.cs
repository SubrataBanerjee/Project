﻿
namespace Henkel.Admin.Web.Framework.UI
{
    public enum NotifyType
    {
        Success,
        Error
    }
}
