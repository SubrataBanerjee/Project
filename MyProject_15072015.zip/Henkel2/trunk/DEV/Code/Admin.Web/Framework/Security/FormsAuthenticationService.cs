﻿using Henkel.Admin.Web.Utils;
using Henkel.Business.Kernel.Security.API.DTO;
using System;
using System.Web;
using System.Web.Security;

namespace Henkel.Admin.Web.Framework.Security
{
    public class FormsAuthenticationService
    {
        private readonly HttpContextBase _httpContext;
        private readonly TimeSpan _expirationTimeSpan;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="httpContext">HTTP context</param>
        public FormsAuthenticationService(HttpContextBase httpContext)
        {
            this._httpContext = httpContext;
            this._expirationTimeSpan = FormsAuthentication.Timeout;
        }

        public FormsAuthenticationService()
        {
            // TODO: Complete member initialization
        }


        public virtual void SignIn(UserToken userToken, bool createPersistentCookie)
        {
            var now = DateTime.UtcNow.ToLocalTime();

            var ticket = new FormsAuthenticationTicket(
                1 /*version*/,
                userToken.UserLoginId,
                now,
                now.Add(_expirationTimeSpan),
                createPersistentCookie,
                userToken.UserLoginId,
                FormsAuthentication.FormsCookiePath);

            var encryptedTicket = FormsAuthentication.Encrypt(ticket);

            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);

            cookie.HttpOnly = true;
            if (ticket.IsPersistent)
            {
                cookie.Expires = ticket.Expiration;
            }
            cookie.Secure = FormsAuthentication.RequireSSL;
            cookie.Path = FormsAuthentication.FormsCookiePath;
            if (FormsAuthentication.CookieDomain != null)
            {
                cookie.Domain = FormsAuthentication.CookieDomain;
            }

            _httpContext.Response.Cookies.Add(cookie);
            SetAppContextData(userToken);
        }

        public virtual void SignOut()
        {
            //_cachedUser = null;
            FormsAuthentication.SignOut();
            _httpContext.Session.Abandon();

            // clear authentication cookie
            var cookie1 = new HttpCookie(FormsAuthentication.FormsCookieName, "") { Expires = DateTime.Now.AddYears(-1) };
            _httpContext.Response.Cookies.Add(cookie1);

            // clear session cookie (not necessary for your current problem but i would recommend you do it anyway)
            var cookie2 = new HttpCookie("ASP.NET_SessionId", "") { Expires = DateTime.Now.AddYears(-1) };
            _httpContext.Response.Cookies.Add(cookie2);

            FormsAuthentication.RedirectToLoginPage();
        }


        private void SetAppContextData(UserToken userToken)
        {
            AppContext.Current.UserId = userToken.UserId;
            AppContext.Current.UserLoginId = userToken.UserLoginId;
            AppContext.Current.UserFullName = userToken.UserFullName;
            AppContext.Current.CustomerFullName = userToken.CustomerFullName;
            AppContext.Current.GroupCompanyName = userToken.GroupCompanyName;
            AppContext.Current.UserToken = userToken;
            
            AppContext.SetThreadData();
        }
    }
}
