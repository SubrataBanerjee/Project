﻿
namespace Henkel.Admin.Web.Framework.Model
{
    //public class ErrorDisplay
    //{
    //    public string StatusCode { get; set; }
    //    public string Message { get; set; }
    //}
}
