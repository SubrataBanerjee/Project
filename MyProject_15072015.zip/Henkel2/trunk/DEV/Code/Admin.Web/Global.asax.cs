﻿using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Locator;
using Henkel.Admin.Web;
using Henkel.Admin.Web.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Henkel.Common.Core.API.Utils;
using System.Web.SessionState;
using System.Text;
using Henkel.Admin.Web.Framework.Model;
using Henkel.Admin.Web.Framework.Utility;
using FluentValidation.Mvc;
using Henkel.Admin.Web.Controllers;
using Henkel.Admin.Web.App_Start;

namespace Henkel.Admin.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801
    public class MvcApplication : HttpApplication
    {
        #region Events

        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            WebApiConfig.Register(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            RegisterWebApiFilters(GlobalConfiguration.Configuration.Filters);

            DependencyResolver.SetResolver(new UnityDependencyResolver(ObjectLocator.UnityContainer));
            ModelBinders.Binders.Add(typeof(PageInfo), new PageInfoModelBinder());
            RegisterGlobalFilters(GlobalFilters.Filters);

            ViewEngines.Engines.Clear();
            ViewEngines.Engines.Add(new RazorViewEngine());
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            SessionEndModule.SessionObjectKey = "CustomerId";
            SessionEndModule.SessionEnd += new SessionEndEventHandler(SessionTimeoutModule_SessionEnd);

            //model binders
            ModelBinders.Binders.Add(typeof(BaseModel), new ModelBinder());

            //fluent validation
            DataAnnotationsModelValidatorProvider.AddImplicitRequiredAttributeForValueTypes = false;
            FluentValidationModelValidatorProvider.Configure();
        }


        protected void Application_AcquireRequestState(object sender, EventArgs e)
        {
            SetContextData();
        }


        protected void Application_PostAuthorizeRequest()
        {
            if (IsWebApiRequest())
            {
                HttpContext.Current.SetSessionStateBehavior(SessionStateBehavior.Required);
            }
        }


        protected void Application_EndRequest(Object sender, EventArgs e)
        {
            if (Context.Items["AjaxPermissionDenied"] is bool)
            {
                Context.Response.StatusCode = 401;
                Context.Response.End();
            }
        }

        protected void Application_Error(object sender, EventArgs e)
        {
            var exception = Server.GetLastError();
            var routeValues = HttpContext.Current.Request.RequestContext.RouteData.Values;
            var controllerName = string.Empty;
            if (routeValues.ContainsKey("controller"))
                controllerName = (string)routeValues["controller"];

            var actionName = string.Empty;
            if (routeValues.ContainsKey("action"))
                actionName = (string)routeValues["action"];

            // Log the exception.
            Response.Clear();

            var httpException = exception as HttpException;

            var routeData = new RouteData();
            routeData.Values.Add("controller", "Error");

            if (httpException == null)
            {
                routeData.Values.Add("action", "Index");
            }
            else //It's an Http Exception, Let's handle it.
            {
                switch (httpException.GetHttpCode())
                {
                    case 404:
                        // Page not found.
                        routeData.Values.Add("action", "HttpError404");
                        break;
                    case 505:
                        // Server error.
                        routeData.Values.Add("action", "HttpError505");
                        break;

                    // Here you can handle Views to other error codes.
                    // I choose a General error template  
                    default:
                        routeData.Values.Add("action", "Index");
                        break;
                }
            }

            // Pass exception details to the target error View.
            routeData.Values.Add("exception", exception);
            routeData.Values.Add("controllerName", controllerName);
            routeData.Values.Add("actionName", actionName);

            // Clear the error on server.
            Server.ClearError();

            // Call target Controller and pass the routeData.
            IController errorController = new ErrorController();
            errorController.Execute(new RequestContext(
                 new HttpContextWrapper(Context), routeData));
        }

        public override string GetVaryByCustomString(HttpContext context, string custom)
        {
            var parameters = custom.Split(';');
            var returnValue = new StringBuilder();
            foreach (var parameter in parameters)
            {
                var cookie = context.Request.Cookies[parameter];
                if (cookie != null)
                {
                    if (returnValue.Length == 0)
                        returnValue.Append(cookie.Value);
                    else
                        returnValue.AppendFormat(";{0}", cookie.Value);
                }
            }
            if (returnValue.Length > 0)
            {
                return returnValue.ToString();
            }
            return base.GetVaryByCustomString(context, custom);
        }


        private static void SessionTimeoutModule_SessionEnd(object sender, SessionEndedEventArgs e)
        {
            if (e.SessionObject != null && e.SessionObject.ToString().IsGuid())
            {
                //var custId = (Guid)e.SessionObject;
                //ThreadUtils.SetThreadData(custId);
            }
            ClearSession(e.SessionId);
        }

        #endregion

        #region Helper Methods

        private static void RegisterWebApiFilters(System.Web.Http.Filters.HttpFilterCollection filters)
        {
            filters.Add(new ContextDataFilter());
        }

        private static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }


        private static void ClearSession(string sessionId)
        {
            //Perform Session clear releated work here
            if (HttpContextFactory.Current.Session != null)
                HttpContextFactory.Current.Session.Abandon();
        }

        private static bool IsWebApiRequest()
        {
            return HttpContext.Current.Request.AppRelativeCurrentExecutionFilePath.ToLower().StartsWith("~/api");
        }

        private void SetContextData()
        {
            if (HttpContextFactory.Current.Session == null)
                return;

            var currentContext = AppContext.Current;


            ThreadUtils.SetThreadData(currentContext.UserId, currentContext.UserLoginId, GetClientIPAddress());
        }

        public static string GetClientIPAddress()
        {
            var context = HttpContextFactory.Current;
            string ipAddress = context.Request.ServerVariables["HTTP_X_FORWARDED_FOR"];
            if (string.IsNullOrEmpty(ipAddress))
                return context.Request.ServerVariables["REMOTE_ADDR"];

            string[] ipArray = ipAddress.Split(new[] { ',' });
            return ipArray[0];
        }

        #endregion

    }
}