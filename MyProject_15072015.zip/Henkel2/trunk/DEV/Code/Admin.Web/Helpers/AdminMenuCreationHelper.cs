﻿using Henkel.Admin.Web.Utils;
using Henkel.Admin.Web.Utils.MenusXsd;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Common.Core.API.Locator;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Web.Mvc;
using System.Linq;
using System.Web;

namespace Henkel.Admin.Web.Helpers
{
    public static class AdminMenuCreationHelper
    {
        public static MvcHtmlString GenerateAdminMenu(this HtmlHelper helper,string tabName)
        {
            var sb = new StringBuilder();
            string itemId = string.Empty;

            var appDataPath = String.Empty;
            switch (tabName)
            {
                case "Customer":
                    appDataPath = helper.ViewContext.HttpContext.Server.MapPath("~/App_Data/CustomerMenus.xml");
                    break;
                case "Secutiry":
                    appDataPath = helper.ViewContext.HttpContext.Server.MapPath("~/App_Data/SecurityMenus.xml");
                    break;
            }

            var root = XRoot.Load(appDataPath);

            foreach (var menu1 in root.Menu.MenuLevel1)
            {
                if (HasRight(menu1.id, menu1.group, menu1.module, menu1.actions))
                {
                    sb.Append(RenderLevel1Menus(tabName, itemId, menu1));
                }
            }

            return new MvcHtmlString(sb.ToString());
        }

        private static string RenderLevel1Menus(string tabName, string itemId, Menu.MenuLevel1LocalType menu1)
        {
            StringBuilder sb = new StringBuilder();
            var text = GetStringFromResource(menu1.text);
            var level2MenuString = "";
            level2MenuString = RenderLevel2Menu(tabName, itemId, menu1);

            if (!String.IsNullOrEmpty(level2MenuString))
            {
                sb.AppendLine(@"<section class=""portlet"">");
                sb.AppendFormat(@"<header class=""pgSecHdr""><h3>{0}</h3></Header>", text);
                sb.AppendLine(@"<div class=""content"">");
                sb.AppendLine(@"<ul>");
                sb.Append(level2MenuString);

                sb.AppendLine(@"</ul></div></section><div class=""spacer""></div>");
            }
            return sb.ToString();
        }

        private static string RenderLevel2Menu(string tabName, string itemId, Menu.MenuLevel1LocalType menu1)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var menu2 in menu1.MenuLevel2)
            {
                if (HasRight(menu2.id, menu2.group, menu2.module, menu2.actions))
                {
                    var text = GetStringFromResource(menu2.text);
                    var url = menu2.url;
                    if (string.IsNullOrWhiteSpace(url))
                        sb.AppendFormat(@"<li class ='adminli'><a href=""#"">{1}</a></li>", string.Empty, text);
                    else
                        sb.AppendFormat(@"<li class ='adminli' url=""{0}""><a href=""#"" onclick=navigateTo(""{1}"",'');>{2}</a></li>", VirtualPathUtility.ToAbsolute(url), VirtualPathUtility.ToAbsolute(url), text);
                }
            }
            return sb.ToString();
        }

        public static bool HasRight(string feature, string group, string module, string actions)
        {
            return MenuCreationHelper.HasRight(feature, group, module, actions);
        }

        private static string GetStringFromResource(string text)
        {
            return MenuCreationHelper.GetStringFromResource(text) ?? text;
        }
    }
}