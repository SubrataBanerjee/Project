﻿using System;
using System.Web.Mvc;

namespace Henkel.Admin.Web.Helpers
{
    public static class ThemeLoadHelper
    {
        public static MvcHtmlString LoadTheme(this HtmlHelper helper)
        {
            var csslink = String.Format("<link href='{0}' rel='stylesheet' type='text/css' />", "~/Content/main.css");
            return new MvcHtmlString(csslink);
        }
    }
}