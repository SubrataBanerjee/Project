﻿using Henkel.Admin.Web.Utils;
using Henkel.Admin.Web.Utils.MenusXsd;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;

namespace Henkel.Admin.Web.Helpers
{
    /// <summary>
    /// Menu creation Helper
    /// </summary>
    public static class MenuCreationHelper
    {

        const string divStart = "<div id='GlobalNav'><ul>";
        const string divEnd = "</ul></div>";
        const string liStart = "<li><a href='#'>";
        const string liEnd = "</a></li>";

        const string divSubStart = "<div id='SubNav'><ul>";
        const string divSubEnd = "</ul></div>";
        const string liSubStart = "<li><a href='#'>";
        const string liSubEnd = "</a></li>";


        /// <summary>
        /// Generate menu based on XML file and user access rights
        /// </summary>
        /// <param name="helper"></param>
        /// <returns></returns>
        public static MvcHtmlString GenerateMenuFromXml(this HtmlHelper helper)
        {
            var sb = new StringBuilder();
            var sbChild = new StringBuilder();

            sb.Append(divStart);
            var appDataPath = helper.ViewContext.HttpContext.Server.MapPath("~/App_Data/Menus.xml");
            var root = XRoot.Load(appDataPath);

            string currentMenu = FindCurrentMenuFromURL(root, VirtualPathUtility.ToAppRelative(helper.ViewContext.HttpContext.Request.Url.AbsolutePath));
            var level1Menus = GetLevel1Menus(root);

            foreach (var menu1 in level1Menus)
            {
                if (HasRight(menu1.id, menu1.group, menu1.module, menu1.actions))
                {
                    RenderLevel1Menu(helper, sb, menu1, sbChild, currentMenu);
                }
            }

            sb.Append(divEnd);
            sb.Append(sbChild);
            
            return new MvcHtmlString(sb.ToString());
        }

        private static List<Menu.MenuLevel1LocalType> GetLevel1Menus(XRoot root)
        {
            var level1Menus = new List<Menu.MenuLevel1LocalType>();
            var level1MenusClone = new List<Menu.MenuLevel1LocalType>();
            level1Menus.AddRange(root.Menu.MenuLevel1);
            level1MenusClone.AddRange(level1Menus);
            if (level1Menus.Count > root.Menu.MenuLevel1.Count)
            {
                Dictionary<string, int> level1MenuDict = new Dictionary<string, int>();
                foreach (var kvp in level1Menus.Select((x, idx) => new { idx, x.id }))
                {
                    level1MenuDict.Add(kvp.id, kvp.idx);
                }

                foreach (var menu1 in level1Menus)
                {
                    if (!string.IsNullOrWhiteSpace(menu1.before) && level1MenuDict[menu1.before] > 0)
                    {
                        level1MenusClone.Remove(menu1);
                        level1MenusClone.Insert(level1MenuDict[menu1.before], menu1);
                        //clear the dictionary and populate again
                        level1MenuDict.Clear();
                        foreach (var kvp in level1MenusClone.Select((x, idx) => new { idx, x.id }))
                        {
                            level1MenuDict.Add(kvp.id, kvp.idx);
                        }
                    }
                }
            }

            return level1MenusClone;
        }

        private static void RenderLevel1Menu(HtmlHelper helper, StringBuilder sb, Menu.MenuLevel1LocalType menu1, StringBuilder sbChild, string currentMenu)
        {
            if (!string.IsNullOrWhiteSpace(menu1.text))
            {
                var childMenu = string.Empty;
                foreach (var menu2 in menu1.MenuLevel2)
                {
                    var level2Menu = RenderLevel2Menu(helper, menu2);
                    childMenu = string.Format("{0}{1}", childMenu, level2Menu);
                }
                if (childMenu.Length > 0 || menu1.id == "Home")
                {
                    if (!string.IsNullOrWhiteSpace(menu1.url))
                    {
                        var newLi = liStart.Replace("#", VirtualPathUtility.ToAbsolute(menu1.url));

                        if (currentMenu == menu1.id)
                        {
                            newLi = newLi.Replace("<li>", "<li class='current'>");
                            //Sub Menu Generation
                            sbChild.Append(divSubStart);
                            sbChild.Append(childMenu);
                            sbChild.Append(divSubEnd);
                        }

                        sb.Append(newLi);
                    }
                    else
                    {
                        sb.Append(liStart);
                    }
                    sb.Append(GetStringFromResource(menu1.text));
                    sb.Append(liEnd);
                }
            }
        }

        private static string RenderLevel2Menu(HtmlHelper helper, Menu.MenuLevel1LocalType.MenuLevel2LocalType menu2)
        {
            var childMenu = string.Empty;
            if (!string.IsNullOrWhiteSpace(menu2.text))
            {
                var hasSubAccess = HasRight(menu2.id, menu2.group, menu2.module, menu2.actions);
                if (hasSubAccess)
                {
                    var newLiSubStart = liSubStart;
                    if (!string.IsNullOrWhiteSpace(menu2.url))
                    {
                        if (helper.ViewContext.HttpContext.Request.Url.AbsolutePath.Contains
                            (menu2.url.Replace("..", "").Replace("~", "")))
                        {
                            newLiSubStart = newLiSubStart.Replace("<li>",
                                                                  "<li class='currentSub'><span class='iconBS-selMenu'></span>");
                        }
                        childMenu = string.Format("{0}{1}", childMenu, newLiSubStart.Replace("#", VirtualPathUtility.ToAbsolute((menu2.url))));
                    }
                    else
                    {
                        childMenu = string.Format("{0}{1}", childMenu,  newLiSubStart);
                    }

                    childMenu = string.Format("{0}{1}", childMenu, GetStringFromResource(menu2.text));
                    childMenu = string.Format("{0}{1}", childMenu, liSubEnd);
                }
            }
            return childMenu;
        }

        

        


        public static string FindCurrentMenuFromURL(XRoot root, string path)
        {
            if (path.StartsWith("/"))
                path = path.Substring(1);
            else if (path.StartsWith("~/"))
                path = path.Substring(2);
            var currentMenu = "";
            foreach (var menu1 in root.Menu.MenuLevel1)
            {
                if (menu1.MenuLevel2.Any(menu2 => menu2.url != "" && path.Contains(menu2.url.Replace("..", "").Replace("~", ""))))
                {
                    currentMenu = menu1.id;
                    break;
                }
            }

            if (currentMenu == "")
            {
                foreach (var menu1 in root.Menu.MenuLevel1)
                {
                    if (!string.IsNullOrWhiteSpace(menu1.url))
                    {
                        if (path.Contains(menu1.url.Replace("..", "").Replace("~", "")))
                        {
                            currentMenu = menu1.id;
                            break;
                        }
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(currentMenu))
            {
                foreach (var menu1 in root.Menu.MenuLevel1)
                {
                    if ((from menu2 in menu1.MenuLevel2 where !string.IsNullOrWhiteSpace(menu2.url) select menu2.url.Replace("..", "").Replace("~", "") into url where !string.IsNullOrWhiteSpace(url) select url.Substring(url.IndexOf("/") + 1) into url select url.Substring(0, url.IndexOf("/"))).Any(path.StartsWith))
                    {
                        currentMenu = menu1.id;
                        break;
                    }
                }

                if (string.IsNullOrWhiteSpace(currentMenu))
                {
                    foreach (var menu1 in root.Menu.MenuLevel1)
                    {
                        if (!string.IsNullOrWhiteSpace(menu1.url))
                        {
                            var url = menu1.url.Replace("..", "").Replace("~", "");

                            if (!string.IsNullOrWhiteSpace(url))
                            {
                                url = url.Substring(url.IndexOf("/") + 1);
                                url = url.Substring(0, url.IndexOf("/"));
                                if (path.StartsWith(url))
                                {
                                    currentMenu = menu1.id;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            return currentMenu;
        }

        /// <summary>
        /// Find current menu based on current url
        /// </summary>
        /// <param name="doc"></param>
        /// <param name="path"></param>
        /// <returns></returns>
        public static string FindCurrentMenuFromURL(XmlDocument doc, string path)
        {
            var currentMenu = "";
            XmlNodeList listChild = doc.GetElementsByTagName("MenuLevel2");
            XmlNodeList listParent = doc.GetElementsByTagName("MenuLevel1");
            foreach (XmlNode node in listChild)
            {
                var urlNode = node.SelectSingleNode("url");
                if (urlNode != null)
                {
                    if (urlNode.InnerText != "" && path.Contains(urlNode.InnerText.Replace("..", "").Replace("~", "")))
                    {
                        currentMenu = node.ParentNode.Attributes["id"].Value;
                        break;
                    }
                }
            }

            if (currentMenu == "")
            {
                foreach (XmlNode node in listParent)
                {
                    var urlNode = node.SelectSingleNode("url");
                    if (urlNode != null)
                    {
                        if (urlNode.InnerText != "" &&
                            path.Contains(urlNode.InnerText.Replace("..", "").Replace("~", "")))
                        {
                            currentMenu = node.Attributes["id"].Value;
                            break;
                        }
                    }
                }
            }

            if (string.IsNullOrWhiteSpace(currentMenu))
            {
                foreach (XmlNode node in listChild)
                {
                    var urlNode = node.SelectSingleNode("url");
                    if (urlNode != null)
                    {
                        var urlInnerText = urlNode.InnerText.Replace("..", "").Replace("~", "");

                        if (!string.IsNullOrWhiteSpace(urlInnerText))
                        {
                            urlInnerText = urlInnerText.Substring(urlInnerText.IndexOf("/") + 1);
                            urlInnerText = urlInnerText.Substring(0, urlInnerText.IndexOf("/"));
                            if (path.Contains(urlInnerText))
                            {
                                currentMenu = node.ParentNode.Attributes["id"].Value;
                                break;
                            }
                        }
                    }
                }

                if (string.IsNullOrWhiteSpace(currentMenu))
                {
                    foreach (XmlNode node in listParent)
                    {
                        var urlNode = node.SelectSingleNode("url");
                        if (urlNode != null)
                        {
                            var urlInnerText = urlNode.InnerText.Replace("..", "").Replace("~", "");

                            if (!string.IsNullOrWhiteSpace(urlInnerText))
                            {
                                urlInnerText = urlInnerText.Substring(urlInnerText.IndexOf("/") + 1);
                                urlInnerText = urlInnerText.Substring(0, urlInnerText.IndexOf("/"));
                                if (path.Contains(urlInnerText))
                                {
                                    currentMenu = node.Attributes["id"].Value;
                                    break;
                                }
                            }
                        }
                    }
                }
            }

            return currentMenu;
        }

        public static string GetStringFromResource(string text)
        {
            return Menus.ResourceManager.GetString(text) ?? text;
        }

        private static UserAction[] GetUserActions(string actions)
        {
            if (string.IsNullOrWhiteSpace(actions))
                return null;

            var actionsArr = actions.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            var userActions = new List<UserAction>();
            foreach (var actionStr in actionsArr)
            {
                var userAction = (UserAction)Enum.Parse(typeof(UserAction), actionStr, true);
                userActions.Add(userAction);
            }

            return userActions.ToArray();
        }

        /// <summary>
        /// Check whether user has rights for particular feature
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="feature"></param>
        /// <param name="action2"></param>
        /// <param name="actions"></param>
        /// <returns></returns>
        public static bool HasRight(string feature, string group, string module, string actions)
        {
            var userRights = AppContext.Current.UserToken == null ? null : AppContext.Current.UserToken.UserRights;
            if (userRights != null)
            {
                if (string.IsNullOrWhiteSpace(actions))
                    return true;

                var paramUserActions = GetUserActions(actions);

                var authrizationService = ObjectLocator.GetService<IAuthorizationService>();
                return authrizationService.HasRight(userRights, feature, group, module, paramUserActions);
            }
            return false;
        }
    }
}