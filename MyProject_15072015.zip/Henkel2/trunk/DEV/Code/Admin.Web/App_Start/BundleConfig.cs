﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Optimization;

namespace Henkel.Admin.Web.App_Start
{
    public class BundleConfig
    {
        #region Fields

        private static IDictionary<string, HashSet<string>> _languageScriptsCache = new ConcurrentDictionary<string, HashSet<string>>();

        #endregion

        #region Public Methods

        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.IgnoreList.Clear();
            AddDefaultIgnorePatterns(bundles.IgnoreList);

            LoadCSS(bundles);
            LoadJSScripts(bundles);
            LoadJQueryScripts(bundles);
            LoadJqueryUIScripts(bundles);
            LoadLanguageScripts(bundles);
            BundleTable.EnableOptimizations = true;
        }
        
        #endregion

        #region Helper Methods

        private static void AddDefaultIgnorePatterns(IgnoreList ignoreList)
        {
            if (ignoreList == null)
                throw new ArgumentNullException("ignoreList");
            ignoreList.Ignore("*.intellisense.js");
            ignoreList.Ignore("*-vsdoc.js");
            ignoreList.Ignore("*.debug.js", OptimizationMode.WhenEnabled);
            //ignoreList.Ignore("*.min.js", OptimizationMode.WhenDisabled);
            ignoreList.Ignore("*.min.css", OptimizationMode.WhenDisabled);
        }

        private static void LoadCSS(BundleCollection bundles)
        {
            bundles.Add(new StyleBundle("~/Content/css")
                .Include("~/Content/jquery-ui-1.7.1.custom.css")
                .Include("~/Content/main.css"));
        }

        private static void LoadJSScripts(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/js")
                .Include("~/Scripts/html5.js")
                .Include("~/Scripts/modernizr-2*")
                .Include("~/Scripts/jquery.jqlog-1.3.min.js")
                .Include("~/Scripts/json2.js")
                .Include("~/Scripts/spin.min.js")
                .Include("~/Scripts/jquery.spin.min.js")
                //Jqgrid
                .Include("~/Scripts/jquery.jqgrid.min.js")
                .Include("~/Scripts/jquery.tmpl.js")
                .Include("~/Scripts/jquery.jqGrid.fluid.js")
                ////treeview
                .Include("~/Scripts/jquery-treeview-1.4.0.min.js")
                .Include("~/Scripts/jquery-treeview-async-0.1.0.js")
                .Include("~/Scripts/jquery.jtruncate.js")
                .Include("~/Scripts/henkel.common.js")
                .Include("~/Scripts/jquery.searchfilter.js")
                .Include("~/Scripts/jquery.layout.js")
                .Include("~/Scripts/jquery.masterlookup.js")
                .Include("~/Scripts/jquery.constrain.js")
                .Include("~/Scripts/global/populateDropDown.js")
                .Include("~/Scripts/global/portletviews.js")
                );
        }

        private static void LoadJQueryScripts(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/jquery")
                .Include("~/Scripts/jquery-{version}.js")
                //.Include("~/Scripts/jquery-1.7.2.js") //Todo Remove Subrata
                .Include("~/Scripts/jquery.validate.js")
                .Include("~/Scripts/moment.js"));
        }

        private static void LoadJqueryUIScripts(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/Scripts/jqueryui")
                .Include("~/Scripts/jquery-ui-{version}.js")
                //.Include("~/Scripts/jquery-ui-1.8.19.js") //TODO Remove Subrata
                .Include("~/Scripts/jquery.ui.date*"));
        }

        private static void LoadLanguageScripts(BundleCollection bundles)
        {
            string currentCulture = Thread.CurrentThread.CurrentUICulture.Name;
            HashSet<string> scriptInCache = null;
            if (!_languageScriptsCache.TryGetValue(currentCulture, out scriptInCache))
            {
                const string defaultScriptPath = "~/Scripts/language/default";
                var defaultFileNames = GetFilesFromWebFolder(defaultScriptPath);

                string baseScriptPath = "~/Scripts/language/" + currentCulture;
                var currentCultureFileNames = GetFilesFromWebFolder(baseScriptPath);

                var scriptFiles = new HashSet<string>();
                foreach (var currentCultureFileName in currentCultureFileNames)
                {
                    scriptFiles.Add(baseScriptPath + "/" + currentCultureFileName);
                }

                foreach (var defaultFileName in defaultFileNames)
                {
                    if (!IsFileInList(defaultFileName, currentCultureFileNames))
                        scriptFiles.Add(defaultScriptPath + "/" + defaultFileName);
                }
                if (!_languageScriptsCache.TryGetValue(currentCulture, out scriptInCache))
                    _languageScriptsCache.Add(currentCulture, scriptFiles);
            }
            var list = _languageScriptsCache[currentCulture].ToList();
            var copy = list;
            var datepickerFile = GetDatePickerFile();
            if (!string.IsNullOrEmpty(datepickerFile))
            {
                copy = list.Where(x => x.IndexOf("jquery.ui.datepicker-") < 0).Select(x => x).ToList();
                copy.Add(datepickerFile);
            }
            var scriptBundle = new ScriptBundle("~/Scripts/langjs");
            foreach (var file in copy)
            {
                scriptBundle.Include(file);
            }
            bundles.Add(scriptBundle);
        }

        private static bool IsFileInList(string fileName, IEnumerable<string> fileNames)
        {
            var baseFileName = fileName.Substring(0, fileName.LastIndexOf('-'));
            var isInList = false;
            foreach (var file in fileNames)
            {
                var baseCurrentUIFile = file.Substring(0, file.LastIndexOf('-'));
                if (baseFileName == baseCurrentUIFile)
                    isInList = true;
            }
            return isInList;
        }

        private static List<string> GetFilesFromWebFolder(string scriptPath)
        {
            string fullDefaultScriptPath = HttpContext.Current.Server.MapPath(scriptPath);
            if (!Directory.Exists(fullDefaultScriptPath))
            {
                const string defaultScriptPath = "~/Scripts/language/default";
                fullDefaultScriptPath = HttpContext.Current.Server.MapPath(defaultScriptPath);
            }
            var defaultDirectory = new DirectoryInfo(fullDefaultScriptPath);
            var defaultFileNames = defaultDirectory.GetFiles().Select(x => x.Name).ToList();
            return defaultFileNames;
        }

        private static string GetDatePickerFile()
        {
            string cultureForFormat = Thread.CurrentThread.CurrentCulture.Name;
            var basePathForDatePicker = "~/Scripts/language/" + cultureForFormat;
            var datePickerFileNames = GetFilesFromWebFolder(basePathForDatePicker);
            foreach (var datepickerFile in datePickerFileNames.Where(x => x.IndexOf("jquery.ui.datepicker-") > -1))
            {
                return basePathForDatePicker + "/" + datepickerFile;
            }
            return "";
        }

        #endregion
    }
}