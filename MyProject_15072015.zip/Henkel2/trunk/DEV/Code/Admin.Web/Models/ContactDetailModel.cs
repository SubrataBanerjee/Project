﻿using Henkel.Common.Core.API.DTO.ComplexType;

namespace Henkel.Admin.Web.Models
{
    public class ContactDetailModel
    {
        #region Fields

        public string Prefix { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }

        public string PhoneNumber { get; set; }
        public string Email { get; set; }

        #endregion

        #region Constructors

        public ContactDetailModel()
        {

        }

        public ContactDetailModel(Contact contact)
        {
            if(contact != null)
            {
                PhoneNumber = contact.PhoneNumber;
                Email = contact.Email;
                if(contact.PersonName != null)
                {
                    Prefix = contact.PersonName.Prefix;
                    FirstName = contact.PersonName.FirstName;
                    MiddleName = contact.PersonName.MiddleName;
                    LastName = contact.PersonName.LastName;
                }
            }
        }

        #endregion

        #region Methods

        public Contact GetContact()
        {
            return new Contact
            {
                Email = Email,
                PhoneNumber = PhoneNumber,
                PersonName = new PersonName
                {
                    Prefix = Prefix,
                    FirstName = FirstName,
                    MiddleName = MiddleName,
                    LastName = LastName
                }
            };
        }

        #endregion
    }
}