﻿using FluentValidation.Attributes;
using Henkel.Admin.Web.Framework.Model;
using Henkel.Admin.Web.Validators.Account;
using System.ComponentModel.DataAnnotations;

namespace Henkel.Admin.Web.Models.Account
{
    [Validator(typeof(ChangePasswordValidator))]
    public partial class ChangePasswordModel : BaseModel
    {
        public string OldPassword { get; set; }

        public string NewPassword { get; set; }

        public string ConfirmNewPassword { get; set; }
    }
}
