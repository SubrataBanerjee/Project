﻿using FluentValidation.Attributes;
using Henkel.Admin.Web.Framework.Model;
using Henkel.Admin.Web.Validators.Account;
using System.ComponentModel.DataAnnotations;

namespace Henkel.Admin.Web.Models.Account
{
    [Validator(typeof(LogonValidator))]
    public partial class LogonModel : BaseModel
    {
        public string UserName { get; set; }

        public string Password { get; set; }

        public bool RememberMe { get; set; }
    }
}