﻿using Henkel.Common.Core.API.DTO.ComplexType;

namespace Henkel.Admin.Web.Models
{
    public class AddressDetailModel
    {
        #region Fields

        public string Line1 { get; set; }
        public string Line2 { get; set; }
        public string Line3 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Country { get; set; }
        public string Pin { get; set; }

        #endregion

        #region Constructors

        public AddressDetailModel()
        {

        }

        public AddressDetailModel(Address address)
        {
            if(address != null)
            {
                Line1 = address.Line1;
                Line2 = address.Line2;
                Line3 = address.Line3;
                City = address.City;
                State = address.State;
                Country = address.CountryId;
                Pin = address.Pin;
            }
        }

        #endregion

        #region Methods

        public virtual Address GetAddress()
        {
            return new Address
            {
                Line1 = Line1,
                Line2 = Line2,
                Line3 = Line3,
                City = City,
                State = State,
                CountryId = Country,
                Pin = Pin,
            };
        }

        #endregion
    }
}