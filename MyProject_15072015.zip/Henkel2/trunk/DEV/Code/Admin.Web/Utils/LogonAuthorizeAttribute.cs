﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Henkel.Admin.Web.Utils
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = false, Inherited = true)]
    public sealed class AllowAnonymous2Attribute : Attribute { }

    public sealed class LogonAuthorizeAttribute : AuthorizeAttribute
    {
        /// <summary>
        /// Processes HTTP requests that fail authorization.
        /// </summary>
        /// <param name="filterContext">Encapsulates the information for using <see cref="T:System.Web.Mvc.AuthorizeAttribute"/>. The <paramref name="filterContext"/> object contains the controller, HTTP context, request context, action result, and route data.</param>
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext.HttpContext.Request.IsAjaxRequest())
                filterContext.HttpContext.Items["AjaxPermissionDenied"] = true;

            base.HandleUnauthorizedRequest(filterContext);
        }


        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (httpContext.Session != null && string.IsNullOrEmpty(AppContext.Current.UserLoginId))
            {
                return false;
            }
            return base.AuthorizeCore(httpContext);
        }


        public override void OnAuthorization(AuthorizationContext filterContext)
        {
            bool skipAuthorization = filterContext.ActionDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true)
                                     || filterContext.ActionDescriptor.ControllerDescriptor.IsDefined(typeof(AllowAnonymousAttribute), true);

            if (!skipAuthorization)
                skipAuthorization = filterContext.ActionDescriptor.IsDefined(typeof(AllowAnonymous2Attribute), true);
            
            if (!skipAuthorization)
            {
                if (AuthorizeCore(filterContext.HttpContext))
                {
                    // Since we're performing authorization at the action level, 
                    // the authorization code runs after the output caching module. 
                    // In the worst case this could allow an authorized user
                    // to cause the page to be cached, then an unauthorized user would 
                    // later be served the cached page. We work around this by telling 
                    // proxies not to cache the sensitive page, then we hook our custom
                    // authorization code into the caching mechanism so that we have
                    // the final say on whether a page should be served from the cache.

                    HttpCachePolicyBase cachePolicy = filterContext.HttpContext.Response.Cache;
                    cachePolicy.SetProxyMaxAge(new TimeSpan(0));
                    cachePolicy.AddValidationCallback(CacheValidateHandler, null /* data */);
                }
                else
                {
                    HandleUnauthorizedRequest(filterContext);
                }
            }
        }


        private static void CacheValidateHandler(HttpContext context, object data, ref HttpValidationStatus validationStatus)
        {
            validationStatus = DoCacheAuthorization(new HttpContextWrapper(context));
        }


        // This method must be thread-safe since it is called by the caching module.
        private static HttpValidationStatus DoCacheAuthorization(HttpContextBase httpContext)
        {
            if (httpContext == null)
            {
                throw new ArgumentNullException("httpContext");
            }
            bool isAuthorized = httpContext.User.Identity.IsAuthenticated;
            return (isAuthorized)
                       ? HttpValidationStatus.Valid
                       : HttpValidationStatus.IgnoreThisRequest;
        }
    }
}