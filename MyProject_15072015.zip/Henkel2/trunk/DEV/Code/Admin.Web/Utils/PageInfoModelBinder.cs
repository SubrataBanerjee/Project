﻿using Henkel.Common.Core.API.DTO.Pagination;
using System.Globalization;
using System.Web.Mvc;

namespace Henkel.Admin.Web.Utils
{
    public class PageInfoModelBinder : IModelBinder
    {
        public object BindModel(ControllerContext controllerContext, ModelBindingContext bindingContext)
        {
            var sidx = bindingContext.ValueProvider.GetValue("sidx");
            var sord = bindingContext.ValueProvider.GetValue("sord");
            var page = bindingContext.ValueProvider.GetValue("page");
            var rows = bindingContext.ValueProvider.GetValue("rows");
            int pageSize = 0, pageIndex = 0;
            bool sortOrderAsc = false;
            string fieldName = "";
            if (page != null)
                int.TryParse(page.AttemptedValue, out pageIndex);
            if (rows != null)
                int.TryParse(rows.AttemptedValue, out pageSize);
            var startRow = (pageIndex - 1) * pageSize;
            if (sord != null)
                sortOrderAsc = sord.AttemptedValue.ToLower(CultureInfo.CurrentCulture) == "asc";

            if (sidx != null)
                fieldName = sidx.AttemptedValue;
            var pageInfo = new PageInfo(startRow, pageSize, fieldName, sortOrderAsc);
            return pageInfo;
        }

    }
}