﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Common.Core.API.Utils;
using System;
using System.Web;

namespace Henkel.Admin.Web.Utils
{
    public class AppContext
    {
        private const string UserIdKey = "UserId";
        private const string UserLoginIdKey = "UserLoginId";
        private const string UserFullNameKey = "UserFullName";
        private const string CustomerFullNameKey = "CustomerFullName";
        private const string GroupCompanyNameKey = "GroupCompanyName";
        private const string UserTokenKey = "UserToken";

        private static readonly AppContext _instance = new AppContext();

        public static AppContext Current
        {
            get { return _instance; }
        }

        public Guid UserId
        {
            get { return (Guid)(CurrentSession[UserIdKey] ?? Guid.Empty); }
            set { CurrentSession[UserIdKey] = value; }
        }

        public string UserLoginId
        {
            get { return (string)CurrentSession[UserLoginIdKey]; }
            set { CurrentSession[UserLoginIdKey] = value; }
        }

        public string UserFullName
        {
            get { return (string)CurrentSession[UserFullNameKey]; }
            set { CurrentSession[UserFullNameKey] = value; }
        }

        public string CustomerFullName
        {
            get { return (string)CurrentSession[CustomerFullNameKey]; }
            set { CurrentSession[CustomerFullNameKey] = value; }
        }

        public string GroupCompanyName
        {
            get { return (string)CurrentSession[GroupCompanyNameKey]; }
            set { CurrentSession[GroupCompanyNameKey] = value; }
        }

        public UserToken UserToken
        {
            get { return CurrentSession[UserTokenKey] as UserToken; }
            set { CurrentSession[UserTokenKey] = value; }
        }

        private static HttpSessionStateBase CurrentSession
        {
            get { return HttpContextFactory.Current.Session; }
        }

        public static void SetThreadData()
        {
            var currentContext = Current;
            ThreadUtils.SetThreadData(currentContext.UserId, currentContext.UserLoginId);
        }
    }
}