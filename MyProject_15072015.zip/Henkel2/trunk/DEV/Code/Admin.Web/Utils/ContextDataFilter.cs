﻿using Henkel.Common.Core.API.Utils;
using System.Web;
using System.Web.Http.Controllers;

namespace Henkel.Admin.Web.Utils
{
    public class ContextDataFilter : System.Web.Http.Filters.ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            // pre-processing
            if (HttpContext.Current.Session != null)
            {
                SetContextData();
            }
        }

        private void SetContextData()
        {
            if (HttpContextFactory.Current.Session == null)
                return;

            var currentContext = AppContext.Current;
            ThreadUtils.SetThreadData(currentContext.UserId, currentContext.UserLoginId);
        }
    }
}