﻿using Henkel.Admin.Web.Models;
using Henkel.Admin.Web.Validators;
using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Common.Core.API.DTO.ComplexType;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Henkel.Admin.Web.Areas.Admin.Models.Customer
{
    public class CustomerInfoModel
    {
        #region Fields

        public string CustomerId { get; set; }
        [XSSCheck]
        public string GroupCompanyName { get; set; }
        public AddressDetailModel Address { get; set; }
        public ContactDetailModel Contact { get; set; }

        #endregion

        #region Constructors

        public CustomerInfoModel()
        {
            Address = new AddressDetailModel();
        }

        #endregion

        #region Methods

        public virtual CustomerInfoDto GetDto()
        {
            var customerInfoDto = new CustomerInfoDto
            {
                GroupCompanyName = GroupCompanyName
            };
            if (Address != null)
            {
                customerInfoDto.Address = Address.GetAddress();
            }

            if (Contact != null)
            {
                customerInfoDto.Contact = Contact.GetContact();
            }
            return customerInfoDto;
        }
        #endregion
    }
}