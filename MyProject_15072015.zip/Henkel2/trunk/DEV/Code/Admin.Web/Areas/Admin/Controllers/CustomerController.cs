﻿using Henkel.Admin.Web.Areas.Admin.Models.Customer;
using Henkel.Admin.Web.Controllers;
using Henkel.Admin.Web.Models;
using Henkel.Admin.Web.Utils;
using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Exceptions;
using System;
using System.Web.Mvc;

namespace Henkel.Admin.Web.Areas.Admin.Controllers
{
    public class CustomerController : BaseController
    {
        #region Fields
        
        private ICustomerManagementService _customerManagementService
        {
            get
            {
                return ObjectLocator.GetService<ICustomerManagementService>();
            }
        }

        #endregion

        #region Queries

        public ActionResult Index()
        {
            return View();
        }

        public virtual PartialViewResult ModifyCustomerGeneralInfo()
        {
            try
            {
                var customerInfoDto = _customerManagementService.GetCustomerInfo();

                var model = new CustomerInfoModel
                {
                    CustomerId = customerInfoDto.Id.ToString(),
                    GroupCompanyName = customerInfoDto.GroupCompanyName,
                    Address = new AddressDetailModel(customerInfoDto.Address)
                };

                return PartialView("_ModifyCustomerGeneralInfo", model);
            }
            catch(ValidationException)
            {
                throw;
            }
            catch(Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw;
            }
        }

        public virtual PartialViewResult ModifyCustomerContactDetail()
        {
            try
            {
                var customerInfoDto = _customerManagementService.GetCustomerInfo();
                var model = new CustomerInfoModel
                {
                    Contact = new ContactDetailModel(customerInfoDto.Contact)
                };

                return PartialView("_ModifyCustomerContactDetail", model);
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw;
            }
        }

        public virtual PartialViewResult ModifyCoBrandingDetail()
        {
            return PartialView("_ModifyCoBrandingDetail");
        }

        #endregion

        #region Commands
        
        [HttpPost]
        public virtual JsonResult UpdateCustomerGeneralInfo(CustomerInfoModel customerInfoModel)
        {
            try
            {
                var customerInfoDto = customerInfoModel.GetDto();
                _customerManagementService.UpdateCustomerGeneralInfo(customerInfoDto);

                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch(ValidationException ex)
            {
                return Json(new { success = false, message = GetErrorResource(ex.Message, ex.Args) }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                return Json(new { success = false, message = GetErrorResource(CoreErrorMessage.KeyErrorProcessingRequest) }, JsonRequestBehavior.AllowGet);
            }
        }


        [HttpPost]
        public virtual JsonResult UpdateCustomerContactDetail(CustomerInfoModel customerInfoModel)
        {
            try
            {
                var customerInfoDto = customerInfoModel.GetDto();
                _customerManagementService.UpdateCustomerContactDetail(customerInfoDto);

                return Json(new { success = true }, JsonRequestBehavior.AllowGet);
            }
            catch (ValidationException ex)
            {
                return Json(new { success = false, message = GetErrorResource(ex.Message, ex.Args)  }, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                return Json(new { success = false, message = GetErrorResource(CoreErrorMessage.KeyErrorProcessingRequest) }, JsonRequestBehavior.AllowGet);
            }
        }
        
        #endregion
    }
}
