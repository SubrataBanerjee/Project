﻿
(function ($) {
    $.fn.layout = function (options) {
        if (this.length == 0)
            return this;

        if (this.length > 1) {
            this.each(function () {
                $(this).layout(options);
            });
            return this;
        }

        // If a layout manager is already associated return the layout manaager
        var layoutmanager = $.data(this[0], 'layoutmanager');
        if (layoutmanager) {
            return layoutmanager;
        }

        layoutmanager = new $.layoutmanager(options, this[0]);
        $.data(this[0], 'layoutmanager', layoutmanager);

        return layoutmanager;
    };

    // Constructor for layoutmanager
    $.layoutmanager = function (options, element) {
        this.settings = $.extend(true, {}, $.layoutmanager.defaults, options);
        this.portlets = [];
        this.containingDiv = element;

        this.init();
    };

    $.extend($.layoutmanager, {
        defaults: {
            addWrapperDiv: true,
            wrapperDivClass: 'accordian',
            visiblePortlet: ''
        },
        setDefaults: function (settings) {
            $.extend($.layoutmanager.defaults, settings);
        },
        prototype: {
            init: function () {
                this.wrapperDiv = this.containingDiv;
                if (this.settings.addWrapperDiv == true) {
                    var portletDiv = $("<div></div>").addClass(this.settings.wrapperDivClass);
                    portletDiv.appendTo(this.containingDiv);

                    this.wrapperDiv = portletDiv;
                }

                // Create as many portlets as the panes
                if (this.settings.portlets && this.settings.portlets.length && this.settings.portlets.length > 0) {
                    var layoutmanager = this;
                    $.each(this.settings.portlets, function (index, value) {
                        layoutmanager.addPortlet(value);
                    });
                }

                if (this.settings.visiblePortlet != '')
                    this.show(this.settings.visiblePortlet);
            },
            portlet: function (name) {
                var i;
                for (i = 0; i < this.portlets.length; i++) {
                    if (this.portlets[i].settings.name == name)
                        return this.portlets[i];
                }
                return null;
            },
            addPortlet: function (portletOptions) {
                if (this.portlet(portletOptions.name) != null)
                    $.error('Portlet ' + portletOptions.name + '  already defined.');

                this.portlets.push(new $.portlet(this, portletOptions));
            },
            removePortlet: function (name) {
                var indexOfPortlet = -1;
                var i;
                for (i = 0; i < this.portlets.length; i++) {
                    if (this.portlets[i].settings.name == name)
                        indexOfPortlet = i;
                }

                if (indexOfPortlet != -1) {
                    var portlet = this.portlets[indexOfPortlet];
                    this.portlets.splice(indexOfPortlet, 1);     // Remove from portlet
                    portlet.remove();
                }
                else {
                    // Error. Portlet of specified name does not existing
                    $.error('Portlet ' + name + '  not defined.');
                }
            },
            show: function (name) {
                var portletToShow = this.portlet(name);

                if (portletToShow != null) {
                    var i;
                    // Hide all unpinned portlets 
                    for (i = 0; i < this.portlets.length; i++) {
                        if (this.portlets[i].isPinned == false && portletToShow.settings.name != this.portlets[i].settings.name)
                            this.portlets[i].minimize(true);
                    }

                    portletToShow.minimize(false);
                }
            },
            refreshAllPortlet: function () {
                var i;
                for (i = 0; i < this.portlets.length; i++) {
                    this.portlets[i].refresh();
                }
            }
        }
    });

    // Constructor for portlet
    $.portlet = function (layoutManager, options) {
        this.layoutManager = layoutManager;
        this.settings = $.extend({}, $.portlet.defaults, options);
        this.isPinned = false;
        this.commands = [];
        this.commandsContainer = null;
        this.init();
    };

    $.extend($.portlet, {
        defaults: {
            title: "Unknown",
            showSectionHeader: true,
            allowPin: true,
            pinned: false,
            addContentWrapperDiv: true,

            portletClass: 'portlet',
            headerClass: 'pgSecHdr',
            contentWrapperClass: 'content',

            container: 'Sidebar',
            contentLoader: 'ajaxContentLoader',

            httpMethod: 'GET'
        },
        prototype: {
            init: function () {
                // Create Section
                this.portletSection = $('<section> </section>');
                this.portletSection.addClass(this.settings.portletClass);

                // Add Title to Section
                if (this.settings.showSectionHeader) {
                    var header = $('<header> </header>').addClass(this.settings.headerClass).appendTo(this.portletSection);
                    $('<h3>' + this.settings.title + '</h3>').appendTo(header);
                    this.commandsContainer = $("<ul></ul>").appendTo(header);

                    var currentPortlet = this;  // Closure                    

                    // Attach Event Handlers
                    header.click(function (e) {
                        e.preventDefault();
                        currentPortlet.layoutManager.show(currentPortlet.settings.name);
                    });
                }

                if (this.settings.addContentWrapperDiv) {
                    // Add Content Div to Section
                    this.contentDiv = $('<div></div>').addClass(this.settings.contentWrapperClass);
                    this.contentDiv.appendTo(this.portletSection);
                }
                else {
                    this.contentDiv = this.portletSection;
                };

                // Add Section to container
                $(this.layoutManager.wrapperDiv).append(this.portletSection);

                // Add Spacer Div
                if (!this.settings.hideSpacer) {
                    $('<div></div>').addClass('spacer').appendTo(this.layoutManager.wrapperDiv);
                }

                // Create Content Loader 
                //var funcRef = eval(this.settings.contentLoader);
                this.contentLoader = new ajaxContentLoader(this, this.settings);

                if (this.settings.allowPin) {
                    this.setCommand({ name: 'pin', text: '', title: 'Pin this section', commandClass: 'icon iconBS-pin', handler: this.handlePin });
                }
                if (this.settings.hidden == true) {
                    this.hide();
                }
               
                // Pin the section if specified in settings
                if (this.settings.isPinned) {
                    this.pin(true);
                }
            },
            refresh: function () {
                if (this.isVisible()) {
                    // Delegate to content loader
                    this.contentLoader.loadContent();
                }
                else {
                    // Since, portlet is hidden, there is no need to refresh content now.
                    // Ensure that content is loaded when the portlet is next shown
                    this.contentLoader.isContentLoaded = false;
                }
            },
            hide: function () {
                this.portletSection.hide();
            },
            show: function () {
                this.portletSection.show();
            },
            isVisible: function () {
                return this.contentDiv.is(":visible");
            },
            minimize: function (isMinimized) {
                if (isMinimized) {
                    this.contentDiv.slideUp('slow');
                    this.contentDiv.prev().removeClass('active');
                }
                else {
                    this.contentDiv.prev().addClass('active');
                    this.contentDiv.slideDown('slow');
                    if (!this.contentLoader.isContentLoaded)
                        this.refresh();
                }
            },
            handlePin: function (portlet, command, item) {
                portlet.pin(portlet.isPinned ? false : true);
            },
            setCommand: function (commandOptions) {
                var command = this.command(commandOptions.name);
                if (command != null) {
                    command.settings = commandOptions;
                    command.refresh();
                } else {
                    this.commands.push(new $.portletCommand(this, commandOptions));
                }
            },
            command: function (name) {
                var i;
                for (i = 0; i < this.commands.length; i++) {
                    if (this.commands[i].settings.name == name)
                        return this.commands[i];
                }
                return null;
            },
            pin: function (isPinned) {
                var pinCommand = this.command('pin');
                if (pinCommand != null) {
                    this.minimize(false);    // Ensure visible
                    var item = pinCommand.contentElement;
                    if (isPinned) {
                        item.removeClass('iconBS-pin');
                        item.addClass('iconBS-unpin');
                        item.attr('title', 'Unpin this section');
                    } else {
                        item.removeClass('iconBS-unpin');
                        item.addClass('iconBS-pin');
                        item.attr('title', 'Pin this section');

                        this.layoutManager.show(this.settings.name);
                    }
                    this.isPinned = isPinned;
                }
            },
            changeUrl: function (newUrl) {
                this.settings.url = newUrl;
                this.refresh();
            },
            remove: function () {
                this.portletSection.remove();
            }
        }
    });

    $.portletCommand = function (portlet, commandOptions) {
        this.portlet = portlet;
        this.settings = commandOptions;

        this.init();
    };

    $.extend($.portletCommand, {
        prototype: {
            init: function () {
                var commandItem = $("<li></li>");
                this.portlet.commandsContainer.prepend(commandItem);
                this.renderCommand(commandItem);
            },
            show: function () {
                this.contentElement.show();
            },
            hide: function () {
                this.contentElement.hide();
            },
            refresh: function () {
                var liContainer = this.contentElement.parent();
                liContainer.html('');
                this.renderCommand(liContainer);
            },
            changeText: function (newText) {
                this.contentElement.html(newText);
            },
            renderCommand: function (commandItem) {
                var currentCommand = this.settings;
                var commandContent;
                if (currentCommand.text == '') {
                    commandContent = $("<span></span>");
                    if (currentCommand.title != null)
                        commandContent.attr('title', currentCommand.title);
                    if (currentCommand.datarel != null) {
                        commandContent.attr('data-rel', currentCommand.datarel);
                        commandContent.append($('#' + currentCommand.datarel));
                    }
                } else {
                    commandContent = $("<a href=\"javascript:;\"></a>");
                    commandContent.text(currentCommand.text);
                }
                if (currentCommand.commandClass != null)
                    commandContent.attr('class', currentCommand.commandClass);
                if (currentCommand.id != null)
                    commandContent.attr('id', currentCommand.id);
                this.contentElement = commandContent;
                commandItem.append(commandContent);

                var portlet = this.portlet;
                var command = this;
                commandContent.click(function (e) {
                    if (currentCommand.handler != null) {
                        currentCommand.handler(portlet, command, commandContent);
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        e.preventDefault();
                    }
                });
            }
        }
    });

    var ajaxContentLoader = function (portlet, options) {
        this.portlet = portlet;
        this.settings = options;
        this.isContentLoaded = false;
        this.isLoadingContent = false;
        this.postLoad = function() {
        };
        this.init();
    };

    $.extend(ajaxContentLoader, {
        prototype: {
            init: function () {
            },
            loadContent: function () {
                if (this.isLoadingContent)
                    return;
                this.isLoadingContent = true;
                var div = this.portlet.contentDiv;
                this.isContentLoaded = false;

                $(div).html("").addClass("loading");

                var portletContext = this.portlet.layoutManager.settings.context;
                if (this.portlet.settings.context !== undefined) {
                    portletContext = $.extend({}, portletContext, this.portlet.settings.context);
                }

                var contentLoader = this;
                $.ajax({
                    cache: false,
                    dataType: "html",
                    data: portletContext,
                    timeout: 30000,             // Timeout of 30 seconds
                    type: this.settings.httpMethod,
                    url: this.settings.url,
                    success: function(data) {
                        $(div).html("").removeClass("loading").append(data);
                        contentLoader.isContentLoaded = true;
                        contentLoader.isLoadingContent = false;
                    },
                    error: function (xhr, status, error) {
                        if (xhr.status != 0 && xhr.status != 401)
                            $(div).html("").removeClass("loading").append('<div class="alert alert-error"><strong>Error!</strong> Cannot load data !!!<span class="iconBS-delete" onClick="$(this).parent().fadeOut();"></span></div>');
                        contentLoader.isLoadingContent = false;
                    },
                    beforeSend: function() {
                        $.jqlog.log('In Ajax beforeSend function');
                    },
                    complete: function() {
                        $.jqlog.log('In Ajax complete function');
                    }
                }).always(function() {
                    if (contentLoader.postLoad != null)
                        contentLoader.postLoad();
                });
            }
        }
    });

})(jQuery);
