﻿var Henkel = Henkel || {};
Henkel.admin = Henkel.admin || {};
Henkel.admin.customer = Henkel.admin.customer || {};
Henkel.admin.customer.contactdetail = Henkel.admin.customer.contactdetail || {};

Henkel.admin.customer.contactdetail = function () {
    this.options = {};

    var init = function (options) {
        var contactdetailInit = this;
        Henkel.admin.customer.contactdetail.options = options;

        var getValidationOptions = function () {
            var options = {
                messages: {
                    required: $.common.messages.required,
                },
                rules: {
                    Prefix: { XSSCheck: true },
                    FirstName: { XSSCheck: true },
                    MidleName: { XSSCheck: true },
                    LastName: { XSSCheck: true },
                    PhoneNumber: { XSSCheck: true },
                    Email: { XSSCheck: true },
                }
            };
            return Henkel.addDefaultValidationOptions(options, "#editCustomerContactDetailForm #editCustomerContactDetailErrors");
        };

        var thisForm = $("#editCustomerContactDetailForm");
        thisForm.validate(getValidationOptions());



        $("#btnEditCustomerContactDetail").click(function (e) {
            e.preventDefault();
            //Validate 
            $("#editCustomerContactDetailForm #editCustomerContactDetailErrors").hide();
            $("#editCustomerContactDetailForm #editCustomerContactDetailSucess").hide();
            var myForm = $('#editCustomerContactDetailForm');
            Henkel.placeholderOnSubmit.call(myForm);
            if (!myForm.valid()) {
                return false;
            }
            $("#editCustomerContactDetailForm #editCustomerGeneralInfoErrors").hide();
            var contact = {
                Prefix: $("#editCustomerContactDetailForm #Prefix").val(),
                FirstName: $("#editCustomerContactDetailForm #FirstName").val(),
                MidleName: $("#editCustomerContactDetailForm #MidleName").val(),
                LastName: $("#editCustomerContactDetailForm #LastName").val(),
                PhoneNumber: $("#editCustomerContactDetailForm #PhoneNumber").val(),
                Email: $("#editCustomerContactDetailForm #Email").val(),
            };

            var formData = myForm.serializeObject();
            $.extend(formData, { Contact: contact });

            var actionUrl = contactdetailInit.options.updateCustomerContactDetailUrl;
            $.ajax(actionUrl, {
                data: JSON.stringify(formData),
                contentType: "application/json; charset=utf-8",
                dataType: 'json',
                cache: false,
                async: false,
                type: 'POST',
                success: function (data) {
                    if (data.success) {
                        $("#editCustomerContactDetailForm #editCustomerGeneralInfoErrors").hide();
                        $("#editCustomerContactDetailForm #editCustomerContactDetailSucess").show();
                        Henkel.displaySuccessMessage("#editCustomerContactDetailForm #editCustomerContactDetailSucess", "Record saved successfully.");
                    }
                    else {
                        $("#editCustomerContactDetailForm #editCustomerContactDetailSucess").hide();
                        $("#editCustomerContactDetailForm #editCustomerContactDetailErrors").show();
                        Henkel.displayErrorMessage("#editCustomerContactDetailForm #editCustomerContactDetailErrors", data.message);
                    }
                }
            });
        });


        $("#editCustomerContactDetailForm #Prefix").focus();
    };

    return {
        init: init,
    };
}();