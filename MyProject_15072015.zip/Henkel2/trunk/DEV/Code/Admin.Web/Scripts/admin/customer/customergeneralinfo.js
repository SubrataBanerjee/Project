﻿var Henkel = Henkel || {};
Henkel.admin = Henkel.admin || {};
Henkel.admin.customer = Henkel.admin.customer || {};
Henkel.admin.customer.generalinfo = Henkel.admin.customer.generalinfo || {};

Henkel.admin.customer.generalinfo = function () {
    this.options = {};

    var init = function (options) {
        var generalinfoInit = this;
        Henkel.admin.customer.generalinfo.options = options;


        var getValidationOptions = function() {
            var options = {
                messages: {
                    required: $.common.messages.required,
                },
                rules: {
                    GroupCompanyName: { XSSCheck: true },
                    Line1: { XSSCheck: true },
                    Line2: { XSSCheck: true },
                    Line3: { XSSCheck: true },
                    City: { XSSCheck: true },
                    State: { XSSCheck: true },
                    Country: { XSSCheck: true },
                    Pin: { XSSCheck: true },
                }
            };
            return Henkel.addDefaultValidationOptions(options, 'editCustomerGeneralInfoErrors');
        };

        var thisForm = $('#editCustomerGeneralInfoForm');
        thisForm.validate(getValidationOptions());



        $("#btnEditCustomerGeneralInfo").click(function (e) {
            e.preventDefault();
            //Validate 
            $('#editCustomerGeneralInfoErrors').hide();
            $('#editCustomerGeneralInfoSuccess').hide();
            var myForm = $('#editCustomerGeneralInfoForm');
            Henkel.placeholderOnSubmit.call(myForm);
            if (!myForm.valid()) {
                return false;
            }
            $("#editCustomerGeneralInfoErrors").hide();
            var address = {
                Line1: $("#editCustomerGeneralInfoForm #Line1").val(),
                Line2: $("#editCustomerGeneralInfoForm #Line2").val(),
                Line3: $("#editCustomerGeneralInfoForm #Line3").val(),
                City: $("#editCustomerGeneralInfoForm #City").val(),
                State: $("#editCustomerGeneralInfoForm #State").val(),
                Country: $("#editCustomerGeneralInfoForm #Country").val(),
                Pin: $("#editCustomerGeneralInfoForm #Pin").val(),
            };

            var formData = myForm.serializeObject();
            $.extend(formData, { Address: address });

            var actionUrl = generalinfoInit.options.updateCustomerGeneralInfoUrl;
            $.ajax(actionUrl, {
                data: JSON.stringify(formData),
                contentType: 'application/json; charset=utf-8',
                dataType: 'json',
                cache: false,
                async: false,
                type: 'POST',
                success: function (data) {
                    if (data.success) {
                        $('#editCustomerGeneralInfoErrors').hide();
                        $('#editCustomerGeneralInfoSuccess').show();
                        Henkel.displaySuccessMessage("#editCustomerGeneralInfoSuccess", "Record saved successfully.");
                    }
                    else {
                        $('#editCustomerGeneralInfoSuccess').hide();
                        $('#editCustomerGeneralInfoErrors').show();
                        Henkel.displayErrorMessage('#editCustomerGeneralInfoErrors', data.message);
                    }
                }
            });
        });


        $("#editCustomerGeneralInfoForm #GroupCompanyName").focus();
    };

    return {
        init: init,
    };
} ();