﻿(function ($) {
    String.prototype.format = String.prototype.f = function () {
        var s = this,
            i = arguments.length;

        while (i--) {
            s = s.replace(new RegExp('\\{' + i + '\\}', 'gm'), arguments[i]);
        }
        return s;
    };

    $.fn.filterSearchBy = function (searchFields) {
        var filterDivHtml = addFilterRow("Filter Search By", searchFields, false);
        for (var i = 0; i < searchFields.length - 1; i++) {
            filterDivHtml += addFilterRow("", searchFields, true);
        }

        filterDivHtml += "<div class=\"btnPnl\"><a id=\"searchButtonLink\" href=\"javascript:;\" class=\"btn primary\">Search</a><a class=\"btn secondary filter add\" href=\"javascript:;\">Add filter</a></div>";
        this.html("").append(filterDivHtml);
        var filterDiv = this;
        $(".filter").click(function () {
            if ($(this).hasClass('add')) {
                filterDiv.find("fieldset:hidden:first").show();
                //$(filterDiv + " fieldset:hidden:first").show();
            };
            if ($(this).hasClass('remove')) {
                $(this).closest("fieldset").hide();
            };
        });
    };

    var addFilterRow = function (label, searchFields, hide) {
        var filterHtml;
        if (hide && hide == true)
            filterHtml = "<fieldset style=\"display:none\">";
        else
            filterHtml = "<fieldset>";

        filterHtml += "<label for=''>{0}</label><select name='searchMaster'><option value=\"All\">Select ...</option>".f(label);
        $.each(searchFields, function (idx, item) {
            filterHtml += "<option value=\"{0}\">{0}</option>".f(item);
        });
        filterHtml += "</select><input type=\"text\" name=\"fSearch\" class=\"txtl\" />";

        if (!label || label.length < 1)
            filterHtml += "<a class=\"filter remove\" href=\"javascript:;\">Remove filter</a>";

        filterHtml += "</fieldset>";

        return filterHtml;
    };

})(jQuery);