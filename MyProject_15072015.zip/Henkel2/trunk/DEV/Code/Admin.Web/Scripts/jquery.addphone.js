﻿/// <reference path="jquery-1.7.1.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />

$(function() {
    $.validator.addMethod('phonenumber', function (value) {
        return /^[0-9\-\(\)]+$/.test(value);
    }, $.common.bookingPartyPortlet.phoneNumber);
});

(function ($) {
    $.fn.addPhone = function (options) {
        if (this.length == 0)
            return this;

        if (this.length > 1) {
            this.each(function () {
                $(this).addPhone(options);
            });
            return this;
        }

        // If a layout manager is already associated return the layout manaager
        var addPhone = $.data(this[0], 'addPhone');
        if (addPhone) {
            return addPhone;
        }

        addPhone = new $.addPhone(options, this[0]);
        $.data(this[0], 'addPhone', addPhone);

        return addPhone;
    };

    // Constructor for layoutmanager
    $.addPhone = function (options, element) {
        this.settings = $.extend(true, {}, $.addPhone.defaults, options);
        this.containingDiv = element;

        this.init();
    };

    $.extend($.addPhone, {
        defaults: {
            phonePrefix: "Contact",
            phoneSectionId: "#ContactPhonesSection"
        },
        setDefaults: function (settings) {
            $.extend($.addPhone.defaults, settings);
        },
        prototype: {
            setPlaceHolder: function (obj) {
                $('[placeholder]', obj).focus(function () {
                    var input = $(this);
                    if (input.val() == input.attr('placeholder')) {
                        input.val('');
                        input.removeClass('placeholder');
                    }
                }).blur(function () {
                    var input = $(this);
                    if (input.val() == '' || input.val() == input.attr('placeholder')) {
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                    }
                });
            },
            setPhoneValue: function (phonesSection) {
                var addPhone = this;
                $('input:hidden', phonesSection).each(function () {
                    $(this).val('');
                });
                $("select option:selected", phonesSection).each(function () {
                    var selected = $(this).val();
                    var fieldset = $(this).closest("fieldset");
                    var name = "";
                    if (selected == "Office") {
                        name = addPhone.settings.phonePrefix + ".Office";
                    }
                    else if (selected == "Main") {
                        name = addPhone.settings.phonePrefix + ".Main";
                    }
                    else if (selected == "Fax") {
                        name = addPhone.settings.phonePrefix + ".Fax";
                    }
                    else if (selected == "Mobile") {
                        name = addPhone.settings.phonePrefix + ".Mobile";
                    }
                    var value = $('input[type="tel"]', fieldset).val();
                    var currentValue = $('input[name=\'' + name + '\']', phonesSection).val();                    
                    $('input[name=\'' + name + '\']', phonesSection).val(currentValue + "," + value);
                });
            },
            init: function () {

                var addPhone = this;

                $(this.settings.phoneSectionId).on('click', '.linkPhoneRemove', function () {
                    var fieldset = $(this).closest("fieldset");
                    var phonesSection = fieldset.closest("section");
                    fieldset.remove();
                    addPhone.setPhoneValue(phonesSection);
                });

                $(this.settings.phoneSectionId).find('input[type="tel"], select').change(function () {
                    var phonesSection = $(this).closest('section');
                    addPhone.setPhoneValue(phonesSection);
                });

                $(this.settings.phoneSectionId).on('click', '.linkPhone', function () {
                    var elementCount = $(addPhone.settings.phoneSectionId + ' .linkPhone').length;
                    
                    var fieldset = $(this).closest("fieldset");
                    var clone = fieldset.clone();                    
                    $('input[type="tel"]', clone).val('');                    
                    
                    var inputAttrName = $('input[type="tel"]', clone).attr("name") + elementCount;
                    $('input[type="tel"]', clone).attr("name", inputAttrName);
                    
                    var selectAttrName = $('select', clone).attr("name") + elementCount;
                    $('select', clone).attr("name", selectAttrName);
                    
                    var phonesSection = fieldset.closest('section');
                    $('select, input[type="tel"]', clone).change(function () {
                        addPhone.setPhoneValue(phonesSection);
                    });
                    phonesSection.append(clone);
                    
                    $('.linkPhone', clone).hide();
                    $('.linkPhoneRemove', clone).show();
                    
                    addPhone.setPlaceHolder(clone);
                    $('[placeholder]', clone).each(function () {
                        var input = $(this);
                        input.addClass('placeholder');
                        input.val(input.attr('placeholder'));
                    });
                });
            }
        }
    });

})(jQuery);