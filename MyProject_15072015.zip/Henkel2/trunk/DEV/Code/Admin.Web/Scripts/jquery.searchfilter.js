﻿language = $.searchfilterStrings;

(function ($) {
    $.searchfilter = $.searchfilter || { };

    $.fn.searchfilter = function (options) {
        if (this.length == 0)
            return this;

        if (this.length > 1) {
            this.each(function () {
                $(this).searchfilter(options);
            });
            return this;
        }

        // If a layout manager is already associated return the layout manaager
        var searchFilter = $.data(this[0], 'searchFilter');
        if (searchFilter) {
            return searchFilter;
        }

        searchFilter = new $.searchfilter(options, this[0]);
        $.data(this[0], 'searchFilter', searchFilter);

        return searchFilter;
    };

    // Constructor for layoutmanager
    $.searchfilter = function (options, element) {
        this.settings = $.extend(true, {}, $.searchfilter.defaults, options);
        this.containingDiv = element;

        this.init();
    };

    $.extend($.searchfilter, {
        defaults: {
            searchFields: [],
            searchHandler: null,
            filterLabel: language.FilterSearchBy,
            buttonPanelClass: '',
            addSearchButton: true,
            searchModule: ''
        },
        setDefaults: function (settings) {
            $.extend($.searchfilter.defaults, settings);
        },
        prototype: {
            getFilterRow: function (label, searchFields, hide) {
                var divContents = $("<fieldset/>");
                var searchFilterObj = this;
                if (hide)
                    divContents.hide();

                divContents.append("<label for=''>{0}</label>".f(label));

                var selectElement = $("<select />");
                selectElement.append("<option value=\"All\">{0}</option>".f(language.Select));
                $.each(searchFields, function (idx, item) {
                    var selectOption = $("<option value=\"{0}\">{1}</option>".f(item.key, item.value));
                    selectOption.attr("otype", item.type);
                    selectOption.data("options", item.options);
                    selectOption.data("configValue", item.configValue);
                    selectElement.append(selectOption);
                });
                divContents.append(selectElement);
                this.setSelectedFieldElement("normal", {}, divContents);

                selectElement.change(function () {
                    var type = $("option:selected", selectElement).attr("otype");
                    if(type == undefined || type == '')
                        type = "normal";                    
                    var options = $("option:selected", selectElement).data("options") || {};
                    var configValue = $("option:selected", selectElement).data("configValue") || '';
                    searchFilterObj.setSelectedFieldElement(type, options, divContents, configValue);
                });
                if (!label || label.length == 0) {
                    var filterRemoveButton = $("<a class=\"filter remove\" href=\"javascript:;\">{0}</a>".f(language.RemoveFilter));
                    divContents.append(filterRemoveButton);
                    filterRemoveButton.click(function () {
                        var fs = $(this).closest("fieldset");
                        $(':input:not(:button)', fs).val([]);
//                        var rateCriteriasDiv = fs.find("#rateCriteriasDiv");
//                        if (rateCriteriasDiv)
//                            rateCriteriasDiv.remove();
                        searchFilterObj.setSelectedFieldElement("normal", {}, fs, '');
                        fs.hide();
                    });
                }
                return divContents;
            },
            init: function () {
                $(this.containingDiv).html("");
                var divInfo;
                //add a div to display error/information 
                if($(this.containingDiv).attr('id')=='advancefilterDiv') {
                    divInfo = $("<div id=\"divInformation\" class=\"alert alert-info alert-MarginLeft\"></div>");
                } else {
                    divInfo = $("<div id=\"divInformationInPopup\" class=\"alert alert-info\"></div>");
                }
                divInfo.hide();
                divInfo.appendTo(this.containingDiv);

                //Fetching extesnion field meta data
                var tempSearchFields = this.settings.searchFields;
                $.ajax(BaseDirectory + "/Extensions/GetPrimaryExtensionMetaData", {
                    data: { entityName: this.settings.searchModule },
                    contentType: 'application/json; charset=utf-8',
                    dataType: 'json',
                    type: 'GET',
                    async: false,
                    cache: false,
                    success: function (data) {
                        for (var intCtr = 0; intCtr < data.length; intCtr++) {
                            var fieldType = data[intCtr].DataType;
                            var urlPath = "";
                            if (fieldType == "MasterLookup") {
                                fieldType = "lookup";
                            }
                            if (fieldType == "Textbox" || fieldType == "Textarea") {
                                fieldType = "normal";
                            }
                            if (fieldType == "Date") {
                                fieldType = "datetime";
                            }
                            if (fieldType == "RadioButton") {
                                fieldType = "dropdown";
                            }
                            if (fieldType == "Multi Select" || fieldType == "Single Select") {
                                fieldType = "dropdown";
                            }
                            if (fieldType == "DB Single Select") {
                                fieldType = "dropdown";
                                urlPath = BaseDirectory + '/' + data[intCtr].Param.replace(/\,/g, '/');
                            }
                            var searchFieldItem = {
                                key: data[intCtr].DisplayName,
                                value: data[intCtr].DisplayName,
                                type: fieldType,
                                subtype: "extension",
                                param: data[intCtr].Param,
                                options: { source: "Extension", metaId: data[intCtr].Id, lookupSelector: data[intCtr].Param, selectorField: data[intCtr].Param + "Name", selectorIdField: data[intCtr].Param + 'NameId', url: urlPath }
                            };
                            tempSearchFields.push(searchFieldItem);
                        }
                    },
                    error: function (data) {
                        var vdata = data;
                    }
                });

                this.getFilterRow(this.settings.filterLabel, this.settings.searchFields, false).appendTo(this.containingDiv);
                for (var i = 0; i < this.settings.searchFields.length - 1; i++) {
                    this.getFilterRow("", this.settings.searchFields, true).appendTo(this.containingDiv);
                }

                var buttonPanelDiv = $("<div></div>");
                buttonPanelDiv.addClass(this.settings.buttonPanelClass);                
                var searchButton = $("<a id=\"searchButtonLink\" href=\"javascript:;\" class=\"btn primary\">{0}</a>".f(language.Search));
                if(this.settings.addSearchButton)
                    buttonPanelDiv.append(searchButton);
                var spacerLabel = $("<label/>");
                buttonPanelDiv.append(spacerLabel);
                var filterAddButton = $("<a id=\"addMoreButtonLink\" class=\"btn secondary filter add\" href=\"javascript:;\">{0}</a>".f(language.AddFilter));
                buttonPanelDiv.append(filterAddButton);
                buttonPanelDiv.append($("<div class=\"spacer\"></div>"));
                
                // Add Events
                var searchFilter = this;
                if(this.settings.addSearchButton) {
                    searchButton.click(function() {
                        searchFilter.executeSearch();
                    });
                }

                filterAddButton.click(function (e) {
                    var lastVisibleSet =  $(searchFilter.containingDiv).find("fieldset:visible:not(#rateCriteriasDiv):last");
                    var selectedValue = lastVisibleSet.find('select').find(":selected").val();
                    
                    if(selectedValue == "All" || selectedValue == "" || selectedValue == null ||selectedValue == undefined)
                    {
                        e.preventDefault();
                        e.stopPropagation();
                        e.stopImmediatePropagation();
                        Henkel.displayErrorMessage(divInfo, $.common.searchFilterMessages.addAdvanceSearchFieldMessage);
                        return false;
                    }
                    $(searchFilter.containingDiv).find("fieldset:hidden:first").show();
                });

                $(this.containingDiv).append(buttonPanelDiv);
            },
            executeSearch: function () {
                if (this.settings.searchHandler) {
                    var data = this.selectedFields();
                    this.settings.searchHandler(data);

                    $(".extensionField").each(function () {
                        var fieldType = $(this)[0].type;
                        if ($(this)[0].className != undefined && $(this)[0].className.indexOf("dpDate") >= 0) {
                            fieldType = "date";
                        }

                        var advSearchValue = ($('#AdvanceSearchData')[0].value == '') ? 'Extension_' + $(this).attr("metaid") + '_' + fieldType + ',' + this.value : '|Extension_' + $(this).attr("metaid") + '_' + fieldType + ',' + this.value;
                        $('#AdvanceSearchData')[0].value += advSearchValue;
                    });
                }
            },
            raiseFilterAddClick: function () {
                 $('.btn.filter.add', $(this.containingDiv)).trigger('click');
            },
            setSelectedFieldElement: function (type, options, fieldset, value) {
                $('#divInformation').hide();
                $('#divInformationInPopup').hide();
                value = value == undefined ? "" : value;
                var removeFilter = $('.filter.remove', fieldset);
                
                switch (type.toLowerCase()) {
                case "normal":
                    {
                        fieldset.find('.dynamicField').remove();
                        var telementName = $(this.containingDiv).attr("id") + "_fSearch";
                        if(options.selectorField && options.selectorField.length > 1)
                            telementName = options.selectorField;
                        var element = "";
                        if (options.source != undefined) {
                            element = $("<span class=\"dynamicField\"><input type=\"text\" id=\"{0}\" name=\"{0}\" metaId=\"{2}\" class=\"extensionField\" value=\"{1}\" class=\"txtl\" /></span>".f(telementName, value, options.metaId));
                        }
                        else {
                            element = $("<span class=\"dynamicField\"><input type=\"text\" id=\"{0}\" name=\"{0}\" value=\"{1}\" class=\"txtl\" /></span>".f(telementName, value));
                        }

                        if(removeFilter.length > 0)
                            element.insertBefore(removeFilter);
                        else
                            fieldset.append(element);
                        break;
                    }
                case "datetime":
                    {
                        fieldset.find('.dynamicField').remove();
                        var delementName = $(this.containingDiv).attr("id") + "_fSearch";
                        if(options.selectorField && options.selectorField.length > 1)
                            delementName = options.selectorField;
                        var delement = "";
                        if (options.source == "Extension") {
                            delement = $("<span class=\"dynamicField\"><input type=\"text\" id=\"{0}\" name=\"{0}\" metaId=\"{2}\" class=\"dpDate datepicker extensionField\" value=\"{1}\" readonly /></span>".f(delementName, value, options.metaId));
                        }
                        else {
                            delement = $("<span class=\"dynamicField\"><input type=\"text\" id=\"{0}\" name=\"{0}\" class=\"dpDate datepicker\" value=\"{1}\" readonly /></span>".f(delementName, value));
                        }
                        if(removeFilter.length > 0)
                            delement.insertBefore(removeFilter);
                        else
                            fieldset.append(delement);                        
                        $(".datepicker").datepicker();                        
                        break;
                    }
                case "numeric":
                    {
                        fieldset.find('.dynamicField').remove();
                        var nelementName = $(this.containingDiv).attr("id") + "_fSearch";
                        if(options.selectorField && options.selectorField.length > 1)
                            nelementName = options.selectorField;                        
                        var nElement = $("<span class=\"dynamicField\"><input type=\"text\" id=\"{0}\" name=\"{0}\" value=\"{1}\" class=\"txtl\" /></span>".f(nelementName, value));
                        $(':input', nElement).numeric({ format: "0.000", onblur:false });
                        if(removeFilter.length > 0)
                            nElement.insertBefore(removeFilter);
                        else
                            fieldset.append(nElement);                                                
                        break;
                    }
                 case "lookup":
                     {
                        fieldset.find('.dynamicField').remove();
                         var value1 = value;
                         var value2 = value;
                        if(value.indexOf(";") > 1) {
                            var array = value.split(";");
                            value1 = array[0];
                            value2 = array[1];
                            value = '';
                        }
                        var lelement = "";
                        if (options.source != undefined) {
                            lelement = $("<span class=\"dynamicField\"><input type=\"text\" name=\"{0}\" id=\"{0}\"  value=\"{2}\" class=\"txtl\" /><input id=\"{1}\" name=\"{1}\"  value=\"{3}\" type=\"hidden\" metaId=\"{4}\" class=\"extensionField\"/></span>".f(options.selectorField, options.selectorIdField, value1, value2, options.metaId));
                        }
                        else {
                            lelement = $("<span class=\"dynamicField\"><input type=\"text\" name=\"{0}\" id=\"{0}\"  value=\"{2}\" class=\"txtl\" /><input id=\"{1}\" name=\"{1}\"  value=\"{3}\" type=\"hidden\" /></span>".f(options.selectorField, options.selectorIdField, value1, value2));
                        }
                        if(removeFilter.length > 0)
                            lelement.insertBefore(removeFilter);
                        else
                            fieldset.append(lelement);                                                
                         
                        var dynamicField1 = $('input[name={0}]'.f(options.selectorField), fieldset);
                        $.removeData(dynamicField1[0], 'masterlookup');
                        dynamicField1.masterlookup({ selector: options.lookupSelector, idField: options.selectorIdField, context: options.context, idFieldValue: value });                         
                         
                        break;
                     }
                case "dropdown":
                    {
                        fieldset.find('.dynamicField').remove();
                        var dynamicField = $('<span class=\"dynamicField\" />');
                        var selectElement = "";
                        var selectedValue = (value == '' || value == undefined) ? '' : value;
                        
                        if(selectedValue.indexOf(";") > 1) {
                            var ddlArray = selectedValue.split(";");
                            selectedValue = ddlArray[1];
                        }
                        if (options.source == "Extension") {
                            selectElement = $("<select Id='{0}' class='extensionField' name=\"{0}\" metaId=\"{1}\" />".f(options.selectorIdField, options.metaId));
                            if (options.url != "") {
                                var dynamicddl = new Henkel.global.PopulateDropDown({
                                    selectId: selectElement,
                                    selectedValue: selectedValue,
                                    actionUrl: options.url
                                });
                                dynamicddl.init();
                            }
                            else {
                                var lelement = "";
                                $(options.lookupSelector.split(',')).each(function () {
                                    lelement = lelement + "<option value='" + this + "'>" + this + "</option>";
                                });
                                selectElement.append(lelement);
                            }
                            
                        }
                        else {
                            selectElement = $("<select Id='{0}' name=\"{0}\"/>".f(options.selectorIdField));
                            if (options.url == undefined) {
                                var lelement = "";
                                $(options.param.split(',')).each(function () {
                                    lelement = lelement + "<option value='" + this + "'>" + this + "</option>";
                                });
                                selectElement.append(lelement);
                            }
                            else {
                                var dynamicddl = new Henkel.global.PopulateDropDown({
                                    selectId: selectElement,
                                    selectedValue: selectedValue,
                                    actionUrl: options.url
                                });
                                dynamicddl.init();
                            }
                        }
                       
                        dynamicField.append(selectElement);
                        if(removeFilter.length > 0)
                            dynamicField.insertBefore(removeFilter);
                        else
                            fieldset.append(dynamicField);                                                
                        break;                             
                    }
                case "checkbox":
                    {
                        fieldset.find('.dynamicField').remove();
                        var celementName = $(this.containingDiv).attr("id") + "_fSearch";
                        if(options.selectorField && options.selectorField.length > 1)
                            celementName = options.selectorField;
                        var celement = "";
                        if (options.source == "Extension") {
                            celement = $("<span class=\"dynamicField\"><input type=\"checkbox\" class='extensionField' metaId=\"{1}\" id=\"{0}\" name=\"{0}\" class=\"\" /></span>".f(celementName, options.metaId));
                        }
                        else {
                            celement = $("<span class=\"dynamicField\"><input type=\"checkbox\" id=\"{0}\" name=\"{0}\" class=\"\" /></span>".f(celementName));
                        }


                        if(removeFilter.length > 0)
                            celement.insertBefore(removeFilter);
                        else
                            fieldset.append(celement);
                        break;
                    }
                case "specialrate":
                    {
                        fieldset.find('.dynamicField').remove();
                        var dynamicField = $('<span class=\"dynamicField\" />');
                        var selectElement = $("<select Id='{0}' name=\"{0}\"/>".f(options.selectorIdField));
                        var selectedValue = (value == '' || value == undefined) ? '' : value.split(";")[1];
                        var selectedStartTime = "";
                        var selectedStartTimeZone = "";
                        var selectedEndTime = "";
                        var selectedEndTimeZone = "";
                                                
                        var rateCriteriasDivId = "rateCriteriasDiv";//do not change this id
                        var rateCriteriasDiv = $("<fieldset id='{0}' style='' class='dynamicField'></fieldset>".f(rateCriteriasDivId));
                        
                        selectElement.change(function() {
                            rateCriteriasDiv.html('');
                            var selected = $(this).val();
                            switch(selected) {
                                case "NonWorkingHours":
                                    $(this).next("#rateCriteriasDiv").html('');
                                    //var overTimeSpan = $('<span id="overtimeRates" style=""/>');
                                    rateCriteriasDiv.append("<label> </label>");
                                    rateCriteriasDiv.append("{0}".f(language.StartTime));
                                    var overTimeStartTime = $("<input class='m' id='overtimeRatesStartTime' name='overtimeRatesStartTime' type='text' value='{0}'/>".f(selectedStartTime));
                                    rateCriteriasDiv.append(overTimeStartTime);
                                    rateCriteriasDiv.append(" ");
                                    var overTimeStartTimeZone = $('<select id="overtimeRatesStartTimeZone" name="overtimeRatesStartTimeZone" class="selX">');
                                    rateCriteriasDiv.append(overTimeStartTimeZone);
                                    rateCriteriasDiv.append(" {0}".f(language.EndTime));
                                    var overTimeEndTime = $("<input class='m' id='overtimeRatesEndTime' name='overtimeRatesEndTime' type='text' value='{0}'/>".f(selectedEndTime));
                                    rateCriteriasDiv.append(overTimeEndTime);
                                    rateCriteriasDiv.append(" ");
                                    var overTimeEndTimeZone = $('<select id="overtimeRatesEndTimeZone" name="overtimeRatesEndTimeZone" class="selX">');
                                    rateCriteriasDiv.append(overTimeEndTimeZone);
                                    
                                    var startTimeZone = new Henkel.global.PopulateDropDown({
                                            selectId: overTimeStartTimeZone,
                                            selectedValue: selectedStartTimeZone,
                                            actionUrl: options.timezoneUrl
                                        });
                                    startTimeZone.init();
                        
                                    var endTimeZone = new Henkel.global.PopulateDropDown({
                                            selectId: overTimeEndTimeZone,
                                            selectedValue: selectedEndTimeZone,
                                            actionUrl: options.timezoneUrl
                                        });
                                    endTimeZone.init();
                                    break;
                                case "NonWorkingDays":
                                    rateCriteriasDiv.append('<label> </label><span id="weekendRates" style=""><input name="weekend" id="Monday" type="checkbox">&nbsp;Monday&nbsp;<input name="weekend" id="Tuesday" type="checkbox">&nbsp;Tuesday&nbsp;<input name="weekend" id="Wednesday" type="checkbox">&nbsp;Wednesday&nbsp;<input name="weekend" id="Thursday" type="checkbox">&nbsp;Thursday&nbsp;<input name="weekend" id="Friday" type="checkbox">&nbsp;Friday<input name="weekend" id="Saturday" type="checkbox">&nbsp;Saturday&nbsp;<input name="weekend" id="Sunday" type="checkbox">&nbsp;Sunday</span>');
                                    break;
                            }
                        });
                        
                        var dynamicddl = new Henkel.global.PopulateDropDown({
                            selectId: selectElement,
                            selectedValue: selectedValue,
                            actionUrl: options.url,
                            postPopulateAction: function () {
                                if(selectedValue != '') {
                                    var ddlArray = value.split(";");
                            
                                    if (selectedValue == 'NonWorkingHours') {
                                        if (ddlArray.length > 2) {
                                            var selectedTimes = ddlArray[2].toString();
                                            selectedStartTime = selectedTimes.split(",")[0];
                                            selectedStartTimeZone = selectedTimes.split(",")[1];
                                            selectedEndTime = selectedTimes.split(",")[2];
                                            selectedEndTimeZone = selectedTimes.split(",")[3];
                                        }
                                        selectElement.change();
                                        selectedStartTime = "";
                                        selectedStartTimeZone = "";
                                        selectedEndTime = "";
                                        selectedEndTimeZone = "";
                                    }
                                    else if (selectedValue == 'NonWorkingDays')  {
                                        selectElement.change();
                                        if (ddlArray.length > 2) {
                                            var checkedIds = ddlArray[2].split(",");
                                            for (var i = 0; i < checkedIds.length; i++) {
                                                rateCriteriasDiv.find("#" + checkedIds[i]).prop('checked', true);
                                            }
                                        }
                                    }
                                }
                            }
                            });
                        dynamicddl.init();
                        dynamicField.append(selectElement);

                        if(removeFilter.length > 0)
                            dynamicField.insertBefore(removeFilter);
                        else
                            fieldset.append(dynamicField);     
                        
                        fieldset.append(rateCriteriasDiv);
                        break;                             
                    }
                    case "daterange":
                     {
                       fieldset.find('.dynamicField').remove();
                         var values = value.split('_');
                         var ele1 = $("<span class=\"dynamicField\">"+$.common.general.From+":<input type=\"text\"  id=\"{0}\" name=\"{0}\" class=\"dpDate datepicker\" value=\"{1}\" readonly /></span>".f(options.fromDateId,values[0]));
                        var drement = $(ele1).append($("<span class=\"dynamicField\"> "+$.common.general.To+":<input type=\"text\"  id=\"{0}\" name=\"{0}\" class=\"dpDate datepicker\" value=\"{1}\" readonly /></span>".f(options.toDateId,values[1]!=undefined?values[1]:'')));
                        //var drement = $(ele1).append(ele2);
                        if(removeFilter.length > 0)
                            drement.insertBefore(removeFilter);
                        else
                            fieldset.append(drement);                        
                        $(".datepicker").datepicker();                        
                        break;
                     }
                default:
                }
            },
            selectedFields: function () {
                var data = {};
                var prevField = '';
                $('input[name="{0}_fSearch"]'.f($(this.containingDiv).attr("id"))).each(function () {
                    if ($(this).closest("fieldset").is(":visible")) {
                        var field = $(this).closest('fieldset').find('select').find(":selected").val();
                        if(field == prevField)
                        {
                            data["duplicate"] = field;
                        }
                        else
                            prevField = field;
                        data[field] = $(this).val();
                    }
                });
                return data;
            },
            fillFields: function (arr) {
            var i = -1;
            var parent = $(this.containingDiv);
             
            $.each(arr, function(key, value) {
                i = i + 1;
                var fs =$(parent).children("fieldset").eq(i);
                $(fs).show();
                var sel = $(fs).children("select");
                var txt = $(fs).children("Span").children(":input[type=text]");

                var type = $($(sel + "option[value=" + key + "]").get(i)).attr('otype');

                if (type != "normal") {
                    var options = $($(sel + "option[value='" + key + "']").get(i)).data("options");
                    $(parent).searchfilter().setSelectedFieldElement(type, options, fs, value);

                    if (type == "lookup") {
                        $("#" + options.selectorIdField).val(value);
                    }
                } else {
                    $(txt).val(value);
                }
                $(sel).val(key);  
            });
            },
            resetInputFields: function () {
                var parent = $(this.containingDiv);
                var fs = $(parent).children("fieldset");
                $.each(fs, function(idx, fs1) {
                    $(fs1).children("span.dynamicField").children(":input[type=text]").val('');
                    $(fs1).children("span.dynamicField").children(":input[type=text]").focus();
                });
            },            
          resetFields: function () {
            var parent = $(this.containingDiv);
            
            var count = $(parent).children("fieldset").size();
            var fs = $(parent).children("fieldset").eq(0);
            $(fs).children("select").prop('selectedIndex', 0);
            $(fs).children("span.dynamicField").children(":input[type=text]").val('');
            for (var i = 1; i < count; i++) {
                $(parent).children("fieldset").eq(i).hide();
            }
        }
        }
    });

})(jQuery);