﻿(function ($) {
	$.fn.masterlookup = function (options) {
		if (this.length == 0)
			return this;

		if (this.length > 1) {
			this.each(function () {
				$(this).layout(options);
			});
			return this;
		}

		// If a layout manager is already associated return the layout manaager
		var masterlookup = $.data(this[0], 'masterlookup');
		if (masterlookup) {
			return masterlookup;
		}
		masterlookup = new $.masterlookup(options, this[0]);
		$.data(this[0], 'masterlookup', masterlookup);

		return masterlookup;
	};

	// Constructor for masterlookup
	$.masterlookup = function (options, element) {
		this.settings = $.extend(true, {}, $.masterlookup.defaults, options);
		this.targetElement = $(element);
		this.lookupSelectors = [];
		this.selector = $.masterlookup.getSelector(options.selector);
		this.init();
	};

	$.extend($.masterlookup, {
		defaults: {
			multiSelect: false,
			searchDialog: true,
			autoComplete: true,
			selector: null,
			context: {},
			autoCompletePostAction: {},
			idField: null,
			idFieldValue: null,
			dialogLevel: 2, // 2 for level 2 dialog
			model: true
		},
		selectorDefaults: {
			name: '',
			hasDialog: true,
			dialog: {
				size: 'm'
			},
			autocomplete: {
				valueField: 'value',
				keyField: 'key'
			},
			context: {}
		},
		setDefaults: function (settings) {
			$.extend($.masterlookup.defaults, settings);
		},
		lookupSelectors: [],
		urlPrefix: '',
		addSelector: function (options) {

			// Options
			// name, hasDialog, dialog {url, size}, autocomplete {url, valueField: value, keyField: key}
			var selectorOptions = $.extend({}, this.selectorDefaults, options);
			$.masterlookup.lookupSelectors.push(selectorOptions);
		},
		getSelector: function (selectorName) {
			var i = 0;
			for (i = 0; i < $.masterlookup.lookupSelectors.length; i++) {
				if ($.masterlookup.lookupSelectors[i].name == selectorName)
					return $.masterlookup.lookupSelectors[i];
			}
			return null;
		},

		prototype: {
			setNewContext: function (newContext) {
				try {
					$.extend(this.settings.context, newContext);
				}
				catch (e) { };
			},
			init: function () {
				var lookup = this;
				// Add a search button after the element and attach event
				if (this.supportsDialog()) {
					var searchAnchorLink = $('<a id="{0}SearchLink"></a>'.f(this.targetElement.attr('Id')));
					var searchIcon = $('<span class="iconBS-search" title="Search"></span>');
					searchAnchorLink.append(searchIcon);
					this.targetElement.after(searchAnchorLink);

					if (this.settings.modal == true)
						searchAnchorLink.attr('name', 'modal');
					if (this.settings.dialogLevel == 1) {
						searchAnchorLink.attr('href', '#dialog');
						searchAnchorLink.addClass('dialog');
					} else {
						searchAnchorLink.attr('href', '#dialogIn');
						searchAnchorLink.addClass('dialogIn');
					}
					if (this.settings.idFieldValue != null && this.settings.idFieldValue.length > 1) {
						var actionUrl = $.masterlookup.urlPrefix + this.selector.getValueUrl;
						var returnValue = "";
						$.ajax(actionUrl, {
							data: { itemId: this.settings.idFieldValue },
							contentType: 'application/json; charset=utf-8',
							dataType: 'json',
							cache: false,
							type: 'Get',
							async: false,
							success: function (data) {
								if (data.success) {
									returnValue = data.Name;
								}
							},
							error: function (data) {
							}
						});
						this.targetElement.val(returnValue);
					}
					searchAnchorLink.attr('rel', this.selector.dialog.size);

					// Add event handler to searchAnchor
					searchAnchorLink.click(function (event) {
						var elementId = lookup.targetElement.attr('id');
						var term = lookup.targetElement.val();
						if (lookup.targetElement.val() == lookup.targetElement.attr('placeholder')) {
							term = '';
						}
						var dialogUrl = $.masterlookup.urlPrefix + lookup.selector.dialog.url + "?id=" + elementId + "&term=" + encodeURIComponent(term);

						var contextValues = {};
						if ($.isFunction(lookup.settings.context)) {
							contextValues = lookup.settings.context();
						} else {
							contextValues = lookup.settings.context;
						}
						// Append context data to dialogUrl 
						$.each(contextValues, function (name, val) {
							dialogUrl = dialogUrl + "&" + name + "=" + encodeURIComponent(val);
						});
						$.each(lookup.selector.context, function (name, val) {
							dialogUrl = dialogUrl + "&" + name + "=" + encodeURIComponent(val);
						});

						// Call the dialog
						Henkel.modalWin.call(searchAnchorLink, dialogUrl);

						event.stopPropagation();
						event.stopImmediatePropagation();
					});
				}

				//Remove id field value in case value in name field is erased
				if (lookup.settings.idField && lookup.settings.idField != null) {
					$(this.targetElement).change(function () {
						var elemId = $(this);
						var hiddenElemId = $("#" + lookup.settings.idField);

						if (elemId.val() == elemId.attr('placeholder') || elemId.val() == '') {
							hiddenElemId.val('');
						}
						else {
							elemId.removeClass('placeholder');
						}
					});
				}
				var autoCompleteResultMap = {};

				var findAutoCompleteResultItem = function (itemValue, map) {
					return $.grep(map, function (item) {
						return item.value.toLowerCase() == itemValue.toLowerCase();
					});
				};
				// Add autoComplete to the element
				if (this.supportsAutocomplete()) {
					this.targetElement.autocomplete({
						source: function (request, response) {
							var contextValues = {};
							if ($.isFunction(lookup.settings.context)) {
								contextValues = lookup.settings.context();
							} else {
								contextValues = lookup.settings.context;
							}
							$.ajax($.masterlookup.urlPrefix + lookup.selector.autocomplete.url, {
								data: $.extend({ term: extractLast(lookup.settings.multiSelect, request.term) }, contextValues, lookup.selector.context),
								dataType: 'json',
								success: function (data) {
									autoCompleteResultMap = data;
									response($.map(data, function (item) {
										if (item.selectedValue === undefined)
											item.selectedValue = item.value;
										return {
											value: item.value,
											selectedValue: item.selectedValue,
											key: item.key
										};
									}));
								}
							});
						},
						minLength: 2,
						delay: 300,
						focus: function () {
						    // prevent value inserted on focus
						    return false;
						},
						select: function (event, ui) {
							if (ui.item) {
								if (lookup.settings.idField && lookup.settings.idField != null) {
									if (lookup.settings.multiSelect) {
										var Ids = splitIds($('#' + lookup.settings.idField).val());
										if (Ids == undefined)
											Ids = [];
										Ids.push(ui.item.key);
										$('#' + lookup.settings.idField).val(Ids.join(";"));
										$('#' + lookup.settings.idField).attr('data-selectedValue', ui.item.selectedValue);
										var terms = split(this.value);
										// remove the current input
										terms.pop();
										// add the selected item
										terms.push(ui.item.value);
										// add placeholder to get the comma-and-space at the end
										terms.push("");

										lookup.targetElement.val(terms.join(", "));
									}
									else {

										$('#' + lookup.settings.idField).val(ui.item.key);
										$('#' + lookup.settings.idField).attr('data-selectedValue', ui.item.selectedValue);
										lookup.targetElement.val(ui.item.selectedValue);

									}
									if ($.isFunction(lookup.settings.autoCompletePostAction)) {
										lookup.settings.autoCompletePostAction();
									}
									return false;
								}
							}
						},
						change: function (event, ui) {
							var data = $.data(this); //Get plugin data for 'this' 
							if (data != null && data.autocomplete != null && ui.item === null && data.autocomplete.selectedItem === null) {
								var item = findAutoCompleteResultItem(data.autocomplete.term, autoCompleteResultMap);
								var itemKey = '';
								var itemValue = '';
								if (item.length > 0 && item[0].key !== undefined) {
									itemKey = item[0].key;
									if (item[0].selectedValue === undefined)
										item[0].selectedValue = item[0].value;
									itemValue = item[0].selectedValue;
								}
								$('#' + lookup.settings.idField).val(itemKey);
								$('#' + lookup.settings.idField).attr('data-selectedValue', itemValue);
							};
						}
					}).data("autocomplete")._renderItem = function (ul, item) {
						if (item.selectedValue == item.value)
							return $("<li>").data("item.autocomplete", item).append("<a>" + item.selectedValue + "</a>").appendTo(ul);
						return $("<li>").data("item.autocomplete", item).append("<a>" + item.selectedValue + "<br>" + item.value + "</a>").appendTo(ul);
					};
				    
					this.targetElement.keydown(function (event) {
					    var newEvent = $.Event('keydown', {
					        keyCode: event.keyCode
					    });

					    if (newEvent.keyCode !== $.ui.keyCode.TAB) {
					        return true;
					    }

					    if (newEvent.keyCode == $.ui.keyCode.TAB) {
					        // custom logic for tab
					        newEvent.keyCode = $.ui.keyCode.DOWN;
					        $(this).trigger(newEvent);
					        $(lookup.targetElement.data('autocomplete').menu.active).find('a').trigger('click');
					        return true;
					    }
					    return true;
					});

				}
			},
			supportsDialog: function () {
				return true;
				//return this.settings.searchDialog && this.settings.searchDialog == true && this.selector.dialog && this.selector.dialog.url;
			},
			supportsAutocomplete: function () {
				return true;
				//return this.settings.autoComplete && this.settings.autocomplete == true && this.selector.autocomplete && this.selector.autocomplete.url;
			}
		}
	});
})(jQuery);

$(function () {

    $.masterlookup.addSelector({
        name: 'Shipper',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: { partyType: 'Shipper' }
    });
    $.masterlookup.addSelector({
        name: 'Consignee',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: { partyType: 'Consignee' }
    });
    $.masterlookup.addSelector({
        name: 'Client',
        hasDialog: true,
        dialog: { url: 'Masters/Client/ClientSearch', size: 'm' },
        autocomplete: { url: 'Masters/Client/SearchClients', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Office',
        hasDialog: true,
        dialog: { url: 'Masters/Office/OfficeSearch', size: 'm' },
        autocomplete: { url: 'Masters/Office/SearchOffices', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Resource',
        hasDialog: true,
        getValueUrl: 'Masters/TeamMember/GetResourceNameById',
        dialog: { url: 'Masters/TeamMember/ResourceSearch', size: 'm' },
        autocomplete: { url: 'Masters/TeamMember/SearchResources', keyField: 'key', valueField: 'value' },
        context: {}
    });
    
    $.masterlookup.addSelector({
        name: 'ResourceUser',
        hasDialog: true,
        getValueUrl: 'CKBMasters/RequestType/GetResourceNameById',
        dialog: { url: 'CKBMasters/RequestType/ResourceSearch', size: 'm' },
        autocomplete: { url: 'CKBMasters/RequestType/SearchResources', keyField: 'key', valueField: 'value' },
        context: {}
    });


    $.masterlookup.addSelector({
        name: 'ResourceMultiSelect',
        hasDialog: true,
        getValueUrl: 'Masters/TeamMember/GetResourceNameById',
        dialog: { url: 'Admin/OfficeGeneralInfo/ResourceSearch', size: 'm' },
        autocomplete: { url: 'Masters/TeamMember/SearchResourcesMultiSelect', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Location',
        hasDialog: true,
        getValueUrl: 'Masters/Location/GetLocationNameById',
        dialog: { url: 'Masters/Location/LocationSearch', size: 'm' },
        autocomplete: { url: 'Masters/Location/SearchLocations', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'LocationWithUNCode',
        hasDialog: true,
        getValueUrl: 'Masters/Location/GetLocationNameById',
        dialog: { url: 'Masters/Location/LocationSearch', size: 'm' },
        autocomplete: { url: 'Masters/Location/SearchLocationsWithUniqueUnCode', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'ActivityLocation',
        hasDialog: true,
        getValueUrl: 'Tracking/BulkTrackingUpdate/GetLocationNameById',
        dialog: { url: 'Tracking/BulkTrackingUpdate/ActivityLocationSearch', size: 'm' },
        autocomplete: { url: 'Tracking/BulkTrackingUpdate/SearchLocations', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'LocationAir',
        hasDialog: true,
        getValueUrl: 'Masters/Location/GetLocationNameById',
        dialog: { url: 'Masters/Location/LocationSearch', size: 'm' },
        autocomplete: { url: 'Masters/Location/SearchLocations', keyField: 'key', valueField: 'value' }
    });
    $.masterlookup.addSelector({
        name: 'LocationSea',
        hasDialog: true,
        getValueUrl: 'Masters/Location/GetLocationNameById',
        dialog: { url: 'Masters/Location/LocationSearch', size: 'm' },
        autocomplete: { url: 'Masters/Location/SearchLocations', keyField: 'key', valueField: 'value' }
    });
    $.masterlookup.addSelector({
        name: 'NonConformance',
        hasDialog: true,
        dialog: { url: 'Masters/NonConformance/NonConformanceSearch', size: 'm' },
        autocomplete: { url: 'Masters/NonConformance/SearchNonConformancesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Party',
        hasDialog: true,
        getValueUrl: 'Masters/Party/GetPartyNameById',
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'PartyWithClientOffice',
        hasDialog: true,
        getValueUrl: 'Masters/Party/GetPartyNameById',
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'PreferredParty',
        hasDialog: true,
        getValueUrl: 'Masters/Party/GetPartyNameById',
        dialog: { url: 'Masters/Party/PreferredPartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPreferredPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'BillingParty',
        hasDialog: true,
        getValueUrl: 'Billing/Search/SearchSystemPartiesFromBookingParties',
        dialog: { url: 'Billing/Search/SystemPartiesFromBookingPartySearch', size: 'm' },
        autocomplete: { url: 'Billing/Search/GetSystemPartiesFromBookingPartiesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Country',
        hasDialog: true,
        getValueUrl: 'Masters/Country/GetCountryNameById',
        dialog: { url: 'Masters/Country/CountrySearch', size: 'm' },
        autocomplete: { url: 'Masters/Country/SearchCountrys', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'SFSCountry',
        hasDialog: true,
        getValueUrl: 'SFSMasters/CountryMaster/GetCountryNameById',
        dialog: { url: 'SFSMasters/CountryMaster/CountrySearch', size: 'm' },
        autocomplete: { url: 'SFSMasters/CountryMaster/SearchCountrys', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Product',
        hasDialog: true,
        getValueUrl: 'Masters/Product/GetProductNameById',
        dialog: { url: 'Masters/Product/ProductSearch', size: 'm' },
        autocomplete: { url: 'Masters/Product/SearchProducts', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'ProductWithoutClient',
        hasDialog: true,
        getValueUrl: 'Masters/Product/GetProductNameById',
        dialog: { url: 'Masters/Product/ProductSearch', size: 'm' },
        autocomplete: { url: 'Masters/Product/SearchProducts', keyField: 'key', valueField: 'value' },
        context: { IsWithoutClient: true }
    });
    $.masterlookup.addSelector({
        name: 'ChargeCode',
        hasDialog: true,
        getValueUrl: 'Billing/Home/GetChargeCodeNameByChargeCodeId',
        dialog: { url: 'Masters/ChargeCodeSearch/ChargeCodeSearch', size: 'm' },
        autocomplete: { url: 'Masters/ChargeCodeSearch/SearchChargeCodeWithTerm', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Activity',
        hasDialog: true,
        dialog: { url: 'Masters/Activity/ActivitySearch', size: 'm' },
        autocomplete: { url: 'Masters/Activity/SearchActivities', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Carrier',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchParties', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Carrier' }
    });
    $.masterlookup.addSelector({
        name: 'VesselCarrier',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'ShippingLine|MasterCarrier' }
    });
    $.masterlookup.addSelector({
        name: 'OriginAgent',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchParties', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Origin Agent' }
    });
    $.masterlookup.addSelector({
        name: 'SystemDebtor',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForBilling', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Debtor' }
    });
    $.masterlookup.addSelector({
        name: 'SystemVendor',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForBilling', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Vendor' }
    });
    $.masterlookup.addSelector({
        name: 'Currency',
        hasDialog: true,
        getValueUrl: 'Masters/Currency/GetCurrencyInfo',
        dialog: { url: 'Masters/Currency/CurrencySearch', size: 'm' },
        autocomplete: { url: 'Masters/Currency/SearchCurrenciesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Continent',
        hasDialog: true,
        getValueUrl: 'Masters/Continent/GetContinentInfo',
        dialog: { url: 'Masters/Continent/ContinentSearch', size: 'm' },
        autocomplete: { url: 'Masters/Continent/SearchContinentsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Company',
        hasDialog: true,
        getValueUrl: 'Masters/Company/GetCompanyInfo',
        dialog: { url: 'Masters/Company/CompanySearch', size: 'm' },
        autocomplete: { url: 'Masters/Company/SearchCompaniesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'EquipmentType',
        hasDialog: true,
        getValueUrl: 'Masters/EquipmentType/GetEquipmentTypeById',
        dialog: { url: 'Masters/EquipmentType/EquipmentTypeSearch', size: 'm' },
        autocomplete: { url: 'Masters/EquipmentType/SearchEquipmentTypesAutocomplete', keyField: 'key', valueField: 'value' },
      
    });
    $.masterlookup.addSelector({
        name: 'VehicleType',
        hasDialog: true,
        getValueUrl: 'Masters/Equipment/GetEquipmentInfo',
        dialog: { url: 'Masters/Equipment/EquipmentSearch', size: 'm' },
        autocomplete: { url: 'Masters/Equipment/SearchEquipments', keyField: 'key', valueField: 'value' },
        context: { road: 'road' }
    });
    $.masterlookup.addSelector({
        name: 'EquipmentSize',
        hasDialog: true,
        getValueUrl: 'Masters/EquipmentSize/GetEquipmentSizeInfo',
        dialog: { url: 'Masters/EquipmentSize/EquipmentSizeSearch', size: 'm' },
        autocomplete: { url: 'Masters/EquipmentSize/SearchEquipmentSizesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Equipment',
        hasDialog: true,
        getValueUrl: 'Masters/Equipment/GetEquipmentInfo',
        dialog: { url: 'Masters/Equipment/EquipmentSearch', size: 'm' },
        autocomplete: { url: 'Masters/Equipment/SearchEquipments', keyField: 'key', valueField: 'value' }
    });
    
    $.masterlookup.addSelector({
        name: 'Booking',
        hasDialog: true,
        getValueUrl: 'Billing/Search/GetBookingNumbers',
        dialog: { url: 'Billing/Search/BookingNumbersSearch', size: 'm' },
        autocomplete: { url: 'Billing/Search/SearchBookingNumbersAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'JobNumber',
        hasDialog: true,
        getValueUrl: 'Billing/Search/GetJobNumbers',
        dialog: { url: 'Billing/Search/BookingProcessNumberSearch', size: 'm' },
        autocomplete: { url: 'Billing/Search/SearchJobNumbersAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
    name: 'Package',
    hasDialog: true,
    getValueUrl: 'Booking/Search/GetBookingPackages',
    dialog: { url: 'Booking/Search/BookingPackageSearch', size: 'm' },
    autocomplete: { url: 'Booking/Search/SearchBookingPackageAutocomplete', keyField: 'key', valueField: 'value' },
    context: {}
   });
   $.masterlookup.addSelector({
   	name: 'Vehicle',
   	hasDialog: true,
   	getValueUrl: 'Booking/Search/GetBookingVehicles',
   	dialog: { url: 'Booking/Search/BookingVehicleSearch', size: 'm' },
   	autocomplete: { url: 'Booking/Search/SearchBookingVehicleAutocomplete', keyField: 'key', valueField: 'value' },
   	context: {}
   });
    $.masterlookup.addSelector({
        name: 'JobNo',
        hasDialog: true,
        getValueUrl: 'Tracking/BulkTrackingUpdate/GetJobNumbers',
        dialog: { url: 'Tracking/BulkTrackingUpdate/JobNumbersList', size: 'm' },
        //        autocomplete: { url: 'Tracking/BulkTrackingUpdate/GetJobNumbersAutoComplete', keyField: 'key', valueField: 'value' },        
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'EquipmentNo',
        hasDialog: true,
        getValueUrl: 'Tracking/BulkTrackingUpdate/GetBookingEquipment',
        dialog: { url: 'Tracking/BulkTrackingUpdate/GetBookingEquipmentList', size: 'm' },
        //        autocomplete: { url: 'Tracking/BulkTrackingUpdate/GetJobNumbersAutoComplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'ActivityList',
        hasDialog: true,
        getValueUrl: 'Tracking/BulkTrackingUpdate/GetActivities',
        dialog: { url: 'Tracking/BulkTrackingUpdate/GetActivityList', size: 'm' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'BookingActivity',
        hasDialog: true,
        getValueUrl: 'Booking/Search/GetJobActivity',
        dialog: { url: 'Booking/Search/BookingProcessActivitySearch', size: 'm' },
        autocomplete: { url: 'Booking/Search/SearchJobActivitiesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'OfficeType',
        hasDialog: true,
        getValueUrl: 'Masters/OfficeType/GetOfficeTypeInfo',
        dialog: { url: 'Masters/OfficeType/OfficeTypeSearch', size: 'm' },
        autocomplete: { url: 'Masters/OfficeType/SearchOfficeTypesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'MawbNo',
        hasDialog: true,
        dialog: { url: 'Booking/StockEntry/GetViewForSearchAirwayBillNo', size: 's' },
        autocomplete: { url: 'Booking/StockEntry/SearchAirwayBillNos', keyField: 'key', valueField: 'value' }
        , context: { type: 'MasterAwb' }
    });
    $.masterlookup.addSelector({
        name: 'HawbNo',
        hasDialog: true,
        dialog: { url: 'Booking/StockEntry/GetViewForSearchAirwayBillNo', size: 's' },
        autocomplete: { url: 'Booking/StockEntry/SearchAirwayBillNos', keyField: 'key', valueField: 'value' }
        , context: { type: 'HouseAwb' }
    });
    $.masterlookup.addSelector({
        name: 'BookingTeam',
        hasDialog: true,
        dialog: { url: 'Booking/Team/GetViewForBookingTeamSearch', size: 'm' },
        autocomplete: { url: 'Booking/Team/SearchBookingTeamsByAutoComplete', keyField: 'key', valueField: 'value' }
        , context: {}
    });
    $.masterlookup.addSelector({
        name: 'Vessel',
        hasDialog: true,
        dialog: { url: 'Masters/Vessel/VesselSearch', size: 'm' },
        autocomplete: { url: 'Masters/Vessel/SearchVesselsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'BillingDocumentHeader',
        hasDialog: true,
        dialog: { url: 'Billing/Search/BillingDocumentHeaderNumberSearch', size: 'm' },
        autocomplete: { url: 'Billing/Search/SearchBillingDocumentHeaderNumbersAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'VesselSchedule',
        hasDialog: false,
        dialog: {},
        autocomplete: { url: 'Masters/VesselSchedule/SearchVesselsScheduleAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'CommodityGroup',
        hasDialog: true,
        getValueUrl: 'Masters/CommodityGroup/GetCommodityGroupNameById',
        dialog: { url: 'Masters/CommodityGroup/CommodityGroupSearch', size: 'm' },
        autocomplete: { url: 'Masters/CommodityGroup/SearchCommodityGroupsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Region',
        hasDialog: true,
        getValueUrl: 'Masters/Region/GetRegionNameById',
        dialog: { url: 'Masters/Region/RegionSearch', size: 'm' },
        autocomplete: { url: 'Masters/Region/SearchRegions', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'EquipmentGroup',
        hasDialog: true,
        dialog: { url: 'Masters/EquipmentGroup/EquipmentGroupSearch', size: 'm' },
        autocomplete: { url: 'Masters/EquipmentGroup/SearchEquipmentGroupsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'ChargeCodeGroup',
        hasDialog: true,
        dialog: { url: 'Masters/ChargeCodeGroup/ChargeCodeGroupSearch', size: 'm' },
        autocomplete: { url: 'Masters/ChargeCodeGroup/SearchChargeCodeGroupsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'ProductCategory',
        hasDialog: true,
        getValueUrl: 'Masters/ProductCategory/GetProductCategoryInfo',
        dialog: { url: 'Masters/ProductCategory/ProductCategorySearchPopup', size: 'm' },
        autocomplete: { url: 'Masters/ProductCategory/SearchProductCategories', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'TaxType',
        hasDialog: true,
        getValueUrl: 'Masters/TaxType/GetTaxTypeInfo',
        dialog: { url: 'Masters/TaxType/TaxTypeSearch', size: 'm' },
        autocomplete: { url: 'Masters/TaxType/SearchTaxTypesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'TaxCode',
        hasDialog: true,
        getValueUrl: 'Masters/TaxCode/GetTaxCodeInfo',
        dialog: { url: 'Masters/TaxCode/TaxCodeSearch', size: 'm' },
        autocomplete: { url: 'Masters/TaxCode/SearchTaxCodesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'PrintingCode',
        hasDialog: true,
        getValueUrl: 'Masters/PrintingCode/GetPrintingCodeInfo',
        dialog: { url: 'Masters/PrintingCode/PrintingCodeSearch', size: 'm' },
        autocomplete: { url: 'Masters/PrintingCode/SearchPrintingCodeAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'TaxGroup',
        hasDialog: true,
        getValueUrl: 'Masters/ChargeCode/GetTaxGroupInfo',
        dialog: { url: 'Masters/ChargeCode/TaxGroupSearch', size: 'm' },
        autocomplete: { url: 'Masters/ChargeCode/SearchTaxGroupsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'DocumentType',
        hasDialog: true,
        getValueUrl: 'Masters/DocumentType/GetDocumentTypeInfo',
        dialog: { url: 'Masters/DocumentType/DocumentTypeSearch', size: 'm' },
        autocomplete: { url: 'Masters/DocumentType/SearchDocumentTypesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Airline',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchParties', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Airline' }
    });

    $.masterlookup.addSelector({
        name: 'Module',
        hasDialog: true,
        getValueUrl: 'Masters/Module/GetModuleInfo',
        dialog: { url: 'Masters/Module/ModuleSearch', size: 'm' },
        autocomplete: { url: 'Masters/Module/SearchModuleAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'ClientParentGroup',
        hasDialog: true,
        dialog: { url: 'Admin/CustomerMaster/ClientParentGroupSearch', size: 'm' },
        autocomplete: { url: 'Admin/CustomerMaster/SearchClientParentGroup', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'Context',
        hasDialog: true,
        getValueUrl: 'Masters/Context/GetContextInfo',
        dialog: { url: 'Masters/Context/ContextSearch', size: 'm' },
        autocomplete: { url: 'Masters/Context/SearchContextsAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'OriginAgent1',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Origin Agent' }
    });

    $.masterlookup.addSelector({
        name: 'Carrier1',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'MasterCarrier' }
    });

    $.masterlookup.addSelector({
        name: 'SysResourceFunction',
        hasDialog: true,
        getValueUrl: 'Admin/UserProfileMapping/GetresourceFunctionDetailsInfo',
        dialog: { url: 'Admin/UserProfileMapping/ResourceFunctionSearch', size: 'm' },
        autocomplete: { url: 'Admin/UserProfileMapping/SearchResourceFunctions', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'Role',
        hasDialog: true,
        getValueUrl: 'Admin/UserProfileMapping/GetRoleDetailsInfo',
        dialog: { url: 'Admin/UserProfileMapping/RoleSearch', size: 'm' },
        autocomplete: { url: 'Admin/UserProfileMapping/SearchRoles', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'Debtors',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Debtor' }
    });
    $.masterlookup.addSelector({
        name: 'Vendors',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Vendor' }
    });
    
    $.masterlookup.addSelector({
        name: 'PartyDebtors',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Debtor' }
    });
    $.masterlookup.addSelector({
        name: 'PartyVendors',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Vendor' }
    });

    $.masterlookup.addSelector({
        name: 'Reason',
        hasDialog: true,
        dialog: { url: 'Masters/Reason/GetReasonSearchView', size: 'm' },
        autocomplete: { url: 'Masters/Reason/SearchReasonsAutocomplete', keyField: 'key', valueField: 'value' },
        context: { ReasonType: 'NonConformance' }
    });
    $.masterlookup.addSelector({
        name: 'PartyForReports',
        hasDialog: true,
        getValueUrl: 'Report/Air/GetPartyNameById',
        dialog: { url: 'Report/Air/PartySearch', size: 'm' },
        autocomplete: { url: 'Report/Air/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'PartyForReport',
        hasDialog: true,
        getValueUrl: 'Report/Air/GetPartyNameById',
        dialog: { url: 'Report/Billing/PartySearch', size: 'm' },
        autocomplete: { url: 'Report/Air/SearchPartiesForClient', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'SysUploadTempateField',
        hasDialog: true,
        getValueUrl: 'Admin/OperationsTemplate/GetUploadTemplateFieldDetailsInfo',
        dialog: { url: 'Admin/OperationsTemplate/UploadTemplateFieldSearch', size: 'm' },
        autocomplete: { url: 'Admin/OperationsTemplate/SearchUploadTemplateField', keyField: 'key', valueField: 'value' },
        context: {}

       });
    $.masterlookup.addSelector({
       	name: 'UserMultiSelect',
       	hasDialog: true,
       	getValueUrl: 'Admin/OperationsTemplate/GetUserNameByResourceId',
       	dialog: { url: 'Admin/OperationsTemplate/UserSearch', size: 'm' },
       	autocomplete: { url: 'Admin/OperationsTemplate/SearchUserMultiSelect', keyField: 'key', valueField: 'value' },
       	context: {}
       });

    $.masterlookup.addSelector({
       	name: 'ResourceFunction',
       	hasDialog: true,
       	getValueUrl: 'Masters/ResourceFunction/GetResourceFunctionInfo',
       	dialog: { url: 'Masters/ResourceFunction/ResourceFunctionSearch', size: 'm' },
       	autocomplete: { url: 'Masters/ResourceFunction/SearchResourceFunctionsAutocomplete', keyField: 'key', valueField: 'value' },
       	context: {}
    });

    $.masterlookup.addSelector({
        name: 'ServiceClass',
        hasDialog: true,
        getValueUrl: 'Masters/ServiceClass/GetServiceClassInfo',
        dialog: { url: 'Masters/ServiceClass/ServiceClassSearch', size: 'm' },
        autocomplete: { url: 'Masters/ServiceClass/SearchServiceClassAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'Bank',
        hasDialog: true,
        getValueUrl: 'Masters/Bank/BankIfo',
        dialog: { url: 'Masters/Bank/BankSearch', size: 'm' },
        autocomplete: { url: 'Masters/Bank/BankAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'Route',
        hasDialog: true,
        dialog: { url: 'Masters/Route/RouteSearch', size: 'm' },
        autocomplete: { url: 'Masters/Route/SearchRoutesAutocomplete', keyField: 'key', valueField: 'value' },
        context: {  }
    });
    $.masterlookup.addSelector({
        name: 'RequestType',
        hasDialog: true,
        getValueUrl: 'CKBMasters/RequestType/GetRequestTypeNameById',
        dialog: { url: 'CKBMasters/RequestType/RequestTypeSearch', size: 'm' },
        autocomplete: { url: 'CKBMasters/RequestType/SearchRequestTypes', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'RequestCode',
        hasDialog: true,
        getValueUrl: 'CKBMasters/RequestType/GetRequestTypeNameById',
        dialog: { url: 'CKBMasters/RequestType/RequestCodeSearch', size: 'm' },
        autocomplete: { url: 'CKBMasters/RequestType/SearchRequestCodes', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'DocumentCharlie',
        hasDialog: true,
        getValueUrl: 'CKBBooking/DocumentCharlie/GetDocumentNameById',
        dialog: { url: 'CKBBooking/DocumentCharlie/DocumentCharlieSearch', size: 'm' },
        autocomplete: { url: 'CKBBooking/DocumentCharlie/SearchDocumentNo', keyField: 'key', valueField: 'value' },
        context: {}
    });
    
    $.masterlookup.addSelector({
        name: 'WorkOrder',
        hasDialog: true,
        getValueUrl: 'CKBBilling/CKBSearch/GetWorkOrderNumbers',
        dialog: { url: 'CKBBilling/CKBSearch/WorkOrderNumbersSearch', size: 'm' },
        autocomplete: { url: 'CKBBilling/CKBSearch/SearchWorkOrderNumbersAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    
    $.masterlookup.addSelector({
        name: 'CKBServiceTemplate',
        hasDialog: true,
        getValueUrl: 'CKBBooking/CKBServiceProcess/GetServiceTemplateInfo',
        dialog: { url: 'CKBBooking/CKBServiceProcess/GetServiceTemplateLookup', size: 'm' },
        autocomplete: { url: 'CKBBooking/CKBServiceProcess/SearchServiceTemplateAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'ActionableUrl',
        hasDialog: true,
        dialog: { url: 'Masters/ActionableUrl/ActionableUrlSearch', size: 'm' },
        autocomplete: { url: 'Masters/ActionableUrl/SearchActionableUrlAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'PackageMaster',
        hasDialog: true,
        dialog: { url: 'SFSMasters/PackageMaster/PackageMasterSearch', size: 'm' },
        autocomplete: { url: 'SFSMasters/PackageMaster/SrchPackageMasters', keyField: 'key', valueField: 'value' },
        context: {}
    });

    $.masterlookup.addSelector({
        name: 'PackageTypeDetail',
        hasDialog: true,
        dialog: { url: 'CKBBooking/CKBBooking/PackageTypeDetailSearch', size: 'm' },
        autocomplete: { url: 'CKBBooking/CKBBooking/SearchPackageTypeDetailTerm', keyField: 'key', valueField: 'value' },
        context: {}
    });


    $.masterlookup.addSelector({
        name: 'ServiceActivitys',
        hasDialog: true,
        //getValueUrl: 'Billing/Search/GetBookingNumbers',
        dialog: { url: 'Admin/OperationsTemplate/ServiceActivitiesList', size: 'm' },
        //autocomplete: { url: 'Billing/Search/SearchBookingNumbersAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    
    $.masterlookup.addSelector({
        name: 'BookingServiceActivities',
        hasDialog: true,
        dialog: { url: 'Booking/Home/BookingServiceActivitiesList', size: 'm' },
        //autocomplete: { url: 'Billing/Search/SearchBookingNumbersAutocomplete', keyField: 'key', valueField: 'value' },
        context: {}
    });
    
    $.masterlookup.addSelector({
        name: 'AddressType',
        hasDialog: true,
        getValueUrl: 'Masters/AddressType/GetAddressTypeById',
        dialog: { url: 'Masters/AddressType/AddressTypeSearch', size: 'm' },
        autocomplete: { url: 'Masters/AddressType/SearchAddressType', keyField: 'key', valueField: 'value' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'Reason1',
        hasDialog: true,
        dialog: { url: 'Masters/Reason/GetReasonSearchView', size: 'm' },
        autocomplete: { url: 'Masters/Reason/SearchReasonsAutocomplete', keyField: 'key', valueField: 'value' },
        context: { ReasonType: 'Amend' }
    });
    $.masterlookup.addSelector({
        name: 'BookingStatusReason',
        hasDialog: true,
        dialog: { url: 'Masters/Reason/GetReasonSearchView', size: 'm' },
        autocomplete: { url: 'Masters/Reason/SearchReasonsAutocomplete', keyField: 'key', valueField: 'value' },
        context: { }
    });

    $.masterlookup.addSelector({
        name: 'BookingRevalidate',
        hasDialog: true,
        getValueUrl: 'CKBBooking/CKBBooking/GetBookingNumbersForRevalidateBooking',
        dialog: { url: 'CKBBooking/CKBBooking/BookingNumbersSearchForRevalidate', size: 'm' },
        autocomplete: { url: 'CKBBooking/CKBBooking/SearchBookingNumbersAutocompleteForRelavidateBooking', keyField: 'key', valueField: 'value' },
        context: {}
    });
    
    $.masterlookup.addSelector({
        name: 'PickupAddress',
        hasDialog: true,
        dialog: { url: 'Masters/Party/PartySearch', size: 'm' },
        autocomplete: { url: 'Masters/Party/SearchPartiesWithClientOffice', keyField: 'key', valueField: 'value' },
        context: { PartyType: 'Pickup Address' }
    });
    
    $.masterlookup.addSelector({
        name: 'PartyMultiSearch',
        hasDialog: true,
        getValueUrl: 'Masters/Party/GetPartyNameById',
        dialog: { url: 'Masters/Party/PartyMultiSearch', size: 'm' },
        context: {}
    });
    $.masterlookup.addSelector({
        name: 'ProductMultiSearch',
        hasDialog: true,
        getValueUrl: 'Masters/Product/GetProductNameById',
        dialog: { url: 'Masters/Product/ProductMultiSearch', size: 'm' },
        context: {}
    });

});
function split(val) {
    return val.split(/,\s*/);
}

function splitIds(val) {
	if(val != "")
		return val.split(",");
}

function extractLast(multiSelect, term) {
    if (multiSelect)
        return split(term).pop();
    else
        return term;


}
