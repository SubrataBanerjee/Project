﻿/// <reference path="jquery.jqGrid.min.js" />
(function ($) {
    $.mastersSearchIndex = $.mastersSearchIndex || {};

    $.fn.mastersSearchIndex = function (options) {
        if (this.length == 0)
            return this;

        if (this.length > 1) {
            this.each(function () {
                $(this).mastersSearchIndex(options);
            });
            return this;
        }

        // If a layout manager is already associated return the layout manaager
        var mastersSearchIndex = $.data(this[0], 'mastersSearchIndex');
        if (mastersSearchIndex) {
            return mastersSearchIndex;
        }

        mastersSearchIndex = new $.mastersSearchIndex(options, this[0]);
        $.data(this[0], 'mastersSearchIndex', mastersSearchIndex);

        return mastersSearchIndex;
    };

    // Constructor for layoutmanager
    $.mastersSearchIndex = function (options, element) {
        this.settings = $.extend(true, {}, $.mastersSearchIndex.defaults, options);
        this.containingDiv = element;

        this.init();
    };

    $.extend($.mastersSearchIndex, {
        defaults: {
            jqGridId: '#list',
            statusField: "Status",
            infoField: "Code",
            toggleActiveActionUrl: "",
            itemViewUrl: "",
            getDetailsUrl: "",
            enableText: "Enable",
            disableText: "Disable",
            questionText: $.common.resourceMaster.resourceMasterConfirmation,
            failMessageText: $.common.resourceMaster.resourceFailMessage,
            columnNames: [],
            columnModel: []
           
        },
        prototype: {
            setDefaults: function (settings) {
                $.extend(this.settings, settings);
            },
            performLinkAction: function (rowId) {
                var rowData = $(this.settings.jqGridId).jqGrid().getRowData(rowId);
                var id = rowData.Id;
                var action = $(rowData[this.settings.statusField]).html();
                var answer = confirm(this.settings.questionText.f(action, rowData[this.settings.infoField]));
                var indexFunctions = this;
                if (answer) {
                    $.ajax(this.settings.toggleActiveActionUrl, {
                        data: {
                            itemId: id
                        },
                        dataType: 'json',
                        type: 'POST',
                        success: function (data) {
                            var resultText;
                            if (action == indexFunctions.settings.enableText)
                                resultText = '1';
                            else
                                resultText = '0';
                            if (data.success) {
                                $(indexFunctions.settings.jqGridId).jqGrid().setCell(rowId, indexFunctions.settings.statusField, resultText);
                                if (indexFunctions.settings.contentDivId != null && indexFunctions.settings.contentDivId != '')
                                    $(indexFunctions.settings.contentDivId).searchfilter().executeSearch();
                            }
                            else
                                alert(indexFunctions.settings.failMessageText.f(action, rowData[indexFunctions.settings.infoField]));
                        }
                    });
                }
                return false;
            },
            init: function () {
                var gridFunctions = this;
                $(this.settings.jqGridId).jqGrid(Henkel.addDefaultJqGridOptions({
                    url: this.settings.getDetailsUrl,
                    datatype: 'local',
                    mtype: 'POST',
                    ajaxGridOptions: { contentType: "application/json" },
                    colNames: this.settings.columnNames,
                    colModel: this.settings.columnModel,
                    pager: $('#pager'),
                    onPaging: function () {
                        if (gridFunctions.settings.gridDiv != "") {
                            var nextPg = $('#' + gridFunctions.settings.gridDiv).getGridParam("page");
                            var lastPg = $('#' + gridFunctions.settings.gridDiv).getGridParam("lastpage");
                            if (nextPg > lastPg) {
                                return 'stop';
                            }
                        }
                    },
                    cmTemplate: { title: false },
                    gridComplete: function () {
                        checkGridRows(gridFunctions.settings.mainDiv, gridFunctions.settings.gridDiv, $.common.GridMessage.noRecordsFound);
                    }
                }));
            }
        }
    });

})(jQuery);

