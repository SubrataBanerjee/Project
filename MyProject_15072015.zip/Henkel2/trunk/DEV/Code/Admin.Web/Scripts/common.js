var Henkel = Henkel ? Henkel : new Object(); // Henkel object created

Henkel = function () {

    var placeholder = function () {
        $('[placeholder]').focus(function () {
            var input = $(this);
            if (input.val() == input.attr('placeholder')) {
                input.val('');
                input.removeClass('placeholder');
            }
        }).blur(function () {
            var input = $(this);
            if (input.val() == '' || input.val() == input.attr('placeholder')) {
                input.addClass('placeholder');
                input.val(input.attr('placeholder'));
            }
        }).blur();

        $('[placeholder]').parents('form').submit(function () {
            $(this).find('[placeholder]').each(function () {
                var input = $(this);
                if (input.val() == input.attr('placeholder')) {
                    input.val('');
                }
            });
        });
    };

    var addAnother = function () {
        $('.portlet a.addanother').live('click', function () {
            $(this).siblings('ul.editable').each(function () {
                ul = $(this);
                newid = (ul.find('li').length) / 2;
                ul.find('li.template').each(function () {
                    row = $(this).clone(true);
                    row.find('*').andSelf().each(function () {
                        if (id = $(this).attr('id')) {
                            $(this).attr('id', id.replace(/0/, newid));
                        }
                    });
                    row.removeClass('template');
                    row.addClass('new');
                    row.appendTo(ul);
                });
            });
            $(this).hide();
            return false;
        });
        portletSave(); portletCancel(); portletListEdit(); portletListRemove();
    };

    var portletSave = function () {
        $('.inline a.save').click(function () {
            rowtype = $(this).closest('li').attr('id').split('-')[0];
            rownum = $(this).closest('li').attr('id').split('-')[1];
            $('#' + rowtype + '-' + rownum).find('a.edit').show().end().find('a.remove').show();
            $(this).closest('li').find(':input').each(function () {
                fieldclass = $(this).attr('id').split('-')[0];
                fieldvalue = $(this).val();
                $('#' + rowtype + '-' + rownum + ' .' + fieldclass).html(fieldvalue);
            });
            $(this).closest('li').find('input[type="checkbox"]').each(function () {
                fieldclass = $(this).attr('id').split('-')[0];
                if ($(this).is(':checked')) {
                    fieldvalue = $(this).attr('onvalue');
                }
                else {
                    fieldvalue = $(this).attr('offvalue');
                }
                $('#' + rowtype + '-' + rownum + ' .' + fieldclass).html(fieldvalue);
            });
            $(this).closest('li').removeClass('new').hide();
            $('#' + rowtype + '-' + rownum).removeClass('new').show();
            $(this).closest('ul').siblings('a.addanother').show();
            //$('html,body').animate({ scrollTop: $(this).closest('div.editsection').find('a.addanother').show().offset().top }, { duration: 'slow', easing: 'swing'});
            //zebrastripe("table tr.details");
            return false;
        });
    };

    var portletCancel = function () {
        $('.inline a.cancel').click(function () {
            rowtype = $(this).closest('li').attr('id').split('-')[0];
            rownum = $(this).closest('li').attr('id').split('-')[1];
            $('#' + rowtype + '-' + rownum).find('a.edit').show().end().find('a.remove').show();
            $(this).closest('li').hide();
            $(this).closest('ul').siblings('a.addanother').show();
            return false;
        });
    };

    var portletListRemove = function () {
        $('.details a.remove, .masterDelete, .delete').click(function () {
            if (confirm('Are you sure you want to Delete')) {
                if ($(this).parent().get(0).tagName == 'TD') {
                    $(this).closest('tr').remove();
                    return true;
                }
                else {
                    rowid = $(this).closest('li').attr('id');
                    $('#' + rowid + '-editable').remove();
                    $('#' + rowid).remove();
                    return true;
                }
            }
            else
                return false;
        });
    };

    var portletListEdit = function () {
        $('.details a.edit').click(function () {
            rowid = $(this).closest('li').attr('id');
            $('#' + rowid + '-editable').show().find('a.save').focus();
            $(this).hide();
            $(this).closest('li').find('a.remove').hide();

            $(this).closest('ul').siblings('a.addanother').hide();
            return false;
        });
    };

    var markComplete = {
        inputClick: function () {
            $(".portlet .content input").click(function () {
                if ($(this).attr('type') == 'checkbox') {
                    $(this).parent().toggleClass("complete");
                    if ($(this).closest("ul").children("li").hasClass("complete")) {
                        $(this).closest(".portlet").find("header .toggleComplete").show();
                    }
                    else {
                        $(this).closest(".portlet").find("header .toggleComplete").hide();
                    }
                }
            });
            return this;
        },
        toggleText: function () {
            $(".toggleComplete").click(function (event) {
                var text = $(this).text() == 'Show completed' ? 'Hide completed' : 'Show completed';
                $(this).closest('header').next().find('.complete').toggle();
                $(this).text(text);
                event.stopPropagation(event);
            });
            return this;
        },
        onloadChk: function () {
            if (($('.accordionSB .active').next().is(':visible')) && ($('.accordionSB .active').next().find("ul").children("li").hasClass("complete"))) {
                $('.accordionSB .active').find(".toggleComplete").show();
            }
            else {
                $('.accordionSB .active').find(".toggleComplete").hide();
            }
            return this;
        }
    };

    var accordion = {
        toggleSec: function () {
            $('header.pgSecHdr').live('click', function () {
                var container = $(this).closest('.accordion');
                //alert(container.html())
                if ($(this).next().is(':hidden')) {
                    $(container).find('header.pgSecHdr').removeClass('active').next().slideUp();
                    $(this).addClass('active').next().slideDown('fast');
                }
                return false;
            });
            return this;
        },
        togglePin: function () {
            $("header .iconBS-pin, header .iconBS-unpin").live('click', function () {
                var title = ($(this).attr('title') == 'Pin this section') ? 'Unpin this section' : 'Pin this section';
                $(this).toggleClass('iconBS-pin').toggleClass('iconBS-unpin');
                $(this).attr('title', title);
                $(this).closest('header').toggleClass("pgSecHdr");
                var container = $(this).closest('.accordion');
                var activeLen = $(container).find('header.active').length;
                if (activeLen > 1) {
                    $(container).find('header.pgSecHdr').removeClass('active').next().slideUp();
                    $(this).addClass('active').next().slideDown('fast');
                }
            });
            return this;
        }
    };

    var secEdit = function () {
        $(".secEdit").click(function (event) {
            var container = $(this).closest("section");
            $(this).hide();
            container.find(".view").hide();
            container.find(".edit").fadeIn('medium');
            event.stopPropagation(event);
        });
    };

    var secEditSave = function () {
        $(".edit .secSave, .edit .secCancel").click(function () {
            var container = $(this).closest("section");
            container.find(".edit").hide();
            container.find(".view, .secEdit").fadeIn('medium');
        });
    };

    var modalWin = function (url, popsize) {
        //select all the a tag with name equal to modal
        $('a[href=#dialog], a[href=#dialogIn]').live('click', function (e) {

            e.preventDefault(); 	//Cancel the link behavior

            //Get the A & REL tag
            var id = $(this).attr('href');
            //var popSize = $(this).attr('rel');

            if ($.browser.msie && parseInt($.browser.version, 10) === 7) {//IE7 issue understanding 'href' attribute
                if ($(this).hasClass('dialogIn')) id = '#dialogIn';
            }

            //force browser to go to the top of your page
            //	if ($.browser.mozilla)$('html, body').animate({ scrollTop: 0 }, 0);
            //	else $('html, body').animate({ scrollTop: 0 }, 0);

            $(id).addClass(popsize); //set Popup size

            var maskHeight = $(document).height(); //Get the screen height and width
            var maskWidth = $(window).width();

            //Set heigth and width to mask to fill up the whole screen
            $('#mask, #maskIn').css({ 'width': maskWidth, 'height': maskHeight });

            //transition effect		
            if ($(this).hasClass("dialogIn")) {//If another dialog is opened add new mask and change dialog z-index
                $('#maskIn').show(100);
                $('#maskIn').show().fadeTo("medium", 0.6);
                $(id).addClass('zIndex');
            }
            else {
                $('#mask').show(100);
                $('#mask').show(100).fadeTo("medium", 0.6);
            }

            //transition effect
            $(id).fadeIn(300).addClass('loading');

            //dynamically populate content
            if ($(this).hasClass("dialogIn")) {//This is required for IE as IE keeps innner Popup blank
                $(id).load(url, function () {
                    $(id).removeClass('loading');
                });
            }
            else {
                $(id).load(url, function () {
                    $(id).removeClass('loading');
                });
            }

            //Get the window height and width
            var winH = $(window).height();
            var winW = $(window).width();
            //Set the popup window to center
            setTimeout(function () {
                $(id).css('top', winH / 2 - $(id).height() / 2 + $(document).scrollTop());
            }, 100);
            $(id).css('left', winW / 2 - $(id).width() / 2);

            //$(id).css({
            //position:'absolute',	//	left: ($(window).width() - $(id).width())/2,	//	top: ($(window).height() - $(id).height())/2
            //});	
        });

        //if close, save and cancel button is clicked
        $('.window .close, .window .save, .window .cancel').live('click', function (e) {
            e.preventDefault(); //Cancel the link behavior
            if ($(this).hasClass("dialogIn")) {//If inner dialog and mask is opened hide second mask
                $('#maskIn').hide(100); //Get popup div and hide
                $('#dialogIn').html("").removeClass('s m l').hide(100);
            }
            else {
                $('#mask').hide(100);
                $('#dialog').html("").removeClass('s m l').hide(100);
            }
        });

        //if mask is clicked
        //	$('#mask, #maskIn').live('click', function () {
        //			$(this).hide(100);
        //			if(($(this).attr('id'))=='maskIn'){
        //				$('#dialogIn').html("").removeClass('s m l').hide(100);
        //			}
        //			else{
        //				$('#dialog').html("").removeClass('s m l').hide(100);
        //			}
        //		});		
    };

    var secOptIcon = function () {
        $(".iconBS-options").hover(
			function () {
			    $(this).addClass("hover");
			    var menuID = "#" + $(this).attr("data-rel");
			    $(menuID).attr("fadeout", "false");
			    $(menuID).css({
			        width: 'auto',
			        lineHeight: '15px'
			    });
			    $(menuID).fadeIn(300); //$(menuID).css("top", $(this).position().top + 25);//$(menuID).css("left", $(this).position().left);
			},
			function () {
			    var menuID = "#" + $(this).attr("data-rel");
			    $(menuID).attr("fadeout", "true");
			    setTimeout(function () { if ($(menuID).attr("fadeout") == "true") /* $(menuID).fadeOut() */; }, 100);
			}
		);
    };

    var secOptMenu = function () {
        $('.addMenu_list').hover(
			function (e) {
			    menuID = "#" + $(this).attr('id');
			    $(menuID).show();
			    e.stopPropagation(); // To stop all events attached to this elem
			    return false; 		// This should not be used unless you do not want any click events registering inside the div
			},
			function () {
			    $(menuID).fadeOut(100);
			    $(".iconBS-options").removeClass('hover');
			}
		);
    };

    var pgSummaryView = function () {//Can be removed when implementing dynamically

        $(".sumEdit").click(function () {
            $(this).hide().next().show();
            $(this).parent().next().hide();
            $(this).parent().closest('li').find('input, select').fadeIn('medium');
        });

        $(".sumSave, .sumCancel").click(function () {
            $(this).parent().hide().prev().show();
            $(this).parent().closest('li').find('input, select').hide();
            $(this).parent().parent().next().fadeIn('medium');
        });

    };

    // Chrome menu for User and Office Starts
    var cssdropdown = {
        disappeardelay: 500, //set delay in miliseconds before menu disappears onmouseout
        dropdownindicator: '<span class=chromednarrow></span>', //specify full HTML to add to end of each menu item with a drop down menu
        enablereveal: [true, 5], //enable swipe effect? [true/false, steps (Number of animation steps. Integer between 1-20. Smaller=faster)]
        enableiframeshim: 0, //enable "iframe shim" in IE5.5 to IE7? (1=yes, 0=no)

        //No need to edit beyond here////////////////////////
        dropmenuobj: null, asscmenuitem: null, domsupport: document.all || document.getElementById, standardbody: null, iframeshimadded: false, revealtimers: {},

        getposOffset: function (what, offsettype) {
            var totaloffset = (offsettype == "left") ? what.offsetLeft : what.offsetTop;
            var parentEl = what.offsetParent;
            while (parentEl != null) {
                totaloffset = (offsettype == "left") ? totaloffset + parentEl.offsetLeft : totaloffset + parentEl.offsetTop;
                parentEl = parentEl.offsetParent;
            }
            return totaloffset;
        },

        css: function (el, targetclass, action) {
            var needle = new RegExp("(^|\\s+)" + targetclass + "($|\\s+)", "ig");
            if (action == "check")
                return needle.test(el.className);
            else if (action == "remove masterDelete")
                el.className = el.className.replace(needle, "");
            else if (action == "add" && !needle.test(el.className))
                el.className += " " + targetclass;
        },

        showmenu: function (dropmenu, e) {
            if (this.enablereveal[0]) {
                if (!dropmenu._trueheight || dropmenu._trueheight < 10)
                    dropmenu._trueheight = dropmenu.offsetHeight;
                clearTimeout(this.revealtimers[dropmenu.id]);
                dropmenu.style.height = dropmenu._curheight = 0;
                dropmenu.style.overflow = "hidden";
                dropmenu.style.visibility = "visible";
                this.revealtimers[dropmenu.id] = setInterval(function () { cssdropdown.revealmenu(dropmenu); }, 10);
            }
            else {
                dropmenu.style.visibility = "visible";
            }
            this.css(this.asscmenuitem, "selected", "add");
        },

        revealmenu: function (dropmenu, dir) {
            var curH = dropmenu._curheight, maxH = dropmenu._trueheight, steps = this.enablereveal[1];
            if (curH < maxH) {
                var newH = Math.min(curH, maxH);
                dropmenu.style.height = newH + "px";
                dropmenu._curheight = newH + Math.round((maxH - newH) / steps) + 1;
            }
            else { //if done revealing menu
                dropmenu.style.height = "auto";
                dropmenu.style.overflow = "hidden";
                clearInterval(this.revealtimers[dropmenu.id]);
            }
        },

        clearbrowseredge: function (obj, whichedge) {
            var edgeoffset = 0;
            if (whichedge == "rightedge") {
                var windowedge = document.all && !window.opera ? this.standardbody.scrollLeft + this.standardbody.clientWidth - 15 : window.pageXOffset + window.innerWidth - 15;
                var dropmenuW = this.dropmenuobj.offsetWidth;
                if (windowedge - this.dropmenuobj.x < dropmenuW)  //move menu to the left?
                    edgeoffset = dropmenuW - obj.offsetWidth;
            }
            else {
                var topedge = document.all && !window.opera ? this.standardbody.scrollTop : window.pageYOffset;
                var windowedge = document.all && !window.opera ? this.standardbody.scrollTop + this.standardbody.clientHeight - 15 : window.pageYOffset + window.innerHeight - 18;
                var dropmenuH = this.dropmenuobj._trueheight;
                if (windowedge - this.dropmenuobj.y < dropmenuH) { //move up?
                    edgeoffset = dropmenuH + obj.offsetHeight;
                    if ((this.dropmenuobj.y - topedge) < dropmenuH) //up no good either?
                        edgeoffset = this.dropmenuobj.y + obj.offsetHeight - topedge;
                }
            }
            return edgeoffset;
        },

        dropit: function (obj, e, dropmenuID) {
            if (this.dropmenuobj != null) //hide previous menu
                this.hidemenu(); //hide menu
            this.clearhidemenu();
            this.dropmenuobj = document.getElementById(dropmenuID); //reference drop down menu
            this.asscmenuitem = obj; //reference associated menu item
            this.showmenu(this.dropmenuobj, e);
            this.dropmenuobj.x = this.getposOffset(obj, "left");
            this.dropmenuobj.y = this.getposOffset(obj, "top");
            this.dropmenuobj.style.left = this.dropmenuobj.x - this.clearbrowseredge(obj, "rightedge") + "px";
            this.dropmenuobj.style.top = this.dropmenuobj.y - this.clearbrowseredge(obj, "bottomedge") + obj.offsetHeight + 13 + "px"; //Edited by Ashok '1' to '12'
            this.positionshim(); //call iframe shim function
        },

        positionshim: function () { //display iframe shim function
            if (this.iframeshimadded) {
                if (this.dropmenuobj.style.visibility == "visible") {
                    this.shimobject.style.width = this.dropmenuobj.offsetWidth + "px";
                    this.shimobject.style.height = this.dropmenuobj._trueheight + "px";
                    this.shimobject.style.left = parseInt(this.dropmenuobj.style.left) + "px";
                    this.shimobject.style.top = parseInt(this.dropmenuobj.style.top) + "px";
                    this.shimobject.style.display = "block";
                }
            }
        },

        hideshim: function () {
            if (this.iframeshimadded)
                this.shimobject.style.display = 'none';
        },

        isContained: function (m, e) {
            var e = window.event || e;
            var c = e.relatedTarget || ((e.type == "mouseover") ? e.fromElement : e.toElement);
            while (c && c != m) try { c = c.parentNode; } catch (e) { c = m; }
            if (c == m)
                return true;
            else
                return false;
        },

        dynamichide: function (m, e) {
            if (!this.isContained(m, e)) {
                this.delayhidemenu();
            }
        },

        delayhidemenu: function () {
            this.delayhide = setTimeout("Henkel.cssdropdown.hidemenu()", this.disappeardelay); //hide menu
        },

        hidemenu: function () {
            this.css(this.asscmenuitem, "selected", "remove masterDelete");
            this.dropmenuobj.style.visibility = 'hidden';
            this.dropmenuobj.style.left = this.dropmenuobj.style.top = "-1000px";
            this.hideshim();
        },

        clearhidemenu: function () {
            if (this.delayhide != "undefined")
                clearTimeout(this.delayhide);
        },

        addEvent: function (target, functionref, tasktype) {
            if (target.addEventListener)
                target.addEventListener(tasktype, functionref, false);
            else if (target.attachEvent)
                target.attachEvent('on' + tasktype, function () { return functionref.call(target, window.event); });
        },

        startchrome: function () {
            if (!this.domsupport)
                return;
            this.standardbody = (document.compatMode == "CSS1Compat") ? document.documentElement : document.body;
            for (var ids = 0; ids < arguments.length; ids++) {
                if (document.getElementById(arguments[ids])) {
                    var menuitems = document.getElementById(arguments[ids]).getElementsByTagName("a");
                }
                else {
                    menuitems = 0;
                }
                for (var i = 0; i < menuitems.length; i++) {
                    if (menuitems[i].getAttribute("data-rel")) {
                        var relvalue = menuitems[i].getAttribute("data-rel");
                        var asscdropdownmenu = document.getElementById(relvalue);
                        this.addEvent(asscdropdownmenu, function () { cssdropdown.clearhidemenu(); }, "mouseover");
                        this.addEvent(asscdropdownmenu, function (e) { cssdropdown.dynamichide(this, e); }, "mouseout");
                        this.addEvent(asscdropdownmenu, function () { cssdropdown.delayhidemenu(); }, "click");
                        try {
                            menuitems[i].innerHTML = menuitems[i].innerHTML + " " + this.dropdownindicator;
                        } catch (e) { }
                        this.addEvent(menuitems[i], function (e) { //show drop down menu when main menu items are mouse over-ed
                            if (!cssdropdown.isContained(this, e)) {
                                var evtobj = window.event || e;
                                cssdropdown.dropit(this, evtobj, this.getAttribute("data-rel"));
                            }
                        }, "mouseover");
                        this.addEvent(menuitems[i], function (e) { cssdropdown.dynamichide(this, e); }, "mouseout"); //hide drop down menu when main menu items are mouse out
                        this.addEvent(menuitems[i], function () { cssdropdown.delayhidemenu(); }, "click"); //hide drop down menu when main menu items are clicked on
                    }
                } //end inner for
            } //end outer for
            if (this.enableiframeshim && document.all && !window.XDomainRequest && !this.iframeshimadded) { //enable iframe shim in IE5.5 thru IE7?
                document.write('<IFRAME id="iframeshim" src="about:blank" frameBorder="0" scrolling="no" style="left:0; top:0; position:absolute; display:none;z-index:90; background: transparent;"></IFRAME>');
                this.shimobject = document.getElementById("iframeshim"); //reference iframe object
                this.shimobject.style.filter = 'progid:DXImageTransform.Microsoft.Alpha(style=0,opacity=0)';
                this.iframeshimadded = true;
            }
        } //end startchrome
    }; // Chrome menu for User and Office ends

    var init = function () {
        placeholder();
        addAnother();
        accordion.toggleSec(); accordion.togglePin();
        secEdit(); secEditSave();
        secOptIcon(); secOptMenu();
        markComplete.inputClick(); markComplete.toggleText(); markComplete.onloadChk();
        pgSummaryView();
    };

    return {
        init: init,
        modalWin: modalWin,
        cssdropdown: cssdropdown,
        placeholder: placeholder
    };
} ();

Henkel.master = Henkel.master ? Henkel.master : new Object();

Henkel.master = function () {

    var searchFilterAdd = function () {
        $(".filter").live('click', function () {
            if ($(this).hasClass('add')) {
                $(this).closest(".btnPnl").prev().show();
            };
            if ($(this).hasClass('remove')) {
                $(this).closest("fieldset").hide();
            };
        });
    };

    var masterStatus = function () {
        $(".masterStatus").click(function () {
            var masterID = $(this).closest('tr').children(":nth-child(2)").text();
            var newStatus = $(this).text();
            var curStatus = $(this).parent().prev().text();
            if (confirm('Are you sure you want to "' + newStatus + '" Master ID:' + masterID)) {
                $(this).text(curStatus);
                $(this).parent().prev().text(newStatus);
            }
        });
    };

    var masterURLGet = function () {
        if ($("h1 span").hasClass("secHd")) {
            var getURL = window.location.href;
            URLsplit = getURL.split("?");
            $("h1 .secHd").html("&gt; " + URLsplit[1].replace(/%20/gi, ' '));
            $("h1 .secItem").html("&gt; " + URLsplit[2].replace(/%20/gi, ' ').replace("#", ""));
        }
    };

    var init = function () {
        searchFilterAdd();
        masterStatus();
    };

    return {
        init: init
    };

} ();

		
jQuery(document).ready(function ($) {
	Henkel.init();
	Henkel.cssdropdown.startchrome("chromemenu");
	Henkel.master.init();
	Henkel.booking.init();
	
	//Events to activate on click of DOM
	$(document).click(function() {
		
		//If Portlet dropdown option visible
		if( $('.addMenu_list').is(':visible')) {
			$('.addMenu_list').fadeOut(100);
			$(".addMenu").removeClass('hover');
		}
		
    });
	
	//progress-bar integration
	$(".progress").each(function() {
        var progressValue = $(this).data("value");
        $(this).progressbar({
            value: progressValue
        }).children("span").appendTo(this);
    });
	
	$("input#autocomplete").autocomplete({
    		source: ["c++", "java", "php", "coldfusion", "javascript", "asp", "ruby"]
	});
	
});


// Set browser cookie
function setCookiefromHome(c_name, officevalue, exdays) {
    window.top.name = officevalue;
	history.go(0);
}

