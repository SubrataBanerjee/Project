﻿//duplicate message as common message.
var validatefieldrequiredMsg = "This field is mandatory.";
var validatecodeAlreadyExistvalidateMsg = "The entered code already exists. Please enter another code.";
var validatecodeAlreadyExistMastersMsg = "The entered code already exists. Please enter another code.";
var validatecommonErrorMessageMsg = "There is some problem while processing this request.";
var validatephoneNumberMsg = "Phone number should contain only numbers.";
var validateemailMsg = "Please enter a valid email address.";
var validateerrorCloseButtonMsg = "<span title='Close' class='iconBS-delete' onClick='$(this).parent().fadeOut();'></span>";
var validateerrorMsg = "<strong>Error!</strong> ";

$.common = {
    messages: {
        required: "This field is mandatory.",
        fieldrequired: "This field is mandatory.",
        email: "Please enter a valid email address.",
        date: "Please enter a valid date.",
        number: "Please enter a valid number.",
        digits: "Please enter only digits.",
        maxlength: "Please enter no more than {0} characters.",
        minlength: "Please enter at least {0} characters.",
        rangelength: "Please enter a value between {0} and {1} characters long.",
        range: "Please enter a value between {0} and {1}.",
        max: "Please enter a value less than or equal to {0}.",
        min: "Please enter a value greater than or equal to {0}.",
        invalidValue: "The value entered is invalid.",
        greaterThan: "The value entered should be greater than {0}",
        greaterThanEqual: "The value entered should be greater than or equal to {0}.",
        lessThanEqual: "The value entered should be less than or equal to {0}.",
        cannotEmpty: "The value entered in {0} cannot be empty.",
        invalidPassword: "The password you have entered is invalid. Please enter a valid password.",
        passWordPolicyError: "Password Policy Error.",
        error: "Error",
        errorWithExclamation: "Error!",
        passwordNoMatch: "The value entered for new and re-confirm passwords does not match.",
        fileNotFound: "No file was uploaded.",
        exceedFileSize: "The size of the file you want to upload should not exceed {0} KB.",
        sucessFileUpload: "The file has been uploaded successfully.",
        invalidLogin: "Invalid Login. Please try again with valid username and password.",
        unlockSuccess: "User has been unlocked successfully.",
        UnlockUserConfirmation: "Are you sure you want to unlock the selected user?",
        Start: "Start",
        errorprocessingRequest: validatecommonErrorMessageMsg
    },
    general: {
        ignore: "Ignore",
        select: "Select",
        Error: validateerrorMsg,
        Errors: " error(s) ",
        AddCriteria: "Add Criteria",
        From: "From",
        To: "To",
        days: "days"
    },
    generalMessages: {
        codeExists: validatecodeAlreadyExistvalidateMsg,
        codeAlreadyExist: validatecodeAlreadyExistvalidateMsg,
        error: validateerrorMsg,
        canNotPerformOperation: "You are not authorized to perform this operation."
    },
    uploadMaster: {
        selectFile: "Please select {0} file to upload"
    },
    
    ajaxErrorMessage: "There is some problem while processing the request.",
    commonErrorExclamation: "Error!",
    errorCloseButton: validateerrorCloseButtonMsg,
    invalidInput: "Invalid Html.",
    invalidInputOnlyNumeric: "Only numeric value is allowed.",
    invalidInputWhiteSpace: "Space is not allowed.",
    fieldRequired: validatefieldrequiredMsg,
    invalidDateFormat: "Please enter a valid date in the format {dd MMM yyyy}",
    Edit: "Edit"
};
