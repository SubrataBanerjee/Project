﻿$.searchfilterStrings = {
    Select: "Select",
    AddFilter: "Add filter",
    RemoveFilter: "Remove filter",
    Search: "Search",
    FilterSearchBys: "Filter Search By",
    FilterSearchBy: "Advance Search",
    AdvanceSearch: "Advance Search",
    StartTime: "Start Time",
    EndTime: "End Time"
};
