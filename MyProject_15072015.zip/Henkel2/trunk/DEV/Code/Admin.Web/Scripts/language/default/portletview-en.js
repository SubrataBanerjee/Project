﻿$.portletViews = {
    common : {
        deleteConfirmation: 'Are you sure you want to delete ?',
        Add: "Add",
        Edit: "Edit",
        HideCompleted: "Hide Completed",
        ShowCompleted: "Show Completed",
        Cancel: "Cancel",
        Save: "Save",
        Or : "or ",
        RequiredMessage: "This field is required",
        Negotiation: "Negotiation"
    },
    listView: {
        noRecordMessage: 'No Data Found'
    },
    gridView: {
        
    }
};


