﻿

using System.ComponentModel.DataAnnotations;
using System.Text.RegularExpressions;
namespace Henkel.Admin.Web.Validators
{
    public class XSSCheckAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            if (value != null)
            {
                Match match = Regex.Match(value.ToString(), "<[^>]+>");

                if (match.Success)
                {
                    return new ValidationResult(validationContext.DisplayName);
                }
            }
            return ValidationResult.Success;
        }
    }
}