﻿using FluentValidation;
using Henkel.Admin.Web.Models.Account;
using Henkel.Resources;

namespace Henkel.Admin.Web.Validators.Account
{
    public class LogonValidator : AbstractValidator<LogonModel>
    {
        public LogonValidator()
        {
            RuleFor(x => x.UserName).NotEmpty().WithMessage(Errors.Key_UserNameCanNotBeEmpty);
            RuleFor(x => x.Password).NotEmpty().WithMessage(Errors.Key_PasswordCanNotBeEmpty);
        }
    }
}
