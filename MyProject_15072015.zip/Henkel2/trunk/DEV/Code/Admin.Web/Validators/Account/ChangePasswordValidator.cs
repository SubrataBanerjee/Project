﻿using FluentValidation;
using Henkel.Admin.Web.Models.Account;
using Henkel.Resources;

namespace Henkel.Admin.Web.Validators.Account
{
    public class ChangePasswordValidator : AbstractValidator<ChangePasswordModel>
    {
        public ChangePasswordValidator()
        {
            RuleFor(x => x.OldPassword).NotEmpty().WithMessage(Errors.Key_ChangePassword_Fields_OldPassword_Required);
            RuleFor(x => x.NewPassword).NotEmpty().WithMessage(Errors.Key_ChangePassword_Fields_NewPassword_Required);
            RuleFor(x => x.ConfirmNewPassword).NotEmpty().WithMessage(Errors.Key_ChangePassword_Fields_ConfirmNewPassword_Required);
            RuleFor(x => x.ConfirmNewPassword).Equal(x => x.NewPassword).WithMessage(Errors.Key_ChangePassword_Fields_NewPassword_EnteredPasswordsDoNotMatch);
        }
    }
}
