﻿using System.Web.Mvc;

namespace Henkel.Admin.Web.Controllers
{
    public class HomeController : BaseController
    {
        #region Fields

        #endregion

        #region Constructors

        #endregion

        #region Actions

        #region Views

        public ActionResult IndexPage()
        {
            return View("Index");
        }

        public ActionResult UnAuthorized()
        {
            return View();
        }

        #endregion

        #region Ajax Commands

        #endregion

        #endregion

        
    }
}
