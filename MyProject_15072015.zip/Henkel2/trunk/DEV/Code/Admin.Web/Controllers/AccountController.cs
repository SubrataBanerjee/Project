﻿using Henkel.Admin.Web.Framework.Security;
using Henkel.Admin.Web.Models.Account;
using Henkel.Admin.Web.Utils;
using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Resources;
using System;
using System.Web.Mvc;
using System.Web.SessionState;

namespace Henkel.Admin.Web.Controllers
{
    [SessionState(SessionStateBehavior.Required)]
    public class AccountController : BaseController
    {
        #region Fields

        private readonly IUserAuthenticationService _userAuthenticationService;
        private readonly IUserManagementService _userManagementService;

        #endregion

        #region Ctor

        public AccountController()
        {
            this._userAuthenticationService = ObjectLocator.GetService<IUserAuthenticationService>();
            this._userManagementService = ObjectLocator.GetService<IUserManagementService>();
        }

        #endregion

        #region Login / logout

        [HttpGet]
        [AllowAnonymous2]
        public ActionResult Logon()
        {
            try
            {
                var model = new LogonModel();
                var customerInfoService = ObjectLocator.GetService<ICustomerManagementService>();

                AppContext.Current.GroupCompanyName = customerInfoService.GetGroupCompanyName();

                return View(model);
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(GetErrorResource(CoreErrorMessage.KeyErrorProcessingRequest));
            }
        }

        [HttpPost]
        [AllowAnonymous]
        public ActionResult Logon(LogonModel model, string returnUrl)
        {
            try
            {
                bool success = false;
                string errorMsg = string.Empty;

                // Server side validation
                if (!IsValidModelState(out errorMsg))
                    return Json(new { success = false, message = errorMsg }, JsonRequestBehavior.AllowGet);

                if (model.UserName != null)
                {
                    model.UserName = model.UserName.Trim();
                }
                UserToken logonResult = _userAuthenticationService.SignIn(model.UserName, model.Password, model.RememberMe);

                if (logonResult.SuccessLogin)
                {
                    var formAuthentication = new FormsAuthenticationService(Request.RequestContext.HttpContext);
                    formAuthentication.SignIn(logonResult, true);

                    success = true;

                    if (logonResult.ChangePwdOnLogin)
                        returnUrl = "../Account/ChangePassword";
                    else
                    {
                        if (String.IsNullOrWhiteSpace(returnUrl) || Url.IsLocalUrl(returnUrl))
                            returnUrl = "../Home/IndexPage";
                    }
                }
                else
                {
                    errorMsg = GetErrorResource(logonResult.ErrorMessage);
                }

                return Json(new { success = success, message = errorMsg, returnUrl = returnUrl });
            }
            catch (ValidationException ex)
            {
                return Json(new { success = false, message = GetErrorResource(ex.Message, ex.Args), returnUrl = returnUrl });
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                return Json(new { success = false, message = GetErrorResource(ex.Message), returnUrl = returnUrl });
            }
        }

        [AllowAnonymous]
        public ActionResult LogOff()
        {
            try
            {
                _userAuthenticationService.SignOut();
                var formAuthentication = new FormsAuthenticationService(Request.RequestContext.HttpContext);
                formAuthentication.SignOut();
            }
            catch (ValidationException ex)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(GetErrorResource(CoreErrorMessage.KeyErrorProcessingRequest));
            }
            
            return RedirectToAction("IndexPage", "Home");
        }

        #endregion

        #region My account

        #region Change password

        [Authorize]
        public ActionResult ChangePassword()
        {
            var model = new ChangePasswordModel();
            return View(model);
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {
                _userAuthenticationService.ChangePassword(AppContext.Current.UserId, model.NewPassword, model.OldPassword, model.ConfirmNewPassword);
                SuccessNotification(GlobalResources.ChangePassword_Success);
            }

            //If we got this far, something failed, redisplay form
            return View(model);
        }

        #endregion

        #endregion
    }
}
