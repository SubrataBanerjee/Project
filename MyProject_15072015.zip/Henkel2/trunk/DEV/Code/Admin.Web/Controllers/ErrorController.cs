﻿using System;
using System.Web.Mvc;

namespace Henkel.Admin.Web.Controllers
{
    [AllowAnonymous]
    public class ErrorController : Controller
    {
        public ActionResult Index(Exception exception, string controllerName, string actionName)
        {
            var model = GetErrorInfo(exception, controllerName, actionName);
            if (model == null)
                return View("Error");

            return View("Error", model);
        }

        public ActionResult HttpError404(Exception exception, string controllerName, string actionName)
        {
            var model = GetErrorInfo(exception, controllerName, actionName);
            if (model == null)
                return View("NotFound");
            return View("NotFound", model);
        }

        public ActionResult HttpError505(Exception exception, string controllerName, string actionName)
        {
            var model = GetErrorInfo(exception, controllerName, actionName);
            if (model == null)
                return View("Error");

            return View("Error", model);
        }

        private HandleErrorInfo GetErrorInfo(Exception ex, string controllerName, string actionName)
        {
            if (ex == null || string.IsNullOrEmpty(controllerName) || string.IsNullOrEmpty(actionName))
                return null;

            return new HandleErrorInfo(ex, controllerName, actionName);
        }
    }
}
