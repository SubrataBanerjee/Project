﻿using Henkel.Common.Core.Integration.Services.Impl;
using Henkel.Scheduler.Scheduling.Services;
using Henkel.Scheduler.Scheduling.Services.Quartz.Impl;
using Microsoft.Practices.Unity;

namespace Henkel.Scheduler.Scheduling.Integration
{
    public class SchedulingIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterServices(container);
        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<ISchedulingService, QuartzSchedulingService>(new ContainerControlledLifetimeManager());
        }
    }
}
