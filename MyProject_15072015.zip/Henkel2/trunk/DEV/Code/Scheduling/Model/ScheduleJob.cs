﻿using Henkel.Scheduler.Scheduling.Resources;
using System.Configuration;

namespace Henkel.Scheduler.Scheduling.Model
{
    public class ScheduleJob : ConfigurationElement
    {
        public ScheduleJob()
        {
        }

        public ScheduleJob(string name, string group, string cronExpresion, string jobType, string dependency)
        {
            Name = name;
            Group = group;
            CronExpression = cronExpresion;
            JobType = jobType;
            Dependency = dependency;
        }

        [ConfigurationProperty(ScheduleJobKey.Name, DefaultValue = "Job1", IsRequired = true)]
        public string Name
        {
            get { return this[ScheduleJobKey.Name] as string; }
            set { this[ScheduleJobKey.Name] = value; }
        }

        [ConfigurationProperty(ScheduleJobKey.Group, DefaultValue = "Group1", IsRequired = true)]
        public string Group
        {
            get { return this[ScheduleJobKey.Group] as string; }
            set { this[ScheduleJobKey.Group] = value; }
        }

        [ConfigurationProperty(ScheduleJobKey.CronExpression, DefaultValue = "0 * * * * ?", IsRequired = true)]
        public string CronExpression
        {
            get { return this[ScheduleJobKey.CronExpression] as string; }
            set { this[ScheduleJobKey.CronExpression] = value; }
        }

        [ConfigurationProperty(ScheduleJobKey.JobType, IsRequired = true)]
        public string JobType
        {
            get { return this[ScheduleJobKey.JobType] as string; }
            set { this[ScheduleJobKey.JobType] = value; }
        }

        [ConfigurationProperty(ScheduleJobKey.Dependency, IsRequired = false)]
        public string Dependency
        {
            get { return this[ScheduleJobKey.Dependency] as string; }
            set { this[ScheduleJobKey.Dependency] = value; }
        }
    }
}
