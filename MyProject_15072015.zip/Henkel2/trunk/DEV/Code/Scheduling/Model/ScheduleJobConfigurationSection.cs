﻿using System.Configuration;

namespace Henkel.Scheduler.Scheduling.Model
{
    public class ScheduleJobConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("ScheduleJobs", IsDefaultCollection = false)]
        [ConfigurationCollection(typeof(ScheduleJobCollection), AddItemName = "add")]
        public ScheduleJobCollection ScheduleJobs
        {
            get
            {
                return (ScheduleJobCollection)base["ScheduleJobs"];
            }
        }

        public static ScheduleJobConfigurationSection GetConfig()
        {
            return (ScheduleJobConfigurationSection)ConfigurationManager.GetSection("ScheduleJobSection") ?? new ScheduleJobConfigurationSection();
        }
    }
}
