﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.API.Utils;
using Henkel.Scheduler.Scheduling.Resources;
using Quartz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;

namespace Henkel.Scheduler.Scheduling.Services.Quartz.Jobs
{
    public class BaseJob
    {
        #region Constructor

        public BaseJob()
        {
            SessionFactory = ObjectLocator.GetObject<IRepositorySessionFactory>();
        }

        #endregion

        #region Property fields

        public IRepositorySessionFactory SessionFactory { get; set; }

        protected IRepositorySession RepositorySession
        {
            get
            {
                var session = SessionFactory.GetNewSession(true);
                return session;
            }
        }

        protected IRepositorySession RepositoryReadOnlySession
        {
            get
            {
                var session = SessionFactory.GetNewSession(false);
                return session;
            }
        }

        #endregion
        
        #region Protected Methods

        

        protected IEnumerable<Guid> GetDependentExtensionIds(IJobExecutionContext context)
        {
            var s = context.JobDetail.JobDataMap.Get(ScheduleJobKey.Dependency);
            var dependency = s == null ? string.Empty : s.ToString();
            return string.IsNullOrWhiteSpace(dependency)
                ? new List<Guid>()
                : dependency.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries).Select(x => new Guid(x)).ToList();
        }


        #endregion

        #region Public Methods

        public void SetThreadData()
        {
            ThreadUtils.SetThreadData(userName: "Scheduler-System");
        }

        public static bool IsAllowedExecution(long counter)
        {
            try
            {
                if (counter <= 1)
                    return true;

                string value = ConfigurationManager.AppSettings["ExecuteOnce"];
                if (string.IsNullOrWhiteSpace(value))
                    return true;

                return !Convert.ToBoolean(value);
            }
            catch (Exception)
            {
                return true;
            }
        }

        #endregion
    }
}
