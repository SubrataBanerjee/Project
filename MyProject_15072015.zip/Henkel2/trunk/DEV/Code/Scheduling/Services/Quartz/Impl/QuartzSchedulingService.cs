﻿using Henkel.Common.Core.API.Logging.Model;
using Henkel.Scheduler.Scheduling.Model;
using Henkel.Scheduler.Scheduling.Resources;
using Quartz;
using Quartz.Impl;
using Quartz.Impl.Triggers;
using System;

namespace Henkel.Scheduler.Scheduling.Services.Quartz.Impl
{
    public class QuartzSchedulingService : ISchedulingService
    {
        #region Fields

        private ISchedulerFactory _schedulerFactory;
        private IScheduler _scheduler;

        #endregion

        #region Implementation of ISchedulingService

        public void Start()
        {
            Logger.Info(GetType().Name, SchedulingInfoMessages.InitializingScheduler);
            try
            {
                _schedulerFactory = new StdSchedulerFactory();
                _scheduler = _schedulerFactory.GetScheduler();
                _scheduler.Start();
                RegisterTasks();
                
                Logger.Info(GetType().Name, SchedulingInfoMessages.SchedulerInitializationComplete);
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(SchedulingErrorMessages.ErrorOccuredToInitializeScheduler, ex));
                Stop();
            }
        }

        public void Stop()
        {
            Logger.Info(GetType().Name, SchedulingInfoMessages.StopingScheduler);
            if (!IsStopped)
                _scheduler.Shutdown();

            _scheduler = null;

            Logger.Info(GetType().Name, SchedulingInfoMessages.SuccessfullyStopedScheduler);
        }

        public bool IsStarted { get { return _scheduler != null && _scheduler.IsStarted; } }

        public bool IsStopped { get { return _scheduler == null || _scheduler.IsShutdown; } }

        #endregion

        #region Private Helper Methods

        private void RegisterTasks()
        {
            var typeName = GetType().Name;
            Logger.Info(typeName, SchedulingInfoMessages.StartingRegistrationForAllTasks);

            try
            {
                var scheduleJobs = ScheduleJobConfigurationSection.GetConfig().ScheduleJobs;
            
                Logger.Info(typeName, SchedulingInfoMessages.TotalTasksToRegisterGeneric1Args, scheduleJobs.Count);

                int count = 0;
                int totalTaskRegisters = 0;
            
                foreach (ScheduleJob job in scheduleJobs)
                {
                    count += 1;
                    Logger.Info(typeName, SchedulingInfoMessages.RegisteringTaskGeneric2Args, count, job.Name);

                    try
                    {
                        Type jobType = GetJobType(job);
                        if (jobType == null)
                            continue;

                        IJobDetail jobDetail = JobBuilder.Create(jobType)
                                .WithIdentity(job.Name, job.Group)
                                .Build();

                        jobDetail.JobDataMap.Add(ScheduleJobKey.Dependency, job.Dependency);

                        ITrigger trigger = new CronTriggerImpl(job.Name + "trigger", job.Group, job.CronExpression);

                        _scheduler.ScheduleJob(jobDetail, trigger);

                        Logger.Info(typeName, SchedulingInfoMessages.CompletedRegisteringTaskGeneric2Args, count, job.Name);
                        totalTaskRegisters += 1;
                    }
                    catch (Exception ex)
                    {
                        Logger.Exception(typeName, OperationStatus.CreateFromException(string.Format(SchedulingErrorMessages.FailedToRegisterTaskGeneric2Args, count, job.Name), ex));
                    }
                }

                Logger.Info(typeName, SchedulingInfoMessages.RegistrationCompletedForAllTasks);
                Logger.Info(typeName, SchedulingInfoMessages.TotalTaskRegisteredGeneric1Args, totalTaskRegisters);
            }
            catch (Exception)
            {
                Logger.Error(typeName, SchedulingErrorMessages.ErrorOccuredInTaskRegistration);
                throw;
            }
        }

        private Type GetJobType(ScheduleJob job)
        {
            try
            {
                return Type.GetType(job.JobType);
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(string.Format(SchedulingErrorMessages.ErrorToCreateTypeObjectForTaskGeneric2Args, job.Name, job.JobType), ex));
                return null;
            }
        }

        #endregion
    }
}
