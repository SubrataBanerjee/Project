﻿using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Scheduler.Scheduling.Resources;
using Quartz;
using System;

namespace Henkel.Scheduler.Scheduling.Services.Quartz.Jobs
{
    public class EmailDispatchingJob : BaseJob, IJob
    {
        #region fields

        static long _counter;

        #endregion

        #region Constructors

        //NOTE: Don't remove this constructor as this has been Invoked through Quartz Job Scheduler 
        public EmailDispatchingJob()
        {
            _counter += 1;
        }

        #endregion

        #region Implementation of IJob

        public void Execute(IJobExecutionContext context)
        {
            var typeName = GetType().Name;
            Logger.Info(typeName, SchedulingInfoMessages.StartExecutingMethodExecute);

            try
            {
                var emailDispatchingService = ObjectLocator.GetObject<IEmailDispatchingService>();

                //Must set thread data first as this has been used in every Repository session
                SetThreadData();
                Logger.Info(typeName, SchedulingInfoMessages.StartingExecutionJob);
                    
                using(var session = RepositorySession)
                {
                    try
                    {
                        emailDispatchingService.DispatchQueuedEmail();
                    }
                    catch(Exception ex)
                    {
                        session.Rollback();
                        Logger.Exception(typeName, OperationStatus.CreateFromException(SchedulingErrorMessages.ErrorOccuredToExecuteJob,ex));
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Exception(typeName, OperationStatus.CreateFromException(SchedulingErrorMessages.ErrorOccuredInMethodExecute, ex));
            }

            Logger.Info(typeName, SchedulingInfoMessages.FinishedExecutionOfMethodExecute);
        }

        #endregion
    }
}
