﻿using Henkel.Common.Core.API.Services;

namespace Henkel.Scheduler.Scheduling.Services
{
    public interface ISchedulingService : IBusinessService
    {
        void Start();
        void Stop();
        bool IsStarted { get; }
        bool IsStopped { get; }
    }
}
