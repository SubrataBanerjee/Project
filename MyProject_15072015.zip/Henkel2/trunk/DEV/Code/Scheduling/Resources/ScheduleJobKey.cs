﻿
namespace Henkel.Scheduler.Scheduling.Resources
{
    public static class ScheduleJobKey
    {
        public const string Name = "name";
        public const string Group = "group";
        public const string CronExpression = "cronExpression";
        public const string JobType = "jobType";
        public const string Dependency = "dependency";
    }
}
