﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Henkel.Common.SupportForTests.Utils
{
    public class TestHelperUtil
    {
        public static TException AssertThrows<TException>(Action action) where TException : Exception
        {
            try
            {
                action();
            }
            catch (TException ex)
            {
                return ex;
            }
            Assert.Fail("Expected exception was not thrown");

            return null;
        }
    }
}
