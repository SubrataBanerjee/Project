﻿using System.Collections.Generic;

namespace Henkel.Common.SupportForTests.Repository
{
    public class DatabaseInfo
    {
        public string XSDPath { get; set; }

        public IList<string> DataFiles { get; set; }

        public string ConnectionString { get; set; }

        public string DataPath
        {
            get
            {
                if (DataFiles.Count > 0)
                    return DataFiles[0];
                return null;
            }
            set
            {
                if (DataFiles.Count > 0)
                    DataFiles[0] = value;
                else
                    DataFiles.Add(value);
            }
        }

        public DatabaseInfo()
        {
            DataFiles = new List<string>();
        }

        protected bool Equals(DatabaseInfo other)
        {
            bool equal = string.Equals(XSDPath, other.XSDPath);
            if (!equal)
                return false;

            return true;
        }

        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != this.GetType()) return false;
            return Equals((DatabaseInfo)obj);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return ((DataFiles != null ? DataFiles.GetHashCode() : 0) * 397) ^ (XSDPath != null ? XSDPath.GetHashCode() : 0);
            }
        }
    }
}
