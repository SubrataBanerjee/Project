﻿using Henkel.Common.Core.API.Locator;

namespace Henkel.Common.SupportForTests.Repository.EntityFramework
{
    public abstract class RequireEFDatabaseSupport : RequireDatabaseSupport
    {
        public RequireEFDatabaseSupport()
            : base(ObjectResolverType.Composite)
        {
        }

        protected override string[] CustomUnityConfigs
        {
            get { return null; }
        }
    }
}
