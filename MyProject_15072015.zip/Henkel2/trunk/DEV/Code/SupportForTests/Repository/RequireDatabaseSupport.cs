﻿using Henkel.Common.Core.API.Integration.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.SupportForTests.Attributes;
using Henkel.Common.SupportForTests.Model;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NDbUnit.Core;
using NDbUnit.Core.SqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Reflection;

namespace Henkel.Common.SupportForTests.Repository
{
    public abstract class RequireDatabaseSupport : BaseTest
    {
        private INDbUnitTest _mySqlDatabase;

        protected IRepositorySessionFactory RepositorySessionFactory { get { return ObjectLocator.GetObject<IRepositorySessionFactory>(); } }

        protected abstract string[] CustomUnityConfigs { get; }

        public RequireDatabaseSupport(ObjectResolverType objectResolverType)
            : base(objectResolverType)
        {
            if (objectResolverType != ObjectResolverType.InMemory)
                RegisterCustomUnityConfigs();
        }

        private void RegisterCustomUnityConfigs()
        {
            var customUnityConfigs = CustomUnityConfigs;
            if (customUnityConfigs != null && customUnityConfigs.Length > 0)
            {
                var unityServices = new List<IRegisterWithUnityService>();
                foreach (var typeName in customUnityConfigs)
                {
                    try
                    {
                        var instance = RegisterTypesWithContainer(typeName);
                        if (instance != null)
                            unityServices.Add(instance);
                    }
                    catch (Exception e)
                    {
                        Console.WriteLine(e);
                        throw;
                    }
                }
                if (unityServices.Count > 0)
                    ObjectLocator.RegisterUnityTypes<IRegisterWithUnityService>(unityServices);
            }
        }

        private IRegisterWithUnityService RegisterTypesWithContainer(string typeName)
        {
            if (!string.IsNullOrWhiteSpace(typeName))
            {
                var type = Type.GetType(typeName);
                if (type != null)
                {
                    var instance = Activator.CreateInstance(type) as IRegisterWithUnityService;

                    return instance;
                }
            }
            return null;
        }

        protected IRepositorySession RepositorySession
        {
            get
            {
                return RepositorySessionFactory.GetNewSession(true);
            }
        }

        protected IRepositorySession RepositoryReadOnlySession
        {
            get
            {
                return RepositorySessionFactory.GetNewSession(false, IsolationLevel.ReadCommitted);
            }
        }

        protected abstract DatabaseInfo DatabaseInfo { get; }

        protected TestContext TestContext { set; get; }

        protected bool IsDataNotRequired()
        {
            if (TestContext == null)
            {
                return false;
            }
            var testName = TestContext.TestName;
            MethodInfo info = this.GetType().GetMethod(testName);
            return info.GetCustomAttributes(typeof(NoDataRequiredAttribute), false).Length > 0;
        }

        protected override void DatabaseSupportInitialize()
        {
            if (IsDataNotRequired())
                return;

            DatabaseInfo databaseInfo = DatabaseInfo;

            _mySqlDatabase = new SqlDbUnitTest(databaseInfo.ConnectionString);
            var xsdResourceStream = GetResourceStream(databaseInfo.XSDPath);
            _mySqlDatabase.ReadXmlSchema(xsdResourceStream);

            //Clean up database before start runing Tests              
            _mySqlDatabase.PerformDbOperation(DbOperationFlag.DeleteAll);

            for (int i = 0; i < databaseInfo.DataFiles.Count; i++)
            {
                var dataFileResourceStream = GetResourceStream(databaseInfo.DataFiles[i]);
                if (i == 0)
                    _mySqlDatabase.ReadXml(dataFileResourceStream);
                else
                    _mySqlDatabase.AppendXml(dataFileResourceStream);
            }

            _mySqlDatabase.PerformDbOperation(DbOperationFlag.CleanInsertIdentity);
        }

        private Stream GetResourceStream(string resourceFileName)
        {
            return GetType().Assembly.GetManifestResourceStream(resourceFileName);
        }

        protected virtual void DatabaseSupportCleanup()
        {
            if (IsDataNotRequired())
                return;

            //when all of the tests are complete, we delete all records from the database             
            // to clean up after ourselves             

            //_mySqlDatabase.PerformDbOperation(DbOperationFlag.DeleteAll);

            RepositorySessionFactory.Unbind();

            ObjectLocator.ClearAllObjects();
        }
    }
}
