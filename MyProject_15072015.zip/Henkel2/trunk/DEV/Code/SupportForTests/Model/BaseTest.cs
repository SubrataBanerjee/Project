﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Business.Kernel.API.Infrastructure.Resources;
using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Common.Core.API.DTO.ComplexType;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.API.Services;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Common.SupportForTests.Model
{
    public abstract class BaseTest
    {
        #region Constructors

        public BaseTest(ObjectResolverType objectResolverType)
        {
            ObjectLocator.SetObjectResolver(objectResolverType);
        }

        #endregion

        #region Methods

        protected virtual void Initialize()
        {
            ObjectLocator.ClearAllObjects();
            var userContextService = MockRepository.GenerateMock<IUserContextService>();
            userContextService.Expect(x => x.CurrentUserName).Repeat.Any().Return("UnitTest_User");
            ObjectLocator.RegisterObject<IUserContextService>(userContextService);

            var cacheCustomerManagementService = MockRepository.GenerateMock<ICacheCustomerManagementService>();
            cacheCustomerManagementService.Expect(x => x.GetCustomerInfo()).Repeat.Any().Return(GetDefaultCustomerInfo());
            cacheCustomerManagementService.Expect(x => x.GetCustomerFullName()).Repeat.Any().Return("Henkel Admin");
            cacheCustomerManagementService.Expect(x => x.GetCustomerConfigDetails()).Repeat.Any().Return(GetDefaultCustomerConfigs());
            cacheCustomerManagementService.Expect(x => x.GetConfigValue(null)).IgnoreArguments().Return(null).WhenCalled(y => 
            {
                var key = (string) y.Arguments[0];
                var config = GetDefaultCustomerConfigs().FirstOrDefault(z => z.ConfigKey == key);
                y.ReturnValue = config  == null ? string.Empty : config.ConfigValue;
            });

            ObjectLocator.RegisterObject<ICacheCustomerManagementService>(cacheCustomerManagementService);

            DatabaseSupportInitialize();
        }

        

        protected virtual void DatabaseSupportInitialize()
        {

        }

        #endregion

        #region Helpers

        private CustomerInfoDto GetDefaultCustomerInfo()
        {
            return new CustomerInfoDto
            {
                Id = new Guid("4D3CCFAE-C1C2-44CA-B55A-A21C739DB313"),
                IsActive = true,
                IsDeleted = false,
                CustomerFullName = "Henkel Admin",
                GroupCompanyName = "Henkel",
                CreatedBy = "Ststem",
                CreatedOn = DateTime.Now,
                LastModifiedBy = "System",
                LastModifiedOn = DateTime.Now,
                Contact = new Contact
                {
                    Email = "abc@xyz.com",
                    PhoneNumber = "8789065760",
                    PersonName = new PersonName
                    {
                        FirstName = "Henkel",
                        LastName = "Admin"
                    }
                },
                Address = new Address
                {
                    Line1 = "Line1",
                    Line2 = "Line2",
                    City = "Mumbai",
                    State = "Maharashtra",
                },
            };
        }

        private IList<CustomerConfigDetailDto> GetDefaultCustomerConfigs()
        {
            return new List<CustomerConfigDetailDto>
            {
                new CustomerConfigDetailDto
                {
                    ConfigKey = CoreAdminConfigKey.CacheTimeOut,
                    ConfigValue = "5"
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = CoreAdminConfigKey.StorageContainerDirectory,
                    ConfigValue = ""
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = CoreAdminConfigKey.StorageContainerDirectoryCredential,
                    ConfigValue = ""
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = CoreAdminConfigKey.UploadPath,
                    ConfigValue = ""
                },

                new CustomerConfigDetailDto
                {
                    ConfigKey = InfrastructureAdminConfigKey.SMTPEmailId,
                    ConfigValue = "abc@xyz.com"
                },

                new CustomerConfigDetailDto
                {
                    ConfigKey = InfrastructureAdminConfigKey.SmtpHost,
                    ConfigValue = ""
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = InfrastructureAdminConfigKey.SmtpPort,
                    ConfigValue = ""
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = InfrastructureAdminConfigKey.SMTPPassword,
                    ConfigValue = ""
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = SecurityAdminConfigKey.DefaultUserPassword,
                    ConfigValue = "abc@1234"
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = SecurityAdminConfigKey.FailureLoginAttemptLimit,
                    ConfigValue = "3"
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = SecurityAdminConfigKey.PasswordHistoryLimit,
                    ConfigValue = "3"
                },
                new CustomerConfigDetailDto
                {
                    ConfigKey = SecurityAdminConfigKey.PasswordPolicy,
                    ConfigValue = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W)\S{8,15}$|Should be 8-15 characters in length\n\rShould have atleast one lowercase character\n\rShould have atleast one uppercase character\n\rShould have atleast one number\n\rShould have atleast one special character\n\rShould not have spaces."
                },
            };
        }

        #endregion
    }
}
