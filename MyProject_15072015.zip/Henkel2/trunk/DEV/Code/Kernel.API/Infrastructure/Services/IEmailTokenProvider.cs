﻿using Henkel.Business.Kernel.Infrastructure.API.DTO;
using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.API.Services
{
    public interface IEmailTokenProvider
    {
        void AddTokens(IList<Token> tokens, Guid entityId);

        void AddTokens(IList<Token> tokens, IEntity entity);
    }
}
