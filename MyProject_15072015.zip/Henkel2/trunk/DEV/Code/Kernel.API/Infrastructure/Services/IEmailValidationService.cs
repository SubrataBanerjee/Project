﻿using Henkel.Common.Core.API.Services;

namespace Henkel.Business.Kernel.Infrastructure.API.Services
{
    public interface IEmailValidationService : IBusinessService
    {
        /// <summary>
        /// Method to validate Email Id format
        /// </summary>
        /// <param name="email">email to Validate</param>
        bool IsValid(string email);
    }
}
