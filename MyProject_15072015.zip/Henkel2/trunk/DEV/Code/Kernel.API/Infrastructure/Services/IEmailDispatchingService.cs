﻿using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.API.Services
{
    public interface IEmailDispatchingService : IBusinessService
    {
        /// <summary>
        /// Method used to Dispatch emails from the Notification Queue
        /// </summary>
        void DispatchQueuedEmail();

        /// <summary>
        /// Method used to Dispatch emails Instantly without Queue
        /// </summary>
        /// <param name="emailTemplateId">emailTemplateId</param>
        /// <param name="fromEmail">fromEmail</param>
        /// <param name="toEmail">semicolon (;) separated toEmail ids</param>
        /// <param name="bccEmails">semicolon (;) separated bcc Email ids</param>
        /// <param name="ccEmails">semicolon (;) separated cc Email ids</param>
        /// <param name="subject">subject</param>
        /// <param name="body">body</param>
        /// <param name="attachements">File path and fielName keyvalue pairs of attachements</param>
        void DispatchEmail(Guid emailTemplateId, string fromEmail, string toEmail, string bccEmails, string ccEmails, string subject, string body, IDictionary<string, string> attachements = null);
    }
}
