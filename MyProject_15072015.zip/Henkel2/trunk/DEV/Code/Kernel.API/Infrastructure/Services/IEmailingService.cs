﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.API.Services
{
    public partial interface IEmailingService : IBusinessService
    {
        #region Methods

        void SendEmail(string templateName, IEntity entity, IDictionary<string, string> attachements = null);

        #endregion
    }
}
