﻿
namespace Henkel.Business.Kernel.API.Infrastructure.Resources
{
    public static class InfrastructureAdminConfigKey
    {
        public const string SmtpHost = "SmtpHost"; 
        public const string SmtpPort = "SmtpPort";
        public const string SMTPEmailId = "SMTPEmailId";
        public const string SMTPPassword = "SMTPPassword";
        public const string NotificationQueueCountForDispatch = "NotificationQueueCountForDispatch";
    }
}
