﻿
namespace Henkel.Business.Kernel.API.Infrastructure.Resources
{
    public static class InfrastructureErrorMessage
    {
        public const string UserIsNotExist = "Key_UserIsNotExist"; //"User is not exist."
        public const string EmailTemplateIsNotExist = "Key_EmailTemplateIsNotExist"; //"Email Template is not exist."
        public const string EmailTemplateNameCanNotBeBlank = "Key_EmailTemplateNameCanNotBeBlank"; //"Email Template name can not blank."
        public const string TokenCanNotBeBlank = "Key_TokenCanNotBeBlank"; //Token Can not be blank.
        public const string EmailCanNotBeEmpty = "Key_EmailCanNotBeEmpty"; //Email Can not be Empty.
        public const string InvalidEmailFormat = "Key_InvalidEmailFormat"; //Invalid Email Format specified.
    }
}
