﻿using Henkel.Common.Core.API.DTO.ComplexType;
using System;

namespace Henkel.Business.Kernel.API.Customer.DTO
{
    public class CustomerInfoDto
    {
        #region Fields

        public Guid Id { get; set; }

        public string CustomerFullName { get; set; }

        public string GroupCompanyName { get; set; }

        public Contact Contact { get; set; }

        public Address Address { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedOn { get; set; }

        public string LastModifiedBy { get; set; }

        public DateTime? LastModifiedOn { get; set; }

        #endregion

        #region Constructors

        public CustomerInfoDto()
        {
            Contact = new Contact
            {
                PersonName = new PersonName()
            };

            Address = new Address();
        }

        #endregion

    }
}
