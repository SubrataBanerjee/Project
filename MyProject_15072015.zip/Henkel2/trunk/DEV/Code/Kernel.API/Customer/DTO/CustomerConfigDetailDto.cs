﻿using System;

namespace Henkel.Business.Kernel.API.Customer.DTO
{
    public class CustomerConfigDetailDto
    {
        public Guid Id { get; set; }

        public Guid CustomerInfoId { get; set; }

        public string ConfigKey { get; set; }

        public string ConfigValue { get; set; }
    }
}
