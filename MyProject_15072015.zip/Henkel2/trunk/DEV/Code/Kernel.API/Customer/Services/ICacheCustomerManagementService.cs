﻿using Henkel.Business.Kernel.API.Customer.DTO;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.API.Customer.Services
{
    public interface ICacheCustomerManagementService
    {
        /// <summary>
        /// Method to Get CustomerInfo (Note: As Name suggested, Data Will be Cached here)
        /// </summary>
        /// <returns>CustomerInfoDto</returns>
        CustomerInfoDto GetCustomerInfo();


        /// <summary>
        /// Method to get Customer Full Name (Note: As Name suggested, Data Will be Cached here)
        /// </summary>
        /// <returns>Customer Full Name</returns>
        string GetCustomerFullName();


        /// <summary>
        /// Method to get Group Company Name (Note: As Name suggested, Data Will be Cached here)
        /// </summary>
        /// <returns>Group Company Name</returns>
        string GetGroupCompanyName();

        /// <summary>
        /// Method to Get CustomerConfigDetailDtos (Note: As Name suggested, Data Will be Cached here)
        /// </summary>
        /// <returns></returns>
        IList<CustomerConfigDetailDto> GetCustomerConfigDetails();


        /// <summary>
        /// Method to Get CustomerConfig Value by Key 
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>Customer Config Value</returns>
        string GetConfigValue(string key);

        /// <summary>
        /// Method to reset or remove CustomerInfo Cache data
        /// </summary>
        void ResetCacheData();

        
    }
}
