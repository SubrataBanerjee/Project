﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Common.Core.API.Services;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.API.Customer.Services
{
    public interface ICustomerManagementService : IBusinessService
    {
        #region Methods

        /// <summary>
        /// Method to Get CustomerInfo (Note: this will return the cached data) 
        /// </summary>
        /// <returns>CustomerInfoDto</returns>
        CustomerInfoDto GetCustomerInfo();



        /// <summary>
        /// Method to get Customer Full Name (Note: this will return the cached data)
        /// </summary>
        /// <returns>Customer Full Name</returns>
        string GetCustomerFullName();

        /// <summary>
        /// Method to get Customer Group Company Name (Note: this will return the cached data)
        /// </summary>
        /// <returns>Group Company Name</returns>
        string GetGroupCompanyName();


        /// <summary>
        /// Method to Get CustomerConfigDetailDtos (Note: As Name suggested, Data Will be Cached here)
        /// </summary>
        /// <returns></returns>
        IList<CustomerConfigDetailDto> GetCustomerConfigDetails();



        /// <summary>
        /// Method to Get CustomerConfig Value by Key 
        /// </summary>
        /// <param name="key">Key</param>
        /// <returns>Customer Config Value</returns>
        string GetConfigValue(string key);



        /// <summary>
        /// Method to Update Customer General Info from Dto
        /// </summary>
        /// <param name="customerInfoDto">customerInfoDto</param>
        void UpdateCustomerGeneralInfo(CustomerInfoDto customerInfoDto);
        

        /// <summary>
        /// Method to Update Customer Contact Detail from Dto
        /// </summary>
        /// <param name="customerInfoDto">customerInfoDto</param>
        void UpdateCustomerContactDetail(CustomerInfoDto customerInfoDto);
        
        #endregion

    }
}
