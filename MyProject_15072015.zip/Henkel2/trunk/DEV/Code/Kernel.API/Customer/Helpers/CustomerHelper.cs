﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Common.Core.API.Locator;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.API.Customer.Helpers
{
    public static class CustomerHelper
    {
        #region Fields

        private static readonly ICacheCustomerManagementService _cacheCustomerManagementService;
        private static readonly ICustomerManagementService _customerManagementService;

        #endregion

        #region Constructors

        static CustomerHelper()
        {
            _cacheCustomerManagementService = ObjectLocator.GetObject<ICacheCustomerManagementService>();
            _customerManagementService = ObjectLocator.GetObject<ICustomerManagementService>();
        }

        #endregion

        #region Methods

        public static CustomerInfoDto GetCustomerInfo(bool requiredSession)
        {
            if (requiredSession)
                return _customerManagementService.GetCustomerInfo();

            return _cacheCustomerManagementService.GetCustomerInfo();
        }

        public static string GetCustomerFullName(bool requiredSession)
        {
            if (requiredSession)
                return _customerManagementService.GetCustomerFullName();

            return _cacheCustomerManagementService.GetCustomerFullName();
        }

        public static IList<CustomerConfigDetailDto> GetCustomerConfigDetails(bool requiredSession)
        {
            if (requiredSession)
                return _customerManagementService.GetCustomerConfigDetails();

            return _cacheCustomerManagementService.GetCustomerConfigDetails();
        }

        public static string GetConfigValue(bool requiredSession, string key)
        {
            if (requiredSession)
                return _customerManagementService.GetConfigValue(key);

            return _cacheCustomerManagementService.GetConfigValue(key);
        }

        

        #endregion
    }
}
