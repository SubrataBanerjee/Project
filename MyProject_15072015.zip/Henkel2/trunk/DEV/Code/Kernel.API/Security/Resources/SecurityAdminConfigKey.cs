﻿
namespace Henkel.Business.Kernel.API.Security.Resources
{
    public static class SecurityAdminConfigKey
    {
        public const string FailureLoginAttemptLimit = "FailureLoginAttemptLimit";
        public const string DefaultUserPassword = "DefaultUserPassword";
        public const string PasswordPolicy = "PasswordPolicy";
        public const string PasswordHistoryLimit = "PasswordHistoryLimit";
    }
}
