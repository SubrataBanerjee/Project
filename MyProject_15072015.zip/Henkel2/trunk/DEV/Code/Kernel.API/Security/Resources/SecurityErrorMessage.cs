﻿
namespace Henkel.Business.Kernel.API.Security.Resources
{
    public static class SecurityErrorMessage
    {
        public const string InvalidEmailFormat = "Key_InvalidEmailFormat"; //Invalid Email Format specified.

        //Resource Related Errors
        public const string InvalidResourceIdForUpdate = "Key_InvalidResourceIdForUpdate"; // Invalid ResourceId specified for Update operation.
        public const string CanNotCreateLoginAsResourceLoginAlreadyExist = "Key_CanNotCreateLoginAsResourceLoginAlreadyExist"; //Can not create Login as Resource Login already Exist.
        public const string ResourceCodeCanNotBeEmpty = "Key_ResourceCodeCanNotBeEmpty"; // Resource Code can not be Empty.
        public const string ResourceEmailCanNotBeEmpty = "Key_ResourceEmailCanNotBeEmpty"; //Resource Email can not be Empty.
        public const string ResourceCodeAlreadyExist = "Key_ResourceCodeAlreadyExist"; // Specified Resource Code already Exist.
        public const string ResourceEmailIdAlreadyExist = "Key_ResourceEmailIdAlreadyExist"; // Specified Resource Email Id already Exist.

        //User Related Errors
        public const string UserNameCanNotBeEmpty = "Key_UserNameCanNotBeEmpty"; //"User Name can not be empty."
        public const string LoginIdAlreadyExist = "Key_LoginIdAlreadyExist"; // LoginId already exists.
        public const string InvalidUserIdForUpdate = "Key_InvalidUserIdForUpdate"; //"Invalid UserId specified for Update operation."
        public const string UsernameOrPasswordIsIncorrect = "Key_UsernameOrPasswordIsIncorrect"; //"Specified User name or password is incorrect.";
        public const string NewPasswordAndConfirmPasswordNotMatched = "Key_NewPasswordAndConfirmPasswordNotMatched"; //"Specified new password and confirm password are not matched.";
        public const string UserIsLocked = "Key_UserIsLocked"; //"Can't Login into the system. User is Locked.";
        public const string UserIsDisabled = "Key_UserIsDisabled"; //"Can't Login into the system. User is Disabled.";
        public const string PasswordCanNotBeEmpty = "Key_PasswordCanNotBeEmpty"; //"Password can not be empty."
        public const string SpecifiedEmailIdIsNotPresent = "Key_SpecifiedEmailIdIsNotPresent"; // Specified Email Id is not present in the system.
        public const string InvalIdLoginIdSpecified = "Key_InvalIdLoginIdSpecified"; //InvalId LoginId/Username Specified for Authentication.
        public const string SuperAdminCanNotBeLocked = "Key_SuperAdminCanNotBeLocked"; //Super Admin can not be Locked.

        public const string InvalidPasswordFormatAsPerPasswordPolicy = "GenericKey_InvalidPasswordFormatAsPerPasswordPolicy"; // "Specified Password does not match with password policy : {0}." //where {0} -> is the description of Policy
        public const string NewPasswordShouldNotBeSameAsLastUsedPassword = "GenericKey_NewPasswordShouldNotBeSameAsLastUsedPassword"; // "Specified Password should not be same as last {0} number of used passwords." //Where {0} -> is the number of last passwords need to verify from History
        public const string SuperAdminCanNotBeDeleted = "Key_SuperAdminCanNotBeDeleted"; // "System Super Admin Can not be Deleted."

        //Role Related Errors
        public const string RoleNameCanNotBeEmpty = "Key_RoleNameCanNotBeEmpty"; //Role Name can not be Empty.
        public const string RoleNameAlreadyExist = "Key_RoleNameAlreadyExist"; // Specified Role Name already Exist.
        public const string InvalidUserIdForDetachedRoleFromUser = "Key_InvalidUserIdForDetachedRoleFromUser"; // Invalid UserId specified to Detach Role From User.
        public const string InvalidRoleIdForDetachedRoleFromUser = "Key_InvalidRoleIdForDetachedRoleFromUser"; // Invalid RoleId specified to Detach Role From User.
        public const string InvalidUserIdToGetSudoRole = "Key_InvalidUserIdToGetSudoRole"; // Invalid UserId specified to get User Sudo Role.
        public const string InvalidUserIdOrRoleIdToGetSudoRole = "Key_InvalidUserIdOrRoleIdToGetSudoRole"; // Invalid UserId or RoleId specified to get Sudo Role.








        
    }
}
