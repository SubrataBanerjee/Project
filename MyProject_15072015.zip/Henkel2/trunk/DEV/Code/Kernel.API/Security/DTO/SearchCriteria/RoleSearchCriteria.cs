﻿using System;

namespace Henkel.Business.Kernel.Security.API.DTO.SearchCriteria
{
    public class RoleSearchCriteria
    {
        public Guid? RoleId { get; set; }
        public string RoleName { get; set; }
        public Guid? UserId { get; set; }
        public string UserName { get; set; }
        public bool? IsActive { get; set; }
    }
}
