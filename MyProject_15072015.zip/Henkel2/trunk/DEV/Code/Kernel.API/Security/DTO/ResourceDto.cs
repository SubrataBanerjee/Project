﻿using Henkel.Common.Core.API.DTO.ComplexType;
using System;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    public class ResourceDto
    {
        public Guid ResourceId { get; set; }

        public string Code { get; set; }

        public Guid? UserId { get; set; }

        public string LoginId { get; set; }

        public Contact Contact { get; set; }

        public Address Address { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedOn { get; set; }

        public string LastModifiedBy { get; set; }

        public DateTime? LastModifiedOn { get; set; }
    }
}
