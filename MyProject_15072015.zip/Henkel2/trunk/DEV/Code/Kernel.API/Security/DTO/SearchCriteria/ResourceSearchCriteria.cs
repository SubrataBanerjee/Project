﻿using Henkel.Common.Core.API.DTO.SearchCriteria;
using System;

namespace Henkel.Business.Kernel.Security.API.DTO.SearchCriteria
{
    public class ResourceSearchCriteria : ISearchCriteria
    {
        public virtual bool? IsActive { get; set; }

        public virtual Guid? ResourceId { get; set; }

        public virtual string ResourceCode { get; set; }
    }
}
