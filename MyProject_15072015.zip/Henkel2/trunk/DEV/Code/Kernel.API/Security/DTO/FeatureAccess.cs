﻿using System;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    /// <summary>
    /// Feature Access
    /// </summary>
    [Serializable]
    public class FeatureAccess
    {
        public Guid FeatureId { get; set; }

        public String FeatureName { get; set; }

        public String Module { get; set; }

        public String FeatureGroup { get; set; }

        public UserAction Rights { get; set; }

        public bool View
        {
            get { return HasAccess(UserAction.View); }
            set { SetActionRights(UserAction.View, value); }
        }

        public bool Add
        {
            get { return HasAccess(UserAction.Add); }
            set { SetActionRights(UserAction.Add, value); }
        }

        public bool Edit
        {
            get { return HasAccess(UserAction.Edit); }
            set { SetActionRights(UserAction.Edit, value); }
        }

        public bool Delete
        {
            get { return HasAccess(UserAction.Delete); }
            set { SetActionRights(UserAction.Delete, value); }
        }

        public bool Execute
        {
            get { return HasAccess(UserAction.Execute); }
            set { SetActionRights(UserAction.Execute, value); }
        }

        public bool Activate
        {
            get { return HasAccess(UserAction.Activate); }
            set { SetActionRights(UserAction.Activate, value); }
        }

        public bool Print
        {
            get { return HasAccess(UserAction.Print); }
            set { SetActionRights(UserAction.Print, value); }
        }

        public void SetActionRights(UserAction action, bool hasRight)
        {
            if (hasRight)
                Rights |= action;
            else
                Rights &= (UserAction.All ^ action);
        }

        public bool HasAccess(UserAction action)
        {
            if ((Rights & action) > 0)
                return true;
            return false;
        }
    }
}
