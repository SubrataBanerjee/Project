﻿using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    public class SudoRoleDto
    {
        public Guid RoleId { get; set; }
        
        public string RoleName { get; set; }

        public Guid UserId { get; set; }

        public bool IsActive { get; set; }

        public IList<RoleFeatureUserMapDto> RoleFeatureUserMapDtos { get; set; }
    }
}
