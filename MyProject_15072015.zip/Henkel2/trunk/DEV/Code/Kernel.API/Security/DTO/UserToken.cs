﻿using System;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    public class UserToken
    {
        public bool SuccessLogin { get; set; }

        public bool ChangePwdOnLogin { get; set; }

        public string ErrorMessage { get; set; }

        public object[] ErrorArguments { get; set; }

        public Guid UserId { get; set; }

        public string CustomerFullName { get; set; }

        public string GroupCompanyName { get; set; }

        public string UserLoginId { get; set; }

        public string UserFullName { get; set; }

        public bool IsActive { get; set; }

        public bool IsDeleted { get; set; }

        public UserRights UserRights { get; set; }

        
    }
}
