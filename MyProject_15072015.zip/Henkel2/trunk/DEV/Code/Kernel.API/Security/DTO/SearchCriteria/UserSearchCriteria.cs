﻿using Henkel.Common.Core.API.DTO.SearchCriteria;
using System;

namespace Henkel.Business.Kernel.Security.API.DTO.SearchCriteria
{
    public class UserSearchCriteria : ISearchCriteria
    {
        public Guid? UserId { get; set; }
        public string UserName { get; set; }
        public bool? IsActive { get; set; }
    }
}
