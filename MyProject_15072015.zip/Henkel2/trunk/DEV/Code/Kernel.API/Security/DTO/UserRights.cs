﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    /// <summary>
    /// Class to store user's features collection
    /// </summary>
    [Serializable]
    public class UserRights
    {
        public Guid UserId { get; set; }
        public bool IsSuperAdmin { get; set; }

        public ICollection<FeatureAccess> FeatureAccesses { get; set; }

        public UserRights(Guid userId, bool isSuperAdmin)
        {
            UserId = userId;
            IsSuperAdmin = isSuperAdmin;
            FeatureAccesses = new Collection<FeatureAccess>();
        }

        public bool HasAccess(Guid featureId, params UserAction[] actions)
        {
            if (this.IsSuperAdmin)
                return true;
            var feature = FeatureAccesses.FirstOrDefault(x => x.FeatureId == featureId);
            if (feature != null)
            {
                foreach (var action in actions)
                {
                    if (action != UserAction.None && feature.HasAccess(action))
                        return true;
                }
            }

            return false;
        }

        public void UpdateState(IList<RoleFeatureUserMapDto> roleFeatureUserMapDtos)
        {
            if (roleFeatureUserMapDtos == null)
                return;

            foreach(var roleFeatureUserMapDto in roleFeatureUserMapDtos)
                UpdateState(roleFeatureUserMapDto);
        }

        public void UpdateState(RoleFeatureUserMapDto roleFeatureUserMapDto)
        {
            if (FeatureAccesses.Count == 0)
            {
                var access = new FeatureAccess { FeatureName = roleFeatureUserMapDto.FeatureName, FeatureId = roleFeatureUserMapDto.FeatureId, Module = roleFeatureUserMapDto.Module, Add = roleFeatureUserMapDto.Add, Edit = roleFeatureUserMapDto.Edit, View = roleFeatureUserMapDto.View, Delete = roleFeatureUserMapDto.Delete, Execute = roleFeatureUserMapDto.Execute, Activate = roleFeatureUserMapDto.Activate, Print = roleFeatureUserMapDto.Print, FeatureGroup = roleFeatureUserMapDto.FeatureGroup };
                FeatureAccesses.Add(access);
            }
            else
            {
                var access = FeatureAccesses.FirstOrDefault(a => a.FeatureId == roleFeatureUserMapDto.FeatureId);
                if (access == null)
                {
                    access = new FeatureAccess { FeatureId = roleFeatureUserMapDto.FeatureId, FeatureName = roleFeatureUserMapDto.FeatureName, Module = roleFeatureUserMapDto.Module, Add = roleFeatureUserMapDto.Add, Edit = roleFeatureUserMapDto.Edit, View = roleFeatureUserMapDto.View, Delete = roleFeatureUserMapDto.Delete, Execute = roleFeatureUserMapDto.Execute, Activate = roleFeatureUserMapDto.Activate, Print = roleFeatureUserMapDto.Print, FeatureGroup = roleFeatureUserMapDto.FeatureGroup };
                    FeatureAccesses.Add(access);
                }
                else
                {
                    access.Add = (roleFeatureUserMapDto.Add || access.Add);
                    access.Edit = (roleFeatureUserMapDto.Edit || access.Edit);
                    access.View = (roleFeatureUserMapDto.View || access.View);
                    access.Delete = (roleFeatureUserMapDto.Delete || access.Delete);
                    access.Print = (roleFeatureUserMapDto.Print || access.Print);
                    access.Execute = (roleFeatureUserMapDto.Execute || access.Execute);
                    access.Activate = (roleFeatureUserMapDto.Activate || access.Activate);
                }
            }
        }
    }
}
