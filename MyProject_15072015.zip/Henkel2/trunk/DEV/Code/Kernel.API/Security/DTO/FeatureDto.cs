﻿using System;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    public class FeatureDto
    {
        public Guid Id { get; set; }

        public string Module { get; set; }

        public string FeatureName { get; set; }

        public string FeatureGroup { get; set; }

        public bool Add { get; set; }

        public bool Edit { get; set; }

        public bool View { get; set; }

        public bool Delete { get; set; }

        public bool Print { get; set; }

        public bool Execute { get; set; }

        public bool Activate { get; set; }
    }
}
