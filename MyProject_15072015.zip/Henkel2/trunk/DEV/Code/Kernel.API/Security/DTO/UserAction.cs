﻿using System;

namespace Henkel.Business.Kernel.Security.API.DTO
{
    /// <summary>
    /// Enum for Actions
    /// </summary>
    [Flags]
    public enum UserAction
    {
        None = 0,
        View = 1,
        Add = 2,
        Edit = 4,
        Delete = 8,
        Print = 16,
        Execute = 32,
        Activate = 64,
        All = View | Add | Edit | Delete | Print | Execute | Activate
    }
}
