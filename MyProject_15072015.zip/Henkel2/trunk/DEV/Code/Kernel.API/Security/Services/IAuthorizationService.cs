﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Security.API.Services
{
    public interface IAuthorizationService : IBusinessService
    {
        /// <summary>
        /// Get user's rights
        /// </summary>
        /// <param name="userId">User Name</param>
        /// <returns>UserFeature Object</returns>
        UserRights GetRights(Guid userId);

        /// <summary>
        /// Check whether user has access rights of feature and given actions
        /// </summary>
        /// <param name="currentRights">Current UserRights</param>
        /// <param name="feature">Feature</param>
        /// /// <param name="group">FeatureGroup</param>
        /// /// <param name="module">module</param>
        /// <param name="actions">actions</param>
        /// <returns>True or False</returns>
        bool HasRight(UserRights currentRights, string feature, string group, string module, params UserAction[] actions);

        /// <summary>
        /// Return All features stored in Cache
        /// </summary>
        /// <returns></returns>
        IList<FeatureDto> GetSystemFeatures();
    }
}
