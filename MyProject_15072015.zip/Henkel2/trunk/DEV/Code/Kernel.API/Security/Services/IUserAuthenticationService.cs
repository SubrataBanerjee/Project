﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Common.Core.API.Services;
using System;

namespace Henkel.Business.Kernel.Security.API.Services
{
    public interface IUserAuthenticationService : IBusinessService
    {
        UserToken SignIn(string loginId, string password, bool rememberMe = false);

        void SignOut();

        void ResetPassword(Guid userId);

        void ChangePassword(Guid userId, string oldPassword, string newPassword, string confirmPassword);

        void ForgotPassword(string emailId);

        void LockUser(Guid userId);

        void UnlockUser(Guid userId);
    }
}
