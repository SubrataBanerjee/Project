﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.DTO.SearchCriteria;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Security.API.Services
{
    public interface IRoleManagementService : IBusinessService
    {
        /// <summary>
        /// Method to Get Role By RoleId
        /// </summary>
        /// <param name="roleId">roleId</param>
        /// <returns>RoleDto</returns>
        RoleDto GetRoleById(Guid roleId);

        /// <summary>
        /// Method to Get Sudo Role By UserId and RoleId. -> Note: Sudo role is one which is Attached with User
        /// </summary>
        /// value<param name="userId">userId</param>
        /// <param name="roleId">roleId</param>
        /// <returns>SudoRoleDto</returns>
        SudoRoleDto GetSudoRoleById(Guid userId, Guid roleId);

        /// <summary>
        /// Method to Search Roles by Search Criteria
        /// </summary>
        /// <param name="roleSearchCriteria">roleSearchCriteria</param>
        /// <param name="pageInfo">pageInfo</param>
        /// <returns>Page of RoleDto</returns>
        Page<RoleDto> FindRoleByCriteria(RoleSearchCriteria roleSearchCriteria, PageInfo pageInfo);

        /// <summary>
        /// Method to Search Roles by Search Criteria
        /// </summary>
        /// <param name="roleSearchCriteria">roleSearchCriteria</param>
        /// <returns>List of RoleDto</returns>
        IList<RoleDto> FindRoleByCriteria(RoleSearchCriteria roleSearchCriteria);

        /// <summary>
        /// Add a New Role into the system 
        /// </summary>
        /// <param name="role">Role to Add</param>
        void AddRole(RoleDto role);

        /// <summary>
        /// Modify an Existing Role
        /// </summary>
        /// <param name="role">Role to Modify</param>
        void UpdateRole(RoleDto role, bool updateSudoRole = false);

        /// <summary>
        /// Modify an Existing Sudo Role
        /// </summary>
        /// <param name="role">Role to Modify</param>
        void UpdateSudoRole(SudoRoleDto sudoRole);

        /// <summary>
        /// Mark Role as Enabled
        /// </summary>
        /// <param name="roleId">roleId to Enable</param>
        void EnableRole(Guid roleId);

        /// <summary>
        /// Mark Role as Disabled
        /// </summary>
        /// <param name="roleId">roleId to Disabled</param>
        void DisableRole(Guid roleId);

        /// <summary>
        /// Delete Role
        /// </summary>
        /// <param name="roleId"> role Id to delete</param>
        void DeleteRole(Guid roleId);

        /// <summary>
        /// Attach a Role To the User
        /// </summary>
        /// <param name="userId">userId</param>
        /// <param name="roleId">RoleId to Attached</param>
        void AttachRoleToUser(Guid userId, Guid roleId);

        /// <summary>
        /// Dettach a Role from User
        /// </summary>
        /// <param name="userId">userId</param>
        /// <param name="roleId">roleId</param>
        void DettachRoleFromUser(Guid userId, Guid roleId);
    }
}
