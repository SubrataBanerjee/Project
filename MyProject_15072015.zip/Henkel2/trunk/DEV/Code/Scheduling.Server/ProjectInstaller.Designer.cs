﻿using System.ComponentModel;

namespace Henkel.Scheduler.Scheduling.Server
{
    partial class ProjectInstaller
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            //components = new Container();

            this.SchedulingServiceProcessInstaller = new System.ServiceProcess.ServiceProcessInstaller();
            this.SchedulingServiceInstaller = new System.ServiceProcess.ServiceInstaller();
            // 
            // SchedulingServiceProcessInstaller
            // 

            this.SchedulingServiceProcessInstaller.Password = null;
            this.SchedulingServiceProcessInstaller.Username = null;
            // 
            // SchedulingServiceInstaller
            // 
            this.SchedulingServiceInstaller.Description = "Henkel.Scheduler.Scheduling.Server: Quartz base scheduling service use for handling multiple schedule tasks.";
            SetServicePropertiesFromCommandLine(this.SchedulingServiceInstaller);
            this.SchedulingServiceInstaller.StartType = System.ServiceProcess.ServiceStartMode.Automatic;
            // 
            // ProjectInstaller
            // 
            this.Installers.AddRange(new System.Configuration.Install.Installer[] {
            this.SchedulingServiceProcessInstaller,
            this.SchedulingServiceInstaller});
        }

        #endregion

        private System.ServiceProcess.ServiceProcessInstaller SchedulingServiceProcessInstaller;
        private System.ServiceProcess.ServiceInstaller SchedulingServiceInstaller;
    }
}