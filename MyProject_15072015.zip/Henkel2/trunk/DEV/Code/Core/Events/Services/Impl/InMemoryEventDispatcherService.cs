﻿using Henkel.Common.Core.API.Events.Model;
using Henkel.Common.Core.API.Events.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.SessionState;

namespace Henkel.Common.Core.Events.Services.Impl
{
    public class InMemoryEventDispatcherService : IEventDispatcherService
    {
        public static void SetThreadData(HttpSessionState session)
        {
            if (HttpContext.Current != null && (HttpContext.Current.Session != null || session != null))
            {
                var currentContext = HttpContext.Current.Session ?? session;
                Guid userid = currentContext["UserId"] != null ? new Guid(currentContext["UserId"].ToString()) : Guid.Empty;
                string userName = currentContext["UserName"] != null ? currentContext["UserName"].ToString() : string.Empty;
                ThreadUtils.SetThreadData(userid, userName);
            }
        }

        public void DispatchEvent(BaseEvent evt)
        {
            var eventType = string.Format("Henkel.Common.Core.API.Events.Model.IEventHandler`1[[{0}]], Henkel.Common.Core.API", evt.GetType().AssemblyQualifiedName);
            var type = Type.GetType(eventType);
            var objType = typeof(ObjectLocator);
            var methodInfo = objType.GetMethod("GetAllObject").MakeGenericMethod(type);
            var eventHandlerTypes = methodInfo.Invoke(null, null) as IEnumerable<IEventHandler<BaseEvent>>;
            var contextBase = HttpContext.Current;
            var session = HttpContext.Current == null ? null : HttpContext.Current.Session;
            Task.Factory.StartNew(() =>
            {
                if (HttpContext.Current == null && contextBase != null)
                {
                    HttpContext.Current = contextBase;
                    SetThreadData(session);
                }
                if (eventHandlerTypes != null)
                {
                    foreach (IEventHandler<BaseEvent> handler in eventHandlerTypes.ToList().OrderBy(x => x.GetType().FullName))
                    {
                        try
                        {
                            handler.Handle(evt);
                        }
                        catch (Exception ex)
                        {
                            Logger.Exception("Event Dispatcher", OperationStatus.CreateFromException("Error in Handler", ex));
                        }
                    }
                }
            });

        }
    }
}
