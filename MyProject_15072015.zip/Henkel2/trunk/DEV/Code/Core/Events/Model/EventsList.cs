﻿using Henkel.Common.Core.API.Events.Model;
using Henkel.Common.Core.API.Events.Services;
using Henkel.Common.Core.API.Locator;
using System;
using System.Collections.Generic;

namespace Henkel.Common.Core.Events.Model
{
    public class EventsList
    {
        [ThreadStatic]
        private static IList<BaseEvent> _events;

        public static void Register(BaseEvent @event)
        {
            if (@event == null)
                return;

            if(_events == null)
                _events = new List<BaseEvent>();

            _events.Add(@event);
        }

        public static void DispatchEvents()
        {
            try
            {
                if (_events != null && _events.Count > 0)
            {
                var eventDispatcherSvc = ObjectLocator.GetService<IEventDispatcherService>();
                foreach (var @event in _events)
                {
                    foreach (var action in @event.Actions)
                    {
                        var entity = action.Key;
                        action.Value(@event, entity);
                    }
                    eventDispatcherSvc.DispatchEvent(@event);
                }
                _events.Clear();
            }
            }
            catch(Exception ex)
            {
            }
        }
    }
}
