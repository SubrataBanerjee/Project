﻿using System;

namespace Henkel.Common.Core.Exceptions
{
    /// <summary>
    /// Exception to be raised when Validation fails
    /// </summary>
    public class ValidationException : Exception
    {
        public object[] Args { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>

        public ValidationException(String message, params object[] args)
            : base(message)
        {
            Args = args;
        }

        public ValidationException()
        {
            // TODO: Complete member initialization
        }
    }
}
