﻿using Henkel.Common.Core.API.Events.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Events.Model;
using System.Collections.Specialized;

namespace Henkel.Common.Core.Model
{
    public abstract class AggregateRootEntity : AuditEntityWithSoftDelete
    {
        public virtual void RaiseEvent<T>(T eventObject) where T : BaseEvent
        {
            EventsList.Register(eventObject);
        }

        public virtual void HandlePreEvent<T>(T obj, string eventType, NameValueCollection formCollection = null) where T : Entity
        {
            var handlers = ObjectLocator.GetAllObject<IPreEventHandler<T>>();
            foreach (var handler in handlers)
            {
                handler.Handle(eventType, obj, formCollection);
            }
        }
    }
}
