﻿using Henkel.Common.Core.API.Model;
using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace Henkel.Common.Core.Model
{
    public abstract class Entity : IEntity
    {
        #region Fields

        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public virtual Guid Id { get; set; }

        #endregion
    }
}
