﻿using Henkel.Common.Core.API.Model;

namespace Henkel.Common.Core.Model
{
    public abstract class AuditEntityWithSoftDelete : AuditEntity, ISupportSoftDelete
    {
        #region Implementation of  ISupportSoftDelete

        #region Fields

        public virtual bool IsDeleted { get; set; }

        #endregion

        #region Methods

        public virtual void MarkAsDelete()
        {
            IsDeleted = true;
        }

        #endregion

        #endregion
    }
}
