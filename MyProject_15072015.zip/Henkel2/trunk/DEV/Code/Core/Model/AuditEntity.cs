﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using System;

namespace Henkel.Common.Core.Model
{
    public abstract class AuditEntity : Entity, IAuditEntity
    {
        #region Implementation of IAuditEntity

        #region Fields

        public virtual string CreatedBy { get; set; }

        public virtual DateTime? CreatedOn { get; set; }

        public virtual string LastModifiedBy { get; set; }

        public virtual DateTime? LastModifiedOn { get; set; }

        #endregion

        #region Constructor

        public AuditEntity()
        {
            CreatedOn = DateTime.UtcNow;
            LastModifiedOn = DateTime.UtcNow;
        }

        #endregion

        #region Methods

        public virtual void SetCreationInfo()
        {
            CreatedOn = DateTime.UtcNow;
            CreatedBy = ObjectLocator.GetService<IUserContextService>().CurrentUserName;
            SetModificationInfo();
        }

        public virtual void SetModificationInfo()
        {
            LastModifiedOn = DateTime.UtcNow;
            LastModifiedBy = ObjectLocator.GetService<IUserContextService>().CurrentUserName;
        }

        #endregion

        #endregion
    }
}
