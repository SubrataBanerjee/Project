﻿using Henkel.Common.Core.API.Locator;

namespace Henkel.Common.Core.Locator.Services.Impl
{
    public class ObjectResolverFactory : IObjectResolverFactory
    {
        public IObjectResolver CreateInstance(ObjectResolverType resolverType)
        {
            switch (resolverType)
            {
                case ObjectResolverType.InMemory:
                    {
                        return new InMemoryObjectResolver();
                    }
                case ObjectResolverType.Composite:
                    {
                        return new CompositeObjectResolver();
                    }
                case ObjectResolverType.Unity:
                    {
                        return new UnityObjectResolver();
                    }
                default:
                    {
                        return new UnityObjectResolver();
                    }
            }
        }
    }
}
