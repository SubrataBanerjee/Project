﻿using Henkel.Common.Core.API.Integration.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Utils.Unity;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Common.Core.Locator.Services.Impl
{
    public class UnityObjectResolver : IObjectResolver
    {
        #region Implementation of IObjectResolver

        #region Service Registration Methods

        public virtual void RegisterObject<T>(T service, string name)
        {
            throw new NotImplementedException("All objects must be registered with Unity");
        }

        public void RegisterUnityTypes<T>(IEnumerable<T> unityServices) where T : class, IRegisterWithUnityService
        {
            if (unityServices != null && unityServices.Any())
            {
                foreach (var unityService in unityServices)
                    unityService.RegisterTypes(UnityContainerFactory.Instance);
            }
        }

        public void ClearObject<T>()
        {
            throw new NotImplementedException("Objects registered with Unity cannot be cleared.");
        }

        public void ClearAllObjects()
        {
            throw new NotImplementedException("Objects registered with Unity cannot be cleared.");
        }

        public virtual IUnityContainer UnityContainer
        {
            get
            {
                return UnityContainerFactory.Instance;
            }
        }

        #endregion

        #region Get Methods

        public virtual T GetService<T>() where T : class, IBusinessService
        {
            var result = GetService<T>("");
            if (result != null)
                return result;
            return UnityContainerFactory.Instance.Resolve<T>();
        }

        public virtual T GetService<T>(string name) where T : class, IBusinessService
        {
            return UnityContainerFactory.Instance.Resolve<T>(name);
        }

        public virtual T GetType<T>() where T : class
        {
            T result = null;
            try
            {
                result = GetType<T>("");
            }
            catch(Exception) { }
            
            if (result != null)
                return result;
            
            return UnityContainerFactory.Instance.Resolve<T>();
        }

        public virtual T GetType<T>(string name) where T : class
        {
            return UnityContainerFactory.Instance.Resolve<T>(name);
        }

        /// <summary>
        /// Gets all the objects that implements the specified Type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public IEnumerable<T> GetAll<T>()
        {
            return UnityContainerFactory.Instance.ResolveAll<T>();
        }

        #endregion

        #endregion

        #region Helper Methods

        #endregion

    }
}
