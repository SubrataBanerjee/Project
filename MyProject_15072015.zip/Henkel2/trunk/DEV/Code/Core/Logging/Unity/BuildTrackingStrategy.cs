﻿using Microsoft.Practices.ObjectBuilder2;

namespace Henkel.Common.Core.Logging.Unity
{
    public class BuildTrackingStrategy : BuilderStrategy
    {

        public override void PreBuildUp(IBuilderContext context)
        {
            IBuildTrackingPolicy policy = BuildTrackingUnityContainerExtension.GetPolicy(context);
            if (policy == null)
            {
                policy = BuildTrackingUnityContainerExtension.SetPolicy(context);
            }

            policy.BuildKeys.Push(context.BuildKey);
        }

        public override void PostBuildUp(IBuilderContext context)
        {
            IBuildTrackingPolicy policy = BuildTrackingUnityContainerExtension.GetPolicy(context);
            if ((policy != null) && (policy.BuildKeys.Count > 0))
            {
                policy.BuildKeys.Pop();
            }
        }
    }
}
