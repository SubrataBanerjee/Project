﻿using Microsoft.Practices.ObjectBuilder2;
using System.Collections.Generic;

namespace Henkel.Common.Core.Logging.Unity
{
    public interface IBuildTrackingPolicy : IBuilderPolicy
    {
        Stack<object> BuildKeys { get; }
    }
}
