﻿using System.Collections.Generic;

namespace Henkel.Common.Core.Logging.Unity.Impl
{
    public class BuildTrackingPolicy : IBuildTrackingPolicy
    {
        public BuildTrackingPolicy()
        {
            this.BuildKeys = new Stack<object>();
        }

        public Stack<object> BuildKeys { get; private set; }
    }
}
