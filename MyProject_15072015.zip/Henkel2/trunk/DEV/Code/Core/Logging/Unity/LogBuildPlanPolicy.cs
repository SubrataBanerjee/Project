﻿using log4net;
using Microsoft.Practices.ObjectBuilder2;
using System;

namespace Henkel.Common.Core.Logging.Unity
{
    public class LogBuildPlanPolicy : IBuildPlanPolicy
    {
        public LogBuildPlanPolicy(Type logType)
        {
            this.LogType = logType;
        }

        public Type LogType { get; private set; }

        public void BuildUp(IBuilderContext context)
        {
            if (context.Existing == null)
            {
                ILog log = LogManager.GetLogger(this.LogType);
                context.Existing = log;
            }
        }
    }
}
