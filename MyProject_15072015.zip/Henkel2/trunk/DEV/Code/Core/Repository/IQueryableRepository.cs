﻿using Henkel.Common.Core.API.Model;
using System;
using System.Linq;
using System.Linq.Expressions;

namespace Henkel.Common.Core.Repository
{
    public interface IQueryableRepository<T> where T : class, IEntity
    {
        /// <summary>
        /// Gets the by id.
        /// </summary>
        /// <param name="id">The id.</param>
        /// <returns></returns>
        T GetById(Guid id, bool checkIsDelete = true);

        
        /// <summary>
        /// Gets the count of records matching the specified searchExpression. If searchExpression is null complete record count in returned.
        /// </summary>
        /// <returns>Total number of matching records count</returns>
        int GetCount(Expression<Func<T, bool>> searchExpression = null, bool checkIsDelete = true);


        /// <summary>
        /// Gets the Query result based on searchExpression and pagination in a form of IQueryable
        /// </summary>
        /// <param name="condition">Search Conditions</param>
        /// <param name="sortExpression">Sort condition</param>
        /// <param name="startRow">This is Page number - default is 0</param>
        /// <param name="maxRows">This is page size (default is -1 which means all the records) </param>
        /// <param name="sortDirection">Sort direction - default is ASC</param>
        /// <param name="checkIsDelete">This is distinguse whther we required to fetch Soft delete records also.</param>
        /// <returns>Matching IQuariable result set</returns>
        IQueryable<T> Find(Expression<Func<T, bool>> condition = null, Expression<Func<T, object>> sortExpression = null, int startRow = 0, int maxRows = -1, string sortDirection = "asc", bool checkIsDelete = true);
    }
}
