﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using Microsoft.Practices.EnterpriseLibrary.Common.Utility;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Data.Entity;
using System.Data.Entity.Core.Metadata.Edm;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;

namespace Henkel.Common.Core.Repository.EntityFramework.Model
{
    public class AppDbContext : DbContext
    {

        private readonly IEnumerable<Assembly> _assemblies;
        private static Dictionary<Type, EntitySetBase> _mappingCache = new Dictionary<Type, EntitySetBase>();

        /// <summary>
        /// Initializes a new instance of the <see cref="AppDbContext"/> class.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <param name="connectionString">The connection string.</param>
        public AppDbContext(IEnumerable<Assembly> assemblies, string connectionString)
            : base(connectionString)
        {
            _assemblies = assemblies;
        }

        /// <summary>
        /// This method is called when the model for a derived context has been initialized, but
        /// before the model has been locked down and used to initialize the context.  The default
        /// implementation of this method does nothing, but it can be overridden in a derived class
        /// such that the model can be further configured before it is locked down.
        /// </summary>
        /// <param name="modelBuilder">The builder that defines the model for the context being created.</param>
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            AddCustomEntityConfigurations(_assemblies, modelBuilder);
            CreateModelFromAssemblies(_assemblies, modelBuilder);

            base.OnModelCreating(modelBuilder);
        }


        public override int SaveChanges()
        {
            foreach (var entry in ChangeTracker.Entries().Where(p => p.State == EntityState.Deleted))
            {
                if(entry.Entity is ISupportSoftDelete)
                    SoftDelete(entry);
            }

            return base.SaveChanges();
        }

        #region Helper Methods

        /// <summary>
        /// Adds the custom entity configurations.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <param name="modelBuilder">The model builder.</param>
        private static void AddCustomEntityConfigurations(IEnumerable<Assembly> assemblies, DbModelBuilder modelBuilder)
        {
            var contextConfiguration = new ContextConfiguration();
            var aggregateCatalog = new AggregateCatalog();
            foreach (var catalog in assemblies.Select(assembly => new AssemblyCatalog(assembly)))
            {
                aggregateCatalog.Catalogs.Add(catalog);
            }
            var container = new CompositionContainer(aggregateCatalog);
            container.ComposeParts(contextConfiguration);

            contextConfiguration.Configurations.ForEach(config => config.AddConfiguration(modelBuilder.Configurations));
        }

        /// <summary>
        /// Creates the model from assemblies.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <param name="modelBuilder">The model builder.</param>
        private static void CreateModelFromAssemblies(IEnumerable<Assembly> assemblies, DbModelBuilder modelBuilder)
        {
            var entityTypes = GetValidEntities(assemblies);

            foreach (var entityType in entityTypes)
            {
                try
                {
                    AddEntityTypeToModel(entityType, modelBuilder);
                }
                catch (Exception e)
                {
                    throw new RepositoryException(string.Format("Error adding to model, entity: {0}. Original exception: {1}", entityType.Name, e.Message));
                }
            }
        }

        /// <summary>
        /// Gets the valid entities.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <returns></returns>
        private static IEnumerable<Type> GetValidEntities(IEnumerable<Assembly> assemblies)
        {
            Type entityInterfaceType = typeof(IEntity);
            return
                assemblies.SelectMany(x => x.GetTypes()).Where(entityInterfaceType.IsAssignableFrom).Where(
                    t => !t.IsInterface && !t.IsAbstract);
        }

        /// <summary>
        /// Adds the entity type to model.
        /// </summary>
        /// <param name="entityType">Type of the entity.</param>
        /// <param name="modelBuilder">The model builder.</param>
        private static void AddEntityTypeToModel(Type entityType, DbModelBuilder modelBuilder)
        {
            Type modelBuilderType = modelBuilder.GetType();
            MethodInfo method = modelBuilderType.GetMethod("Entity").MakeGenericMethod(entityType);
            method.Invoke(modelBuilder, null);
        }

        private void SoftDelete(DbEntityEntry entry)
        {
            Type entryEntityType = entry.Entity.GetType();

            string tableName = GetTableName(entryEntityType);
            string primaryKeyName = GetPrimaryKeyName(entryEntityType);

            string sql = string.Format("UPDATE {0} SET IsDeleted = 1 WHERE {1} = @id", tableName, primaryKeyName);

            Database.ExecuteSqlCommand(sql, new SqlParameter("@id", entry.OriginalValues[primaryKeyName]));

            // prevent hard delete            
            entry.State = EntityState.Detached;
        }

        private string GetTableName(Type type)
        {
            EntitySetBase es = GetEntitySet(type);

            return string.Format("[{0}].[{1}]",
                es.MetadataProperties["Schema"].Value,
                es.MetadataProperties["Table"].Value);
        }

        private string GetPrimaryKeyName(Type type)
        {
            EntitySetBase es = GetEntitySet(type);

            return es.ElementType.KeyMembers[0].Name;
        }

        private EntitySetBase GetEntitySet(Type type)
        {
            if (!_mappingCache.ContainsKey(type))
            {
                ObjectContext octx = ((IObjectContextAdapter)this).ObjectContext;

                string typeName = ObjectContext.GetObjectType(type).Name;

                var es = octx.MetadataWorkspace
                                .GetItemCollection(DataSpace.SSpace)
                                .GetItems<EntityContainer>()
                                .SelectMany(c => c.BaseEntitySets
                                                .Where(e => e.Name == typeName))
                                .FirstOrDefault();

                if (es == null)
                    throw new ArgumentException("Entity type not found in GetTableName", typeName);

                _mappingCache.Add(type, es);
            }

            return _mappingCache[type];
        }

        #endregion
    }
}
