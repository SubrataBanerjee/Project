﻿using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Common.Core.Repository.EntityFramework.Configuration
{
    /// <summary>
    /// Entity Configuration for Custom EntityFramework Entity Configurations
    /// </summary>
    public interface IEntityConfiguration
    {
        /// <summary>
        /// Adds the configuration.
        /// </summary>
        /// <param name="registrar">The registrar.</param>
        void AddConfiguration(ConfigurationRegistrar registrar);
    }
}
