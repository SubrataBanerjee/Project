﻿using Henkel.Common.Core.API.Model;
using System;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl
{
    public class EFSession : IEFSession
    {
        private DbContext _currentContext;
        private readonly bool _isReadWrite;
        private DbContextTransaction _transaction;
        private static int _objectId = 0;

        public EFSession(DbContext dbContext, bool isReadWrite, IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            _objectId += 1;
            Console.WriteLine("Initializing {0}", SessionId);

            _currentContext = dbContext;
            _isReadWrite = isReadWrite;
            if (_isReadWrite)
                _transaction = _currentContext.Database.BeginTransaction(isolationLevel);
        }

        #region Implementation of IEFSession

        public string SessionId
        {
            get
            {
                return string.Format("Session Id: {0}", _objectId);
            }
        }

        public void Commit()
        {
            Console.WriteLine("Commit {0}", SessionId);
            SaveChanges();

            if (_transaction != null)
                _transaction.Commit();
        }

        public void Rollback()
        {
            Console.WriteLine("Rollback {0}", SessionId);
            if (_transaction != null)
                _transaction.Rollback();
        }

        public void SaveChanges()
        {
            Console.WriteLine("SaveChanges {0}", SessionId);
            if (_isReadWrite)
                _currentContext.SaveChanges();
        }

        public void Dispose()
        {
            Console.WriteLine("Dispose {0}", SessionId);
            if (_transaction != null)
            {
                _transaction.Dispose();
                _transaction = null;
            }

            //if (_currentContext != null)
            //{
            //    _currentContext.Dispose();
            //    _currentContext = null;
            //}
        }

        public bool IsReadOnly
        {
            get { return !_isReadWrite; }
        }

        public DbSet Set(Type entityType)
        {
            return _currentContext.Set(entityType);
        }

        public DbSet<T> Set<T>() where T : class, IEntity
        {
            return _currentContext.Set<T>();
        }

        public DbEntityEntry Entry(object obj)
        {
            return _currentContext.Entry(obj);
        }

        public DbEntityEntry<T> Entry<T>(T obj) where T : class, IEntity
        {
            return _currentContext.Entry<T>(obj);
        }

        #endregion
    }
}
