﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Expressions;
using Henkel.Common.Core.Repository.EntityFramework.Transaction;
using System;
using System.Data.Entity;
using System.Linq;
using System.Linq.Expressions;

namespace Henkel.Common.Core.Repository.EntityFramework.Impl
{
    public class EFQueryableRepository<T> : EFBaseRepository<T>, IQueryableRepository<T> where T : class, IEntity
    {
        #region Implementation of IQueryableRepository<T>

        public T GetById(Guid id, bool checkIsDelete = true)
        {
            var lambdaExpression = LambdaHelper.GetBinaryEqualityExpression<T>(KeyProperty, id);

            IQueryable<T> resultCollection = Find(lambdaExpression, checkIsDelete: checkIsDelete);
            if (resultCollection != null)
                return resultCollection.FirstOrDefault();

            return null;
        }


        public int GetCount(Expression<Func<T, bool>> searchExpression = null, bool checkIsDelete = true)
        {
            IQueryable<T> query = CurrentSession.Set<T>();

            if (checkIsDelete && IsSupportSoftDelete)
                //query = query.Where("IsDeleted == false");

            if (searchExpression != null)
                query = query.Where(searchExpression);

            if (CurrentSession.IsReadOnly)
                query.AsNoTracking();

            return query.Count();
        }


        public IQueryable<T> Find(Expression<Func<T, bool>> condition = null, Expression<Func<T, object>> sortExpression = null, int startRow = 0, int maxRows = -1, string sortDirection = "asc", bool checkIsDelete = true)
        {
            return Find(CurrentSession, condition, sortExpression, startRow, maxRows, sortDirection, checkIsDelete && IsSupportSoftDelete);
        }

        #endregion

        #region helper Methods



        private static IQueryable<T> Find(IEFSession currentSession, Expression<Func<T, bool>> condition, Expression<Func<T, object>> sortExpression = null, int startRow = 0, int maxRows = -1, string sortDirection = "asc", bool checkSoftDelete = true)
        {
            IQueryable<T> query = currentSession.Set<T>();
            if (checkSoftDelete)
            {
                //query = query.Where("IsDeleted == false");
            }

            if (currentSession.IsReadOnly)
                query = query.AsNoTracking();

            //query = options.Includes.Aggregate(query, (current, include) => current.Include(include));

            if (condition != null)
                query = query.Where(condition);

            if (sortExpression != null)
            {
                query = sortDirection.ToLower() == "asc" ? query.OrderBy(sortExpression) : query.OrderByDescending(sortExpression);
            }

            if (startRow > 0)
                query = query.Skip(startRow - 1);

            if (maxRows > 0)
                query = query.Take(maxRows);

            return query;
        }

        #endregion
    }
}
