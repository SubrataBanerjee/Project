﻿using Henkel.Common.Core.Repository.EntityFramework.Model;
using System.Collections.Generic;
using System.Data;
using System.Reflection;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl
{
    public class EFSessionFactory : IEFSessionFactory
    {
        #region Fields

        private readonly IEnumerable<Assembly> _allAssemblies;
        private readonly string _connectionString;
        #endregion

        #region Constructors


        public EFSessionFactory(IEnumerable<Assembly> allAssemblies, string connectionString)
        {
            _allAssemblies = allAssemblies;
            _connectionString = connectionString;
        }

        #endregion

        #region Implementation of IEFSessionFactory

        public IEFSession OpenSession(bool isReadWrite, IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            var appDbContext = new AppDbContext(_allAssemblies, _connectionString);
            return new EFSession(appDbContext, isReadWrite, isolationLevel);
        }

        #endregion
    }
}
