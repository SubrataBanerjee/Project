﻿using System.Data;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction
{
    public interface IEFSessionFactory
    {
        IEFSession OpenSession(bool isReadWrite, IsolationLevel isolationLevel);
    }
}
