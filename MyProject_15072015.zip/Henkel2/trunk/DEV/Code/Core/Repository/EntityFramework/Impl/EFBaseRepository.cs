﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Repository.EntityFramework.Model;
using Henkel.Common.Core.Repository.EntityFramework.Transaction;

namespace Henkel.Common.Core.Repository.EntityFramework.Impl
{
    public class EFBaseRepository<T> : BaseRepository<T> where T : class, IEntity
    {
        protected IEFSession CurrentSession
        {
            get
            {
                return EFWorkspace.CurrentSession;
            }
        }
    }
}
