﻿using Henkel.Common.Core.API.Model;
using System;

namespace Henkel.Common.Core.Repository.EntityFramework.Impl
{
    public class EFReadWriteRepository<T> : EFQueryableRepository<T>, IReadWriteRepository<T> where T : class, IEntity
    {
        #region Implementation of IReadWriteRepository<T>

        /// <summary>
        /// Adds the specified entity to DbContext.
        /// </summary>
        /// <param name="obj">The obj.</param>
        /// <returns></returns>
        public T Add(T obj)
        {
            if (IsAuditEntity)
                ((IAuditEntity)obj).SetCreationInfo();

            var savedObj = CurrentSession.Set<T>().Add(obj);
            CurrentSession.SaveChanges();

            if (IsAuditTrailEntity)
                ((IAuditTrailEntity)obj).CreateAuditTrail(AuditAction.Insert);

            return savedObj;
        }


        /// <summary>
        /// Updates the specified entity to DbContext.
        /// </summary>
        /// <param name="obj">The obj.</param>
        public void Update(T entity)
        {
            Update(entity, AuditAction.Modify);
        }


        /// <summary>
        /// Deletes the specified entity from DbContext.
        /// </summary>
        /// <param name="id">The id.</param>
        public void Delete(Guid id)
        {
            var obj = GetById(id);
            Delete(obj);
        }

        /// <summary>
        /// Deletes the specified entity from DbContext.
        /// </summary>
        /// <param name="T obj">The entity Object.</param>
        public void Delete(T obj)
        {
            if (obj != null)
            {
                if (IsSupportSoftDelete)
                    ((ISupportSoftDelete)obj).MarkAsDelete();

                if (IsAuditEntity)
                    ((IAuditEntity)obj).SetModificationInfo();

                if (IsAuditTrailEntity)
                    ((IAuditTrailEntity)obj).CreateAuditTrail(AuditAction.Delete);

                CurrentSession.Set<T>().Remove(obj);
                CurrentSession.SaveChanges();

                //if (IsSupportSoftDelete)
                //{
                //    ((ISupportSoftDelete)obj).MarkAsDelete();
                //    Update(obj, AuditAction.Delete);
                //}
                //else
                //{
                //    if (IsAuditTrailEntity)
                //        ((IAuditTrailEntity)obj).CreateAuditTrail(AuditAction.Delete);

                //    CurrentSession.Set<T>().Remove(obj);
                //    CurrentSession.SaveChanges();
                //}
            }
        }

        #endregion

        #region Helper Methods

        private void Update(T entity, AuditAction auditAction)
        {
            if (IsAuditEntity)
                ((IAuditEntity)entity).SetModificationInfo();

            CurrentSession.SaveChanges();

            if (IsAuditTrailEntity)
                ((IAuditTrailEntity)entity).CreateAuditTrail(auditAction);
        }

        #endregion
    }
}
