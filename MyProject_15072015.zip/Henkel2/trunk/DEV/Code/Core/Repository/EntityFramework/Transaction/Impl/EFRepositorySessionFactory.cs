﻿using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.Repository.EntityFramework.Model;
using System.Data;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl
{
    public class EFRepositorySessionFactory : IRepositorySessionFactory
    {
        #region Implementation of IRepositorySessionFactory

        public IRepositorySession GetNewSession(bool isReadWrite, IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            return new EFRepositorySession(isReadWrite, isolationLevel);
        }

        public bool RepositorySessionExists()
        {
            return EFWorkspace.CurrentSession != null;
        }

        public void Unbind()
        {
            //No Implementation - Ignore
        }

        #endregion
    }
}
