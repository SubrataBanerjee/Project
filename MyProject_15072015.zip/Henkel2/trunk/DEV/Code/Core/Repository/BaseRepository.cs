﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Repository;
using System;
using System.Linq;

namespace Henkel.Common.Core.Repository
{
    public class BaseRepository<T> : IRepository<T> where T : class, IEntity
    {
        #region Fields

        private readonly Type[] _interfaces;
        private bool? _isSupportSoftDelete;
        private bool? _isAuditEntity;
        private bool? _isAuditTrailEntity;

        #endregion

        #region Constructors

        public BaseRepository()
        {
            var type = typeof(T);
            _interfaces = type.GetInterfaces();
        }

        #endregion

        #region Protected Members

        protected const string KeyProperty = "Id";

        protected bool IsSupportSoftDelete
        {
            get
            {
                if (_isSupportSoftDelete == null)
                    _isSupportSoftDelete = _interfaces.Any(x => x == typeof(ISupportSoftDelete));
                return _isSupportSoftDelete.Value;
            }
        }

        protected bool IsAuditEntity
        {
            get
            {
                if (_isAuditEntity == null)
                    _isAuditEntity = _interfaces.Any(x => x == typeof(IAuditEntity));

                return _isAuditEntity.Value;
            }
        }

        protected bool IsAuditTrailEntity
        {
            get
            {
                if (_isAuditTrailEntity == null)
                    _isAuditTrailEntity = _interfaces.Any(x => x == typeof(IAuditTrailEntity));

                return _isAuditTrailEntity.Value;
            }
        }

        #endregion

        #region Helper Methods


        #endregion
    }
}
