﻿using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.Services;
using Henkel.Common.Core.Utils.Unity;
using Microsoft.Practices.Unity;
using System;

namespace Henkel.Common.Core.Caching.Services.Impl
{
    public class CachingService : BaseService, ICachingService
    {
        public T Get<T>(string cacheKey, Func<T> fallback, CachingOptions options) where T : class
        {
            var cacheProvider = UnityContainerFactory.Instance.Resolve<ICachedDataSource>(options.CacheType.ToString()) ??
                                UnityContainerFactory.Instance.Resolve<ICachedDataSource>();
            return cacheProvider != null ? cacheProvider.RetrieveCachedData(cacheKey, fallback, options.CachePolicy) : null;
        }

        public void Remove(string key, CacheType cacheType)
        {
            var cacheProvider = UnityContainerFactory.Instance.Resolve<ICachedDataSource>(cacheType.ToString()) ??
                                UnityContainerFactory.Instance.Resolve<ICachedDataSource>();
            if (cacheProvider != null) cacheProvider.RemoveCachedData(key);
        }

        public void RemoveAll(CacheType cacheType)
        {
            var cacheProvider = UnityContainerFactory.Instance.Resolve<ICachedDataSource>(cacheType.ToString()) ??
                                UnityContainerFactory.Instance.Resolve<ICachedDataSource>();
            if (cacheProvider != null) cacheProvider.ClearAll();
        }
    }
}
