﻿using System;
using System.Collections;
using System.Runtime.Caching;
using System.Web;

namespace Henkel.Common.Core.Caching.Services.Impl
{
    public class LocalCachedDataSource : ICachedDataSource
    {
        public T RetrieveCachedData<T>(string cacheKey, Func<T> fallback, CacheItemPolicy policy) where T : class
        {
            var item = HttpRuntime.Cache.Get(cacheKey) as T;
            if (item == null)
            {
                item = fallback();
                if (item != null)
                {
                    //TODO[Subrata]: Uncomment this below block of code to work Caching
                    //if (policy == null)
                    //    HttpRuntime.Cache.Insert(cacheKey, item);
                    //else
                    //    HttpRuntime.Cache.Insert(cacheKey, item, null, policy.AbsoluteExpiration.DateTime, policy.SlidingExpiration);
                }
            }
            return item;
        }

        public void RemoveCachedData(string cacheKey)
        {
            HttpRuntime.Cache.Remove(cacheKey);
        }

        public void ClearAll()
        {
            foreach (DictionaryEntry item in HttpRuntime.Cache)
            {
                var key = item.Key as string;
                if (key != null)
                    RemoveCachedData(key);
            }
        }
    }
}
