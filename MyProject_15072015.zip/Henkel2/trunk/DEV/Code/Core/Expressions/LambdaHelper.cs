﻿using Henkel.Common.Core.API.Model;
using System;
using System.Linq.Expressions;

namespace Henkel.Common.Core.Expressions
{
    /// <summary>
    /// Lambda Helper class to create a Lambda Expressions
    /// </summary>
    public static class LambdaHelper
    {
        /// <summary>
        /// Gets the binary equality expression.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="propertyName">Name of the property.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static Expression<Func<T, bool>> GetBinaryEqualityExpression<T>(string propertyName, object value)
        {
            var xParam = Expression.Parameter(typeof(T), typeof(T).Name);
            MemberExpression leftExpr = Expression.Property(xParam, propertyName);
            Expression rightExpr = Expression.Constant(value);
            BinaryExpression binaryExpr = Expression.Equal(leftExpr, rightExpr);

            return Expression.Lambda<Func<T, bool>>(binaryExpr, new[] { xParam });
        }

        public static Expression<Func<T, object>> GetMemberExpression<T>(string sortField) where T : class, IEntity
        {
            Expression param = Expression.Parameter(typeof(T), "item");
            return Expression.Lambda<Func<T, object>>(Expression.Convert(GetPropertyExpression(sortField, param), typeof(object)), (ParameterExpression)param);
        }

        public static MemberExpression GetPropertyExpression(string sortField, Expression param)
        {
            if (sortField.IndexOf(".", StringComparison.Ordinal) == -1)
                return Expression.Property(param, sortField);

            int lastIndexOfDot = sortField.LastIndexOf(".", StringComparison.Ordinal);
            return Expression.Property(GetPropertyExpression(sortField.Substring(0, lastIndexOfDot), param), sortField.Substring(lastIndexOfDot + 1));
        }
    }
}
