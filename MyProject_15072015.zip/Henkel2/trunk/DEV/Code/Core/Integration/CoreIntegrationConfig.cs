﻿using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.API.Events.Services;
using Henkel.Common.Core.API.Logging.Services;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Caching.Services;
using Henkel.Common.Core.Caching.Services.Impl;
using Henkel.Common.Core.Events.Services.Impl;
using Henkel.Common.Core.Integration.Services.Impl;
using Henkel.Common.Core.Logging.Services.Impl;
using Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl;
using Henkel.Common.Core.Services.Impl;
using Microsoft.Practices.Unity;
using System.Runtime.Caching;

namespace Henkel.Common.Core.Integration
{
    public class CoreIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterLoggers(container);
            CachingServices(container);
            RegisterRepositories(container);
            RegisterServices(container);
            RegisterEventHandlers(container);
        }

        #region Helper Methods

        

        private void RegisterLoggers(IUnityContainer container)
        {
            container.RegisterType<ILoggingService, Log4NetLoggingService>(new ContainerControlledLifetimeManager());
        }

        private void CachingServices(IUnityContainer container)
        {
            container.RegisterType<ICachingService, CachingService>(new ContainerControlledLifetimeManager());
            container.RegisterType<ICachedDataSource, DistributedCachedDataSource>(CacheType.Distributed.ToString(), new ContainerControlledLifetimeManager());
            container.RegisterType<ICachedDataSource, LocalCachedDataSource>(CacheType.Local.ToString(), new ContainerControlledLifetimeManager());
            container.RegisterInstance(typeof(ObjectCache), MemoryCache.Default, new ContainerControlledLifetimeManager());
        }

        private void RegisterRepositories(IUnityContainer container)
        {
            container.RegisterType<IRepositorySessionFactory, EFRepositorySessionFactory>(new ContainerControlledLifetimeManager());
        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<IUserContextService, ThreadLocalUserContextService>(new ContainerControlledLifetimeManager());
            
        }


        private void RegisterEventHandlers(IUnityContainer container)
        {
            container.RegisterType<IEventDispatcherService, InMemoryEventDispatcherService>(new ContainerControlledLifetimeManager());
        }



        #endregion
    }
}
