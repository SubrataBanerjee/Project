﻿using Henkel.Common.Core.API.Integration.Services;
using Microsoft.Practices.Unity;

namespace Henkel.Common.Core.Integration.Services.Impl
{
    public abstract class IntegrationConfigBase : IRegisterWithUnityService
    {
        public abstract void RegisterTypes(IUnityContainer container);
    }
}
