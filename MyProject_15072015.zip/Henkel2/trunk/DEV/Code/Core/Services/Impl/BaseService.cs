﻿
namespace Henkel.Common.Core.Services
{
    public class BaseService
    {
    }
}
