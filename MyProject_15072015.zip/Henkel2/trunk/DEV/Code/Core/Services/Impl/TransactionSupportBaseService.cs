﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Repository.Transaction;

namespace Henkel.Common.Core.Services.Impl
{
    public class TransactionSupportBaseService : BaseService
    {
        #region Fields

        private readonly IRepositorySessionFactory _repositorySessionFactory;

        #endregion

        #region Constructors

        public TransactionSupportBaseService()
        {
            _repositorySessionFactory = ObjectLocator.GetObject<IRepositorySessionFactory>();
        }

        #endregion

        #region Properties

        protected IRepositorySession RepositorySession
        {
            get
            {
                return _repositorySessionFactory.GetNewSession(true);
            }
        }

        protected IRepositorySession RepositoryReadOnlySession
        {
            get
            {
                return _repositorySessionFactory.GetNewSession(false);
            }
        }


        #endregion
    }
}
