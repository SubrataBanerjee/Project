﻿using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Tests.Repository.Helper;
using Henkel.Business.Kernel.Tests;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.SupportForTests.Repository;
using Henkel.Common.SupportForTests.Repository.EntityFramework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Configuration;

namespace Henkel.Business.Kernel.Security.Tests.Repository.EntityFramework
{
    //[Ignore]
    [TestClass]
    public class UserRepositoryTest :  RequireEFDatabaseSupport
    {
        #region Fields

        private IUserRepository _userRepository;
        private UserRepositoryTestHelper _userRepositoryTestHelper;

        #endregion

        #region Settings

        protected override DatabaseInfo DatabaseInfo
        {
            get
            {
                return new DatabaseInfo
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings[FileLocator.CONNECTION_STRING_KEY].ToString(),
                    XSDPath = FileLocator.Schema.COMMON,
                    DataFiles = {
                                    FileLocator.DataFile.SYSTEM_DATA,
                                    FileLocator.DataFile.BASE_DATA,
                                    FileLocator.DataFile.USER,
                                }
                };
            }
        }

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _userRepository = ObjectLocator.GetObject<IUserRepository>();
            _userRepositoryTestHelper = new UserRepositoryTestHelper(_userRepository);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            DatabaseSupportCleanup();
        }

        #endregion

        #region Tests

        #region Query Tests


        [TestMethod]
        public void EFShouldGetUserCountBySearchExpression()
        {
            _userRepositoryTestHelper.ShouldGetUserCountBySearchExpression();
        }

        [TestMethod]
        public void EFShouldGetUserById()
        {
            _userRepositoryTestHelper.ShouldGetUserById();
        }

        [TestMethod]
        public void EFShouldFindAllUsersWithoutAnySearchExpressionAndPagination()
        {
            _userRepositoryTestHelper.ShouldFindAllUsersWithoutAnySearchExpressionAndPagination();
        }
        
        [TestMethod]
        public void EFShouldFindAllUsersWithPagination()
        {
            _userRepositoryTestHelper.ShouldFindAllUsersWithPagination();
        }

        [TestMethod]
        public void EFShouldFindUserBySearchExpressionAndPagination()
        {
            _userRepositoryTestHelper.ShouldFindUserBySearchExpressionAndPagination();
        }

        [TestMethod]
        public void EFShouldFindUserBySearchExpression()
        {
            _userRepositoryTestHelper.ShouldFindUserBySearchExpression();
        }

        #endregion

        #region Command tests

        [TestMethod]
        public void EFShouldAddUser()
        {
            _userRepositoryTestHelper.ShouldAddUser();
        }

        [TestMethod]
        public void EFShouldRollbackTransactionOnFailureToAddForMultipleRecords()
        {
            _userRepositoryTestHelper.ShouldRollbackTransactionOnFailureToAddForMultipleRecords();
        }

        [TestMethod]
        public void EFShouldUpdateUser()
        {
            _userRepositoryTestHelper.ShouldUpdateUser();
        }

        [TestMethod]
        public void EFShouldDeleteUser()
        {
            _userRepositoryTestHelper.ShouldDeleteUser();
        }

        #endregion

        #endregion
    }
}
