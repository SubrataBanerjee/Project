﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.DTO.SearchCriteria;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Tests;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.SupportForTests.Repository;
using Henkel.Common.SupportForTests.Repository.EntityFramework;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Configuration;

namespace Henkel.Business.Kernel.Security.Tests.Services
{
    [TestClass]
    public class UserManagementServiceTest : RequireEFDatabaseSupport
    {
        #region Fields

        private IUserManagementService _userManagementService;

        #endregion

        #region Settings

        protected override DatabaseInfo DatabaseInfo
        {
            get
            {
                return new DatabaseInfo
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings[FileLocator.CONNECTION_STRING_KEY].ToString(),
                    XSDPath = FileLocator.Schema.COMMON,
                    DataFiles = {
                                    FileLocator.DataFile.SYSTEM_DATA,
                                    FileLocator.DataFile.BASE_DATA,
                                    FileLocator.DataFile.USER,
                                    FileLocator.DataFile.PASSWORD_HISTORY,
                                    FileLocator.DataFile.EMAIL_TEMPLATE,
                                }
                };
            }
        }

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _userManagementService = ObjectLocator.GetService<IUserManagementService>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            DatabaseSupportCleanup();
        }

        #endregion

        #region Tests

        #region Positive Tests

        #region Query Tests


        [TestMethod]
        public void ShouldGetUserById()
        {
            var userId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");
            var userDto = _userManagementService.GetUserById(userId);

            Assert.IsNotNull(userDto);
            Assert.AreEqual(userId, userDto.UserId);
            Assert.AreEqual("User00", userDto.LoginId);
            Assert.AreEqual("System", userDto.CreatedBy);
            Assert.AreEqual("System", userDto.LastModifiedBy);
            Assert.AreEqual(Convert.ToDateTime("2015-01-01T10:32:52Z").ToString("ddMMyyyy"), userDto.CreatedOn.Value.ToString("ddMMyyyy"));
            Assert.AreEqual(Convert.ToDateTime("2015-01-01T10:32:52Z").ToString("ddMMyyyy"), userDto.LastModifiedOn.Value.ToString("ddMMyyyy"));
            Assert.AreEqual(true, userDto.IsActive);
            Assert.AreEqual(false, userDto.IsDeleted);
        }

        [TestMethod]
        public void ShouldFindUserByCriteriaAndPageInfoAsAPaginatedResult()
        {
            var criteria = new UserSearchCriteria
            {
                IsActive = true
            };

            var pageInfo = new PageInfo
            {
                PageSize = 5,
                StartRow = 6,
                SortField = "Name",
                SortDirection = false
            };

            var page = _userManagementService.FindUserByCriteria(criteria, pageInfo);

            Assert.IsNotNull(page);
            Assert.AreEqual(7, page.TotalRecord);
            Assert.AreEqual(2, page.Data.Count);
        }

        [TestMethod]
        public void ShouldFindUserByCriteriaAsAListResult()
        {
            var criteria = new UserSearchCriteria
            {
                IsActive = true
            };

            var result = _userManagementService.FindUserByCriteria(criteria);

            Assert.IsNotNull(result);
            Assert.AreEqual(7, result.Count);
        }

        [TestMethod]
        public void ShouldGetAllUsersAsAPaginatedResult()
        {
            var pageInfo = new PageInfo
            {
                PageSize = 5,
                StartRow = 6,
                SortField = "Name",
                SortDirection = false
            };

            var page = _userManagementService.GetAllUsers(pageInfo);

            Assert.IsNotNull(page);
            Assert.AreEqual(8, page.TotalRecord);
            Assert.AreEqual(3, page.Data.Count);
        }

        [TestMethod]
        public void ShouldGetAllUsersAsAListResult()
        {
            var result = _userManagementService.GetAllUsers();
            Assert.IsNotNull(result);
            Assert.AreEqual(8, result.Count);
        }

        #endregion

        #region Command Tests

        [TestMethod]
        public void ShouldAddUser()
        {
            var userDtoToAdd = GetDefaultUserDto();
            var savedUserDtoId = _userManagementService.AddUser(userDtoToAdd);
            var savedUserDto = _userManagementService.GetUserById(savedUserDtoId);

            Assert.IsNotNull(savedUserDto);

            Assert.AreEqual(savedUserDtoId, savedUserDto.UserId);
            Assert.AreEqual(userDtoToAdd.LoginId, savedUserDto.LoginId);
            Assert.AreEqual(userDtoToAdd.IsActive, savedUserDto.IsActive);
            Assert.AreEqual(userDtoToAdd.IsDeleted, savedUserDto.IsDeleted);
        }

        [TestMethod]
        public void ShouldUpdateUser()
        {
            var userDtoToUpdate = GetDefaultUserDto();
            userDtoToUpdate.UserId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");

            //There is no fields to Update in User for now

            _userManagementService.UpdateUser(userDtoToUpdate);

            var savedUserDto = _userManagementService.GetUserById(userDtoToUpdate.UserId);

            Assert.IsNotNull(savedUserDto);
            Assert.AreEqual("User00", savedUserDto.LoginId);
        }

        [TestMethod]
        public void ShouldDeleteUser()
        {
            var userId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");

            _userManagementService.DeleteUser(userId);

            var deletedUser = _userManagementService.GetUserById(userId);

            Assert.IsNull(deletedUser);
        }

        [TestMethod]
        public void ShouldMarkUserAsEnabled()
        {
            var userId = new Guid("841A8DEB-81AB-4035-89A9-CE926CCFB185");

            var user = _userManagementService.GetUserById(userId);
            Assert.IsFalse(user.IsActive);

            _userManagementService.MarkUserAsEnabled(userId);

            user = _userManagementService.GetUserById(userId);

            Assert.IsTrue(user.IsActive);
        }

        [TestMethod]
        public void ShouldMarkUserAsDisabled()
        {
            var userId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");

            var user = _userManagementService.GetUserById(userId);
            Assert.IsTrue(user.IsActive);

            _userManagementService.MarkUserAsDisabled(userId);

            user = _userManagementService.GetUserById(userId);

            Assert.IsFalse(user.IsActive);
        }

        #endregion

        #endregion

        #region Negetive Tests

        #region Query Tests



        #endregion

        #region Command Tests


        #endregion

        #endregion

        #endregion

        #region Helper Methods

        private static UserDto GetDefaultUserDto()
        {
            var userId = new Guid("FA10D3AA-00DC-46A0-AE2C-0BB1CB1C71FB");

            return new UserDto()
            {
                UserId = userId,
                LoginId = "Test",
                IsActive = true,
                IsDeleted = false,
                CreatedBy = "System",
                LastModifiedBy = "System",
                CreatedOn = DateTime.UtcNow,
                LastModifiedOn = DateTime.UtcNow,
            };
        }

        #endregion
    }
}
