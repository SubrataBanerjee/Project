﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Services;
using Henkel.Business.Kernel.Tests;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.SupportForTests.Attributes;
using Henkel.Common.SupportForTests.Repository;
using Henkel.Common.SupportForTests.Repository.EntityFramework;
using Henkel.Common.SupportForTests.Utils;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.ObjectModel;
using System.Configuration;

namespace Henkel.Business.Kernel.Security.Tests.Services
{
    [TestClass]
    public class PasswordHistoryValidationServiceTest : RequireEFDatabaseSupport
    {
        #region Fields

        private IUserRepository _userRepository;

        private IPasswordHistoryValidationService _passwordHistoryValidationService;

        #endregion

        #region Settings

        protected override DatabaseInfo DatabaseInfo
        {
            get
            {
                return new DatabaseInfo
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings[FileLocator.CONNECTION_STRING_KEY].ToString(),
                    XSDPath = FileLocator.Schema.COMMON,
                    DataFiles = {
                                    FileLocator.DataFile.SYSTEM_DATA,
                                    FileLocator.DataFile.BASE_DATA,
                                    FileLocator.DataFile.USER,
                                    FileLocator.DataFile.PASSWORD_HISTORY
                                }
                };
            }
        }

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _userRepository = ObjectLocator.GetObject<IUserRepository>();
            _passwordHistoryValidationService = ObjectLocator.GetObject<IPasswordHistoryValidationService>();
        }

        [TestCleanup]
        public void TestCleanup()
        {
            DatabaseSupportCleanup();
        }

        #endregion

        #region Tests

        #region Positive tests

        [TestMethod]
        public void ShouldNotThrowErrorForNewPasswordWhichIsNotPresentInHistory()
        {
            //Test with actual data in DB
            using(RepositoryReadOnlySession)
            {
                var userIdHavinghPasswordHistory = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");
                var user = _userRepository.GetById(userIdHavinghPasswordHistory);

                _passwordHistoryValidationService.Validate(user, "xyz&1234");
            }
        }



        [NoDataRequired]
        [TestMethod]
        public void ShouldNotThrowErrorForNewPasswordWhichIsNotPresentInHistoryWithDummyData()
        {
            //Test with Dummy data

            var user = GetDefaultUser();
            _passwordHistoryValidationService.Validate(user, "xyz@1234");
        }

        [NoDataRequired]
        [TestMethod]
        public void ShouldValidateSuccessfullyWithExistingHistoryPasswordButOutOfExceedingLimit3()
        {
            //Test with Dummy data

            var user = GetDefaultUser();
            _passwordHistoryValidationService.Validate(user, "abc&1234");
        }

        #endregion

        #region Negetive tests

        [NoDataRequired]
        [TestMethod]
        public void ShouldThrowErrorForMatchingHistoryPasswordLimit3()
        {
            //Test with Dummy data

            var user = GetDefaultUser();

            var exception = TestHelperUtil.AssertThrows<ValidationException>(() =>  _passwordHistoryValidationService.Validate(user, "def@1234"));
            
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.NewPasswordShouldNotBeSameAsLastUsedPassword, exception.Message);
        }

        #endregion

        #endregion

        #region Helper methods

        private static User GetDefaultUser()
        {
            var user = new User
            {
                Id = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520"),
                PasswordHistories = new Collection<PasswordHistory>
                {
                    new PasswordHistory
                    {
                        Id = Guid.NewGuid(),
                        Password = "g6D+bEA71S0hqf7ZmPSMekzYfVndkt8tZ4rW16CPH48=", // abc@1234
                        CreatedOn = DateTime.UtcNow.AddDays(-5)
                    },
                    new PasswordHistory
                    {
                        Id = Guid.NewGuid(),
                        Password = "WcRkYtw40nBl4pZdjZskWFQ+gQpqRxXuZRt81NK6VcU=", // def@1234
                        CreatedOn = DateTime.UtcNow.AddDays(-4)
                    },
                    new PasswordHistory
                    {
                        Id = Guid.NewGuid(),
                        Password = "4elBWasU1RAUchg1PoHg2pQnVcOsT4q1Jx56fN/NNso=", // ghi@1234
                        CreatedOn = DateTime.UtcNow.AddDays(-3)
                    },
                    new PasswordHistory
                    {
                        Id = Guid.NewGuid(),
                        Password = "5+TgeuNX5XiS5rjujpH1tSjfu/ZdAPYYTrD8hMgipB0=", // jkl@1234
                        CreatedOn = DateTime.UtcNow.AddDays(-2)
                    },
                },
            };
            return user;
        }

        #endregion
    }
}
