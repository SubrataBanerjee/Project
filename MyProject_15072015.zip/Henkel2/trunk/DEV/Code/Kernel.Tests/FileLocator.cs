﻿
namespace Henkel.Business.Kernel.Tests
{
    internal class FileLocator
    {
        internal const string CONNECTION_STRING_KEY = "Henkel.Business.Kernel.Tests.Properties.Settings.TestDBConnectionString";

        internal class DataFile
        {
            public const string SYSTEM_DATA = "Henkel.Business.Kernel.Tests.Support.Data.SystemData.xml";
            public const string BASE_DATA = "Henkel.Business.Kernel.Tests.Support.Data.BaseData.xml";
            public const string USER = "Henkel.Business.Kernel.Tests.Support.Data.Users.xml";
            public const string PASSWORD_HISTORY = "Henkel.Business.Kernel.Tests.Support.Data.PasswordHistory.xml";
            public const string EMAIL_TEMPLATE = "Henkel.Business.Kernel.Tests.Support.Data.EmailTemplate.xml";
        }

        internal class Schema
        {
            internal const string COMMON = "Henkel.Business.Kernel.Tests.Support.Schema.Common.xsd";
        }
    }
}
