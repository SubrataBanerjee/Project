﻿
namespace Henkel.Business.Kernel.Security.Notification.Resource
{
    public static class EmailTokenRegisterKey
    {
        public const string UserEmailTokenProvider = "UserEmailTokenProvider";
    }
}
