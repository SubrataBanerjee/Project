﻿
namespace Henkel.Business.Kernel.Security.Notification.Resources
{
    public static class SecurityNotificationKey
    {
        public const string NewUser = "NewUser";
        public const string ResetPassword = "ResetPassword";
        public const string ChangePassword = "ChangePassword";
    }
}
