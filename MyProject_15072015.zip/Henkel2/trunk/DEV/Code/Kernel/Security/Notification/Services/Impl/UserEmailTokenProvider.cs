﻿using Henkel.Business.Kernel.Infrastructure.API.DTO;
using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Security.Notification.Services.Impl
{
    public class UserEmailTokenProvider : IEmailTokenProvider
    {
        #region Fields

        private IUserRepository _userRepository;

        #endregion

        #region Constructors

        public UserEmailTokenProvider(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        #endregion

        #region Implementation of IEmailTokenProvider

        public void AddTokens(IList<Token> tokens, Guid entityId)
        {
            var user = _userRepository.GetById(entityId);
            if (user == null)
                return;
            
            AddTokens(tokens, user);
        }

        public void AddTokens(IList<Token> tokens, IEntity entity)
        {
            var user = entity as User;
            if (user == null)
                return;

            AddTokens(tokens, user);
        }

        #endregion

        #region Helper Methods

        private static void AddTokens(IList<Token> tokens, User user)
        {
            tokens.Add(new Token("User.Username", user.LoginId));
            tokens.Add(new Token("User.Name", user.LoginId));
            tokens.Add(new Token("User.Password", user.UnHashedNewPassword));

            //TODO add all User token property
        }
        #endregion
    }
}
