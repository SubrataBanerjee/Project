﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class UserAuthenticationService : TransactionSupportBaseService, IUserAuthenticationService
    {
        #region Fields

        private readonly IUserRepository _userRepository;
        private readonly IResourceRepository _resourceRepository;

        #endregion

        #region Constructors

        public UserAuthenticationService(IUserRepository userRepository, IResourceRepository resourceRepository)
        {
            _userRepository = userRepository;
            _resourceRepository = resourceRepository;
        }

        #endregion

        #region Implementation of IUserAuthenticationService

        public UserToken SignIn(string loginId, string password, bool rememberMe = false)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    var resource = _resourceRepository.Find(x => x.User != null && x.User.LoginId == loginId).FirstOrDefault();
                    if (resource == null)
                        throw new ValidationException(SecurityErrorMessage.InvalIdLoginIdSpecified);

                    resource.ValidateAuthentication(password);
                    return resource.GetToken();
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                return new UserToken()
                {
                    SuccessLogin = false,
                    ErrorMessage = ex.Message,
                    ErrorArguments = ex.Args
                };
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                return new UserToken()
                {
                    SuccessLogin = false,
                    ErrorMessage = CoreErrorMessage.KeyErrorProcessingRequest,
                };
            }
        }

        public void SignOut()
        {
            try
            {
                //Nothing to Do for Now
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void ResetPassword(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.ResetPassword();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }


        public void ChangePassword(Guid userId, string oldPassword, string newPassword, string confirmPassword)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.ChangePassword(oldPassword, newPassword, confirmPassword);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }       
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }


        public void ForgotPassword(string emailId)
        {
            try
            {
                using(var session = RepositorySession)
                {
                    try
                    {
                        var resourceRepository = ObjectLocator.GetObject<IResourceRepository>();
                        var resource = resourceRepository.Find(x => x.Contact != null && x.Contact.Email == emailId && x.User != null).FirstOrDefault();
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.SpecifiedEmailIdIsNotPresent);

                        resource.User.ForgotPassword();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }



        public void LockUser(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.Lock();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        
        public void UnlockUser(Guid userId)
        {
            try
            {
                using(var session  = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.Unlock();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion
    }
}
