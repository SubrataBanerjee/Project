﻿using Henkel.Business.Kernel.API.Customer.Helpers;
using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.Exceptions;
using System;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class PasswordHistoryValidationService : IPasswordHistoryValidationService
    {
        #region Constructors

        public PasswordHistoryValidationService()
        {
        }

        #endregion

        #region Implementation of IPasswordHistoryValidationService

        public void Validate(User user, string password)
        {
            var passwordHistoryLimitStr = CustomerHelper.GetConfigValue(false, SecurityAdminConfigKey.PasswordHistoryLimit);

            if (string.IsNullOrWhiteSpace(passwordHistoryLimitStr))
                return;

            Int16 passwordHistoryLimit;
            if (!Int16.TryParse(passwordHistoryLimitStr, out passwordHistoryLimit))
            {
                Logger.Warning(GetType().Name, "Invalid entry configured in Customer Configuration for Key: {0}. Exiting without validation of last N numbers of used passwords match.", SecurityAdminConfigKey.PasswordHistoryLimit);
                return;
            }


            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();

            var hashedPwd = hasGeneratorService.GetHashedDataString(password);
            var paswwordHistories = user.PasswordHistories.OrderByDescending(x => x.CreatedOn).Take(passwordHistoryLimit);
            if (paswwordHistories.Any(x => x.Password == hashedPwd))
                throw new ValidationException(SecurityErrorMessage.NewPasswordShouldNotBeSameAsLastUsedPassword, passwordHistoryLimit);
        }

        #endregion
    }
}
