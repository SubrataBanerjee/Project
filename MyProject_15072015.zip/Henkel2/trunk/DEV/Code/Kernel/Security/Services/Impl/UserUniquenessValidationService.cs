﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Expressions;
using System;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class UserUniquenessValidationService : IUserUniquenessValidationService
    {
        #region Fields

        private readonly IUserRepository _userRepository;

        #endregion

        #region Constructors

        public UserUniquenessValidationService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        #endregion

        #region Implementation of IUserUniquenessValidationService

        public void ValidateUserLoginId(string loginId, Guid[] ignoreUserIds = null)
        {
            var expression = PredicateBuilder.True<User>();
            expression = expression.AndAlso(x => x.LoginId == loginId);
            if(ignoreUserIds != null)
                expression = expression.AndAlso(x => !ignoreUserIds.Contains(x.Id));

            var count = _userRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.LoginIdAlreadyExist);
        }

        #endregion
    }
}
