﻿using System;

namespace Henkel.Business.Kernel.Security.Services
{
    public interface IRoleUniquenessValidationService
    {
        /// <summary>
        /// Validate Unique RoleName in the system
        /// </summary>
        /// <param name="roleName">roleName to Validate</param>
        /// <param name="ignoreRoleIds">RoleIds to Ignore</param>
        void ValidateRoleName(string roleName, Guid[] ignoreRoleIds = null);
    }
}
