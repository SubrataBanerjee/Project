﻿using System;
using System.Security.Cryptography;
using System.Text;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    /// <summary>
    /// Hashed data Generation service using SHA hashing algorithm.
    /// </summary>
    public class SHAHashGeneratorService : IHashGeneratorService
    {
        /// <summary>
        /// Gets the hashed data.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public byte[] GetHashedData(String data)
        {
            byte[] dataBytes = Encoding.UTF8.GetBytes(data);

            SHA256 hasher = new SHA256Managed();
            byte[] hashedData = hasher.ComputeHash(dataBytes);
            return hashedData;
        }

        /// <summary>
        /// Gets the hashed data string.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        public string GetHashedDataString(string data)
        {
            return Convert.ToBase64String(GetHashedData(data));
        }
    }
}
