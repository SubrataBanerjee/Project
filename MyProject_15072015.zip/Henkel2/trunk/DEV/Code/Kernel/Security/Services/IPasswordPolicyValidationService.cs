﻿
namespace Henkel.Business.Kernel.Security.Services
{
    public interface IPasswordPolicyValidationService
    {
        /// <summary>
        /// Methods to validate password with configured password format policy. If password format is not configured in DB then it will validate on default format. 
        /// Default format for password is:
        /// --"Should be 8-15 characters in length
        /// --Should have atleast one lowercase character
        /// --Should have atleast one uppercase character
        /// --Should have atleast one number
        /// --Should have atleast one special character
        /// --Should not have spaces."
        /// </summary>
        /// <param name="password">Password to validate</param>
        void Validate(string password);
    }
}
