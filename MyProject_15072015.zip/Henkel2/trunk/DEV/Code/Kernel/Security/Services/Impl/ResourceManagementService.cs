﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.DTO.SearchCriteria;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Repository.Specification;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class ResourceManagementService : TransactionSupportBaseService, IResourceManagementService
    {
        #region Fields

        private readonly IResourceRepository _resourceRepository;
        private readonly IAssembler<Resource, ResourceDto> _resourceAssembler;
        
        #endregion

        #region Constructors

        public ResourceManagementService(IResourceRepository resourceRepository)
        {
            _resourceRepository = resourceRepository;
            _resourceAssembler = ObjectLocator.GetObject<IAssembler<Resource, ResourceDto>>();
        }

        #endregion

        #region Implementation of IResourceManagementService

        #region Queries

        public ResourceDto GetResourceById(Guid resourceId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var user = _resourceRepository.GetById(resourceId);
                    if (user == null)
                        return null;
                    return _resourceAssembler.GetDtoFromEntity(user);
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public Page<ResourceDto> FindResourceByCriteria(ResourceSearchCriteria resourceSearchCriteria, PageInfo pageInfo)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var searchExp = resourceSearchCriteria.GetSearchExpression();
                    var count = _resourceRepository.GetCount(searchExp);
                    if (count > 0)
                    {
                        var pageExp = pageInfo.GetResourceSortExpression();
                        var result = _resourceRepository.Find(searchExp, pageExp, pageInfo.StartRow, pageInfo.PageSize).ToList();
                        return new Page<ResourceDto>(count, result.Select(x => _resourceAssembler.GetDtoFromEntity(x)).ToList());
                    }
                    return new Page<ResourceDto>(count, new List<ResourceDto>());
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<ResourceDto> FindResourceByCriteria(ResourceSearchCriteria resourceSearchCriteria)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var expression = resourceSearchCriteria.GetSearchExpression();
                    var result = _resourceRepository.Find(expression).ToList();
                    return result.Select(_resourceAssembler.GetDtoFromEntity).ToList();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public Page<ResourceDto> GetAllResources(PageInfo pageInfo)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var totalRecordCount = _resourceRepository.GetCount();
                    if (totalRecordCount > 0)
                    {
                        var sortExpression = pageInfo.GetResourceSortExpression();
                        var result = _resourceRepository.Find(null, sortExpression, pageInfo.StartRow, pageInfo.PageSize, pageInfo.SortDirection ? "asc" : "desc").ToList();
                        return new Page<ResourceDto>(totalRecordCount, result.Select(_resourceAssembler.GetDtoFromEntity).ToList());
                    }
                    return new Page<ResourceDto>(0, new List<ResourceDto>());
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<ResourceDto> GetAllResources()
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var result = _resourceRepository.Find().ToList();
                    return result.Select(_resourceAssembler.GetDtoFromEntity).ToList();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #region Commands

        public Guid AddResource(ResourceDto resourceDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var entity = _resourceAssembler.GetEntityFromDto(resourceDto);
                        entity.Add();

                        return entity.Id;
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void UpdateResource(ResourceDto resourceDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceDto.ResourceId);
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidResourceIdForUpdate);

                        _resourceAssembler.UpdateEntityFromDto(resource, resourceDto);

                        resource.Update();

                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void UpdateResourceEmailId(Guid resourceId, string email)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceId);
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidResourceIdForUpdate);

                        resource.UpdateEmail(email);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void DeleteResource(Guid resourceId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceId);
                        resource.Delete();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void MarkResourceAsEnabled(Guid resourceId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceId);
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidResourceIdForUpdate);

                        resource.MarkAsEnable();
                    }
                    catch(Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void MarkResourceAsDisabled(Guid resourceId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceId);
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidResourceIdForUpdate);

                        resource.MarkAsDisable();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void CreateLogin(Guid resourceId, string loginId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceId);
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidResourceIdForUpdate);

                        resource.CreateLogin(loginId);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void DeleteLogin(Guid resourceId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var resource = _resourceRepository.GetById(resourceId);
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidResourceIdForUpdate);

                        resource.DeleteLogin();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #endregion

        #region Helper Methods


        #endregion
    }
}
