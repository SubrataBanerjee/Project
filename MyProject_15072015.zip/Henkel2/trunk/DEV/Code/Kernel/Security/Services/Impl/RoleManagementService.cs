﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.DTO.SearchCriteria;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Repository.Specification;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class RoleManagementService : TransactionSupportBaseService, IRoleManagementService
    {
        #region Fields

        private readonly IUserRepository _userRepository;
        private readonly IReadWriteRepository<Role> _roleRepository;
        private readonly IQueryableRepository<Feature> _featureRepository;
        private readonly IAssembler<Role, RoleDto> _roleAssembler;
        private readonly IAssembler<Role, SudoRoleDto> _sudoRoleAssembler;

        #endregion


        #region Constructors

        public RoleManagementService(IUserRepository userRepository, IReadWriteRepository<Role> roleRepository, IQueryableRepository<Feature> featureRepository)
        {
            _userRepository = userRepository;
            _roleRepository = roleRepository;
            _featureRepository = featureRepository;
            _roleAssembler = ObjectLocator.GetObject<IAssembler<Role, RoleDto>>();
            _sudoRoleAssembler = ObjectLocator.GetObject<IAssembler<Role, SudoRoleDto>>();
        }

        #endregion


        #region Implementation of IRoleManagementService
        
        #region Queries

        public RoleDto GetRoleById(Guid roleId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var role = _roleRepository.GetById(roleId);
                    if (role == null)
                        return null;
                    
                    var roleDto = _roleAssembler.GetDtoFromEntity(role);
                    roleDto.RoleFeatureMapDtos = role.GetRoleFeatureMapDtos();

                    return roleDto;
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public SudoRoleDto GetSudoRoleById(Guid userId, Guid roleId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var user = _userRepository.GetById(userId);
                    if (user == null)
                        throw new ValidationException(SecurityErrorMessage.InvalidUserIdToGetSudoRole);

                    var roleUserMap = user.RoleUserMaps.FirstOrDefault(x => x.Role.Id == roleId);
                    if (roleUserMap == null)
                        throw new ValidationException(SecurityErrorMessage.InvalidUserIdOrRoleIdToGetSudoRole);

                    var sudoRoleDto = _sudoRoleAssembler.GetDtoFromEntity(roleUserMap.Role);
                    sudoRoleDto.UserId = userId;
                    sudoRoleDto.RoleFeatureUserMapDtos = roleUserMap.Role.GetRoleFeatureUserMapDtos();

                    return sudoRoleDto;
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public Page<RoleDto> FindRoleByCriteria(RoleSearchCriteria roleSearchCriteria, PageInfo pageInfo)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var searchExp = roleSearchCriteria.GetSearchExpression();
                    var count = _roleRepository.GetCount(searchExp);
                    if (count > 0)
                    {
                        var pageExp = pageInfo.GetRoleSortExpression();
                        var result = _roleRepository.Find(searchExp, pageExp, pageInfo.StartRow, pageInfo.PageSize).ToList();
                        return new Page<RoleDto>(count, result.Select(x => _roleAssembler.GetDtoFromEntity(x)).ToList());
                    }
                    return new Page<RoleDto>(count, new List<RoleDto>());
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<RoleDto> FindRoleByCriteria(RoleSearchCriteria roleSearchCriteria)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var expression = roleSearchCriteria.GetSearchExpression();
                    var result = _roleRepository.Find(expression).ToList();
                    return result.Select(_roleAssembler.GetDtoFromEntity).ToList();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #region Commands

        public void AddRole(RoleDto roleDto)
        {
            try
            {
                using(var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleAssembler.GetEntityFromDto(roleDto);
                        role.Add();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void UpdateRole(RoleDto roleDto, bool resetSudoRole = false)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleDto.Id);
                        _roleAssembler.UpdateEntityFromDto(role, roleDto);

                        if (resetSudoRole)
                            role.ResetSudoRoles();

                        role.Update();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void UpdateSudoRole(SudoRoleDto sudoRole)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(sudoRole.RoleId);
                        _sudoRoleAssembler.UpdateEntityFromDto(role, sudoRole);

                        role.Update();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void EnableRole(Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleId);
                        role.MarkAsEnable();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void DisableRole(Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleId);
                        role.MarkAsDisable();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void DeleteRole(Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleId);
                        role.Delete();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void AttachRoleToUser(Guid userId, Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        var role = _roleRepository.GetById(roleId);

                        role.AttachUser(user);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void DettachRoleFromUser(Guid userId, Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if(user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForDetachedRoleFromUser);
                        var roleUserMap = user.RoleUserMaps.FirstOrDefault(x => x.User.Id == user.Id && x.Role.Id == roleId);
                        if (roleUserMap == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidRoleIdForDetachedRoleFromUser);

                        roleUserMap.Role.DettachUser(user);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #endregion


        #region Helper Methods

        #endregion

    }
}
