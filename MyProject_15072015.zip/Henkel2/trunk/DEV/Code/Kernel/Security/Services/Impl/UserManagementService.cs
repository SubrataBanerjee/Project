﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.DTO.SearchCriteria;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Repository.Specification;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class UserManagementService : TransactionSupportBaseService, IUserManagementService
    {
        #region Fields

        private readonly IUserRepository _userRepository;
        private readonly IAssembler<User, UserDto> _userAssembler;
        #endregion

        #region Constructors

        public UserManagementService(IUserRepository userRepository, IAssembler<User, UserDto> userAssembler)
        {
            _userRepository = userRepository;
            _userAssembler = userAssembler;
        }

        #endregion

        #region Implementation of IUserManagementService

        #region Queries

        public UserDto GetUserById(Guid userId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var user = _userRepository.GetById(userId);
                    if (user == null)
                        return null;
                    return _userAssembler.GetDtoFromEntity(user);
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public UserDto GetUserByLoginId(string loginId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var user = _userRepository.Find(x => x.LoginId == loginId).FirstOrDefault();
                    if (user == null)
                        return null;
                    return _userAssembler.GetDtoFromEntity(user);
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public Page<UserDto> FindUserByCriteria(UserSearchCriteria userSearchCriteria, PageInfo pageInfo)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var searchExp = userSearchCriteria.GetSearchExpression();
                    var count = _userRepository.GetCount(searchExp);
                    if (count > 0)
                    {
                        var pageExp = pageInfo.GetUserSortExpression();
                        var result = _userRepository.Find(searchExp, pageExp, pageInfo.StartRow, pageInfo.PageSize).ToList();
                        return new Page<UserDto>(count, result.Select(x => _userAssembler.GetDtoFromEntity(x)).ToList());
                    }
                    return new Page<UserDto>(count, new List<UserDto>());
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<UserDto> FindUserByCriteria(UserSearchCriteria searchCriteria)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var expression = searchCriteria.GetSearchExpression();
                    var result = _userRepository.Find(expression).ToList();
                    return result.Select(_userAssembler.GetDtoFromEntity).ToList();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public Page<UserDto> GetAllUsers(PageInfo pageInfo)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var totalRecordCount = _userRepository.GetCount();
                    if(totalRecordCount > 0)
                    {
                        var sortExpression = pageInfo.GetUserSortExpression();
                        var result = _userRepository.Find(null, sortExpression, pageInfo.StartRow, pageInfo.PageSize, pageInfo.SortDirection ? "asc" : "desc").ToList();
                        return new Page<UserDto>(totalRecordCount, result.Select(_userAssembler.GetDtoFromEntity).ToList());
                    }
                    return new Page<UserDto>(0, new List<UserDto>());
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<UserDto> GetAllUsers()
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var result = _userRepository.Find().ToList();
                    return result.Select(_userAssembler.GetDtoFromEntity).ToList();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #region Commands

        public Guid AddUser(UserDto userDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var entity = _userAssembler.GetEntityFromDto(userDto);
                        entity.Add();
                        
                        return entity.Id;
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void UpdateUser(UserDto userDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var entity = _userRepository.GetById(userDto.UserId);
                        if (entity == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        _userAssembler.UpdateEntityFromDto(entity, userDto);

                        entity.Update();
                        
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void DeleteUser(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        user.Delete();
                    }
                    catch(Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void MarkUserAsEnabled(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.MarkAsEnable();
                    }
                    catch(Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public void MarkUserAsDisabled(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.MarkAsDisable();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #endregion
    }
}
