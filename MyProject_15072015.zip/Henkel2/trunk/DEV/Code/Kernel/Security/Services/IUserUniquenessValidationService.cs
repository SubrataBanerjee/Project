﻿using System;

namespace Henkel.Business.Kernel.Security.Services
{
    public interface IUserUniquenessValidationService
    {
        /// <summary>
        /// Validate Unique User LoginId in the system
        /// </summary>
        /// <param name="loginId">userName to Validate</param>
        /// <param name="ignoreUserIds">UserIds to Ignore</param>
        void ValidateUserLoginId(string loginId, Guid[] ignoreUserIds = null);
    }
}
