﻿using Henkel.Business.Kernel.API.Customer.Helpers;
using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Exceptions;
using System;
using System.Text.RegularExpressions;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class PasswordPolicyValidationService : IPasswordPolicyValidationService
    {
        #region Implementation of IPasswordPolicyValidationService

        public void Validate(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                throw new ValidationException(SecurityErrorMessage.PasswordCanNotBeEmpty);

            // Validating password format as per policy
            var passwordPolicy = GetPasswordPolicy();
            Regex reg = new Regex(passwordPolicy.Regex);
            if (!reg.IsMatch(password))
                throw new ValidationException(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, passwordPolicy.Description);
        }

        #endregion
        
        #region Helper Methods

        private static PasswordPolicy GetPasswordPolicy()
        {
            var passwordPolicyStr = CustomerHelper.GetConfigValue(false,SecurityAdminConfigKey.PasswordPolicy);

            if (string.IsNullOrWhiteSpace(passwordPolicyStr))
                return DefaultPasswordPolicy();

            return CreatePasswordPolicy(passwordPolicyStr);
        }

        private static PasswordPolicy DefaultPasswordPolicy()
        {
            return new PasswordPolicy
            {
                Regex = @"^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*\W)\S{8,15}$",
                Description = "Should be 8-15 characters in length\n\rShould have atleast one lowercase character\n\rShould have atleast one uppercase character\n\rShould have atleast one number\n\rShould have atleast one special character\n\rShould not have spaces."
            };
        }

        private static PasswordPolicy CreatePasswordPolicy(string passwordPolicyStr)
        {
            var passwordPolicy = new PasswordPolicy();

            var arr = passwordPolicyStr.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
            passwordPolicy.Regex = arr[0];
            if (arr.Length > 1)
                passwordPolicy.Description = arr[1];

            return passwordPolicy;
        }


        #endregion
    }
}
