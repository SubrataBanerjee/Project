﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Expressions;
using System;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class ResourceUniquenessValidationService : IResourceUniquenessValidationService
    {
        #region Fields

        private readonly IResourceRepository _resourceRepository;

        #endregion

        #region Constructors

        public ResourceUniquenessValidationService(IResourceRepository resourceRepository)
        {
            _resourceRepository = resourceRepository;
        }

        #endregion

        #region Implementation of IResourceUniquenessValidationService

        public void ValidateCode(string code, Guid[] ignoreResourceIds = null)
        {
            var expression = PredicateBuilder.True<Resource>();
            expression = expression.AndAlso(x => x.Code == code);
            if (ignoreResourceIds != null)
                expression = expression.AndAlso(x => !ignoreResourceIds.Contains(x.Id));

            var count = _resourceRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.ResourceCodeAlreadyExist);
        }

        public void ValidateEmail(string email, Guid[] ignoreResourceIds = null)
        {
            var expression = PredicateBuilder.True<Resource>();
            expression = expression.AndAlso(x => x.Contact != null && x.Contact.Email == email);
            if (ignoreResourceIds != null)
                expression = expression.AndAlso(x => !ignoreResourceIds.Contains(x.Id));

            var count = _resourceRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.ResourceEmailIdAlreadyExist);
        }

        #endregion

        
    }
}
