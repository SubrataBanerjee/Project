﻿using System;

namespace Henkel.Business.Kernel.Security.Services
{
    /// <summary>
    /// Interface specifying methods that need implementation for Hashed string/bytes Generation
    /// </summary>
    public interface IHashGeneratorService
    {
        /// <summary>
        /// Gets the hashed data.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        byte[] GetHashedData(String data);

        /// <summary>
        /// Gets the hashed data string.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        string GetHashedDataString(String data);
    }
}
