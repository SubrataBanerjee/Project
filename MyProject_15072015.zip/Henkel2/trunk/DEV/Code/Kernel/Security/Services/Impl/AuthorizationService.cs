﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;

namespace Henkel.Business.Kernel.Security.Services.Impl
{
    public class AuthorizationService : TransactionSupportBaseService, IAuthorizationService
    {
        #region Fields

        private readonly IUserRepository _userRepository;
        private readonly IQueryableRepository<Feature> _featureRepository;

        #endregion

        #region Constructor

        public AuthorizationService(IUserRepository userRepository, IQueryableRepository<Feature> featureRepository)
        {
            _userRepository = userRepository;
            _featureRepository = featureRepository;
        }

        #endregion

        #region Implementation of IAuthorizationService

        public UserRights GetRights(Guid userId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var user = _userRepository.GetById(userId);
                    if (user == null)
                        throw new ValidationException(SecurityErrorMessage.InvalidUserIdToGetSudoRole);

                    return user.GetUserRights();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public bool HasRight(UserRights currentRights, string feature, string group, string module, params UserAction[] actions)
        {
            try
            {
                if (currentRights.IsSuperAdmin)
                   return true;

                if (string.IsNullOrWhiteSpace(feature))
                    return false;

                if (actions == null || actions.Length == 0)
                    return false;

                var allSystemFeatures = GetSystemFeatures();
                bool hasAccess = false;
                var filteredFeatures = allSystemFeatures.Where(a => a.FeatureName.ToUpper() == feature.ToUpper()).ToList();
                if (!string.IsNullOrWhiteSpace(group))
                    filteredFeatures = filteredFeatures.Where(x => x.FeatureGroup != null && x.FeatureGroup.ToUpper() == group.ToUpper()).ToList();

                if (!string.IsNullOrWhiteSpace(module))
                    filteredFeatures = filteredFeatures.Where(x => x.Module != null && x.Module.ToUpper() == module.ToUpper()).ToList();

                var selectedFeature = filteredFeatures.FirstOrDefault();
                if (selectedFeature != null)
                    hasAccess = currentRights.HasAccess(selectedFeature.Id, actions);
                    
                return hasAccess;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<FeatureDto> GetSystemFeatures()
        {
            try
            {
                var cacheTimeOut = CoreHelper.GetCacheTimeOut();

                var cachingService = ObjectLocator.GetService<ICachingService>();
                var allFeatures = cachingService.Get<IList<FeatureDto>>(GlobalConstant.SYS_FEATURE_CACHE_KEY, () =>
                {
                    using (RepositoryReadOnlySession)
                    {
                        return GetAllSystemFeatures();
                    }

                }, new CachingOptions()
                {
                    CacheType = CoreHelper.GetCacheType(),
                    CachePolicy = new CacheItemPolicy
                    {
                        AbsoluteExpiration = DateTime.Now.AddDays(cacheTimeOut)
                    }
                });

                return allFeatures;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #region Helpers

        private IList<FeatureDto> GetAllSystemFeatures()
        {
            var features = _featureRepository.Find().ToList();
            return features.Select(x => x.GetDto()).ToList();
        }

        #endregion
    }
}
