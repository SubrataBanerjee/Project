﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class ResourceConfiguration : EntityTypeConfiguration<Resource>, IEntityConfiguration
    {
        public ResourceConfiguration()
        {
            var s = Map(m =>
                {
                    m.ToTable("Sec_Resource");
                    m.Requires("IsDeleted").HasValue(false);
                });
            
            s.HasKey(x => x.Id);

            s.Property(x => x.Code);
            s.Property(x => x.IsActive);
            s.Property(x => x.CreatedBy);
            s.Property(x => x.CreatedOn);
            s.Property(x => x.LastModifiedOn);
            s.Property(x => x.LastModifiedBy);

            s.Ignore(e => e.IsDeleted);

            s.HasOptional(x => x.User).WithMany().HasForeignKey(y => y.UserId);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
