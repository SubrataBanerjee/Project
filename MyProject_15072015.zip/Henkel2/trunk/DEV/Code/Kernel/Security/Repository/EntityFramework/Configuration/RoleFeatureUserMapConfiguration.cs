﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class RoleFeatureUserMapConfiguration : EntityTypeConfiguration<RoleFeatureUserMap>, IEntityConfiguration
    {
        public RoleFeatureUserMapConfiguration()
        {
            ToTable("Sec_RoleFeatureUserMap");
            HasKey(x => x.Id);

            Property(x => x.Add);
            Property(x => x.Edit);
            Property(x => x.View);
            Property(x => x.Delete);
            Property(x => x.Print);
            Property(x => x.Execute);
            Property(x => x.Activate);

            HasRequired(x => x.Role).WithMany().HasForeignKey(y => y.RoleId);
            HasRequired(x => x.User).WithMany().HasForeignKey(y => y.UserId);
            HasRequired(x => x.Feature).WithMany().HasForeignKey(y => y.FeatureId);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
