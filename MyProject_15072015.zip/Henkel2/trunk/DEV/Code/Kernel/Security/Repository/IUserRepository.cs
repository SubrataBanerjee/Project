﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository;

namespace Henkel.Business.Kernel.Security.Repository
{
    public interface IUserRepository : IReadWriteRepository<User>
    {
    }
}
