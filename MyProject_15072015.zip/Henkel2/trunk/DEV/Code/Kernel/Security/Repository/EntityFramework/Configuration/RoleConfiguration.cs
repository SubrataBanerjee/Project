﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class RoleConfiguration : EntityTypeConfiguration<Role>, IEntityConfiguration
    {
        public RoleConfiguration()
        {
            var s = Map(m =>
            {
                m.ToTable("Sec_Role");
                m.Requires("IsDeleted").HasValue(false);
            });

            s.HasKey(x => x.Id);

            s.Property(x => x.Name).IsRequired();
            s.Property(x => x.IsActive).IsRequired();
            s.Property(x => x.CreatedBy).HasMaxLength(50).IsUnicode(true);
            s.Property(x => x.CreatedOn);
            s.Property(x => x.LastModifiedBy).HasMaxLength(50).IsUnicode(true);
            s.Property(x => x.LastModifiedOn);
            
            s.Ignore(e => e.IsDeleted);

            s.HasMany(x => x.RoleUserMaps)
                .WithRequired()
                .HasForeignKey(y => y.RoleId);

            s.HasMany(x => x.RoleFeatureMaps)
                .WithRequired()
                .HasForeignKey(y => y.RoleId);

            s.HasMany(x => x.RoleFeatureUserMaps)
                .WithRequired()
                .HasForeignKey(y => y.RoleId);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
