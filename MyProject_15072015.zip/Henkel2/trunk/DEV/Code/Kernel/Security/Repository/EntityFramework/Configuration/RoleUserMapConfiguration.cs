﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class RoleUserMapConfiguration : EntityTypeConfiguration<RoleUserMap>, IEntityConfiguration
    {
        public RoleUserMapConfiguration()
        {
            ToTable("Sec_RoleUserMap");
            HasKey(x => x.Id);

            HasRequired(x => x.Role).WithMany().HasForeignKey(y => y.RoleId);
            HasRequired(x => x.User).WithMany().HasForeignKey(y => y.UserId);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
