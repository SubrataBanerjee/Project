﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Impl;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Impl
{
    public class UserRepository : EFReadWriteRepository<User>, IUserRepository
    {
    }
}
