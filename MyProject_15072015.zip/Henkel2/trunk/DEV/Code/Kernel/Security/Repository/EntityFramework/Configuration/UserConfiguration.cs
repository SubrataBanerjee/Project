﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class UserConfiguration : EntityTypeConfiguration<User>, IEntityConfiguration
    {
        public UserConfiguration()
        {
            var s = Map(m =>
                {
                    m.ToTable("Sec_User");
                    m.Requires("IsDeleted").HasValue(false);
                });

            s.HasKey(x => x.Id);

            s.Property(x => x.LoginId).IsRequired();
            s.Property(x => x.Password);
            s.Property(x => x.IsActive).IsRequired();
            s.Property(x => x.Locked);
            s.Property(x => x.ChangePwdOnLogin);
            s.Property(x => x.FailureLoginAttempt);
            s.Property(x => x.IsSuperAdmin);
            s.Property(x => x.CreatedBy).HasMaxLength(50).IsUnicode(true);
            s.Property(x => x.CreatedOn);
            s.Property(x => x.LastModifiedBy).HasMaxLength(50).IsUnicode(true);
            s.Property(x => x.LastModifiedOn);

            s.Ignore(e => e.UnHashedNewPassword);
            s.Ignore(e => e.IsDeleted);

            s.HasMany(x => x.PasswordHistories)
                .WithRequired()
                .HasForeignKey(y => y.UserId);

            s.HasMany(x => x.RoleUserMaps)
                .WithRequired()
                .HasForeignKey(y => y.UserId);

            s.HasMany(x => x.RoleFeatureUserMaps)
                .WithRequired()
                .HasForeignKey(y => y.UserId);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
