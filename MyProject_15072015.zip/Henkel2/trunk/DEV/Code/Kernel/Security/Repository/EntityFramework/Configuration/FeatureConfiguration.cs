﻿using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class FeatureConfiguration : EntityTypeConfiguration<Feature>, IEntityConfiguration
    {
        public FeatureConfiguration()
        {
            ToTable("Sys_Feature");
            HasKey(x => x.Id);

            Property(x => x.FeatureGroup);
            Property(x => x.Name).IsRequired();
            Property(x => x.Module);
            Property(x => x.Add);
            Property(x => x.Edit);
            Property(x => x.View);
            Property(x => x.Delete);
            Property(x => x.Print);
            Property(x => x.Execute);
            Property(x => x.Activate);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
