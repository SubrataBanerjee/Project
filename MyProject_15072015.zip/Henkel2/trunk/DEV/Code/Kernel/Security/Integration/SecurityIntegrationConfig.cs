﻿using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.API.Services;
using Henkel.Business.Kernel.Security.Assembler;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Notification.Resource;
using Henkel.Business.Kernel.Security.Notification.Services.Impl;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Repository.EntityFramework.Impl;
using Henkel.Business.Kernel.Security.Services;
using Henkel.Business.Kernel.Security.Services.Impl;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Integration.Services.Impl;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Repository.EntityFramework.Impl;
using Microsoft.Practices.Unity;

namespace Henkel.Business.Kernel.Security.Integration
{
    public class SecurityIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterRepository(container);
            RegisterAssemblers(container);
            RegisterServices(container);
            RegisterEmailTokens(container);
        }

        private void RegisterRepository(IUnityContainer container)
        {
            container.RegisterType<IUserRepository, UserRepository>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceRepository, ResourceRepository>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<Role>, EFReadWriteRepository<Role>>(new ContainerControlledLifetimeManager());
            container.RegisterType<IQueryableRepository<Feature>, EFQueryableRepository<Feature>>(new ContainerControlledLifetimeManager());
        }

        private void RegisterAssemblers(IUnityContainer container)
        {
            container.RegisterType<IAssembler<User, UserDto>, UserAssembler>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAssembler<Resource, ResourceDto>, ResourceAssembler>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAssembler<Role, RoleDto>, RoleAssembler>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAssembler<Role, SudoRoleDto>, SudoRoleAssembler>(new ContainerControlledLifetimeManager());
        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<IHashGeneratorService, SHAHashGeneratorService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUserManagementService, UserManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUserUniquenessValidationService, UserUniquenessValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceManagementService, ResourceManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceUniquenessValidationService, ResourceUniquenessValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUserAuthenticationService, UserAuthenticationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IPasswordPolicyValidationService, PasswordPolicyValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IPasswordHistoryValidationService, PasswordHistoryValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IPasswordValidationService, PasswordValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceManagementService, ResourceManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IRoleManagementService, RoleManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IRoleUniquenessValidationService, RoleUniquenessValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAuthorizationService, AuthorizationService>(new ContainerControlledLifetimeManager());
        }

        private void RegisterEmailTokens(IUnityContainer container)
        {
            container.RegisterType<IEmailTokenProvider, UserEmailTokenProvider>(EmailTokenRegisterKey.UserEmailTokenProvider, new ContainerControlledLifetimeManager());
        }
    }
}
