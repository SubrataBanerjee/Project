﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Assembler;
using System;

namespace Henkel.Business.Kernel.Security.Assembler
{
    public class ResourceAssembler : IAssembler<Resource, ResourceDto>
    {
        #region Implementation of IAssembler

        public Resource GetEntityFromDto(ResourceDto dto)
        {
            var entity = new Resource();
            entity.Id = dto.ResourceId;
            entity.IsActive = true;
            entity.Code = dto.Code;
            //Note: IAuditEntry related fields will be updated at base level in Repository

            UpdateEntityFromDto(entity, dto);
            return entity;
        }

        public ResourceDto GetDtoFromEntity(Resource entity)
        {
            return new ResourceDto
            {
                ResourceId = entity.Id,
                Code = entity.Code,
                UserId = entity.User == null ? null : (Guid?)entity.User.Id,
                LoginId = entity.User == null ? null : entity.User.LoginId,
                IsActive = entity.IsActive,
                IsDeleted = entity.IsDeleted,
                Contact = entity.Contact,
                Address = entity.Address,
                CreatedBy = entity.CreatedBy,
                CreatedOn = entity.CreatedOn,
                LastModifiedBy = entity.LastModifiedBy,
                LastModifiedOn = entity.LastModifiedOn,
            };
        }

        public void UpdateEntityFromDto(Resource entity, ResourceDto dto)
        {
            //Note: Id, CustomerId, Code, IsDeleted, IsActive, are not be updated from here
            //Note: IAuditEntry related fields will be updated at base level in Repository
            
            entity.Contact = dto.Contact;
            entity.Address = dto.Address;
            //Note: User must be attached through service
        }

        #endregion
    }
}
