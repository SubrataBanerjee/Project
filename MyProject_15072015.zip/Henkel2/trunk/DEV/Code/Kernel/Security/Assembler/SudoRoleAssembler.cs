﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Assembler
{
    public class SudoRoleAssembler : IAssembler<Role, SudoRoleDto>
    {
        #region Fields

        private readonly IReadWriteRepository<Role> _roleRepository;
        private readonly IQueryableRepository<Feature> _featureRepository;
        private readonly IUserContextService _userContextService;

        #endregion

        #region Constructors

        public SudoRoleAssembler(IReadWriteRepository<Role> roleRepository, IQueryableRepository<Feature> featureRepository)
        {
            _roleRepository = roleRepository;
            _featureRepository = featureRepository;
            _userContextService = ObjectLocator.GetService<IUserContextService>();
        }

        #endregion

        #region Implementation of IAssembler<Role, SudoRoleDto>

        public Role GetEntityFromDto(SudoRoleDto sudoRoleDto)
        {
            throw new NotImplementedException();
        }

        public SudoRoleDto GetDtoFromEntity(Role role)
        {
            return new SudoRoleDto
            {
                RoleId = role.Id,
                IsActive = role.IsActive,
                RoleName = role.Name,
            };
        }

        public void UpdateEntityFromDto(Role role, SudoRoleDto sudoRoleDto)
        {
            var userRepository = ObjectLocator.GetObject<IUserRepository>();
            var user = userRepository.GetById(sudoRoleDto.UserId);

            if (sudoRoleDto.RoleFeatureUserMapDtos == null || !sudoRoleDto.RoleFeatureUserMapDtos.Any())
            {
                //Clear All existing matching records for this Role and User
                role.RemoveRoleFeatureUserMaps(user);
            }
            else
            {
                var featureIds = sudoRoleDto.RoleFeatureUserMapDtos.Select(x => x.FeatureId).Distinct().ToArray();
                var features = _featureRepository.Find(x => featureIds.Contains(x.Id)).ToDictionary(y => y.Id);
                var newRoleFeatureUserMaps = new List<RoleFeatureUserMap>();
                foreach (var roleFeatureUserMapDto in sudoRoleDto.RoleFeatureUserMapDtos)
                {
                    var feature = features[roleFeatureUserMapDto.FeatureId];
                    var roleFeatureUserMap = RoleFeatureUserMap.CreateNewInstance(user, role, feature, roleFeatureUserMapDto);
                    newRoleFeatureUserMaps.Add(roleFeatureUserMap);
                }
                role.SaveRoleFeatureUserMaps(user, newRoleFeatureUserMaps);
            }
        }

        #endregion

        #region Helper Methods

        #endregion
    }
}
