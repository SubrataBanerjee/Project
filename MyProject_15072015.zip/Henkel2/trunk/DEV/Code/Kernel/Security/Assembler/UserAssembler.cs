﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.Assembler;

namespace Henkel.Business.Kernel.Security.Assembler
{
    public class UserAssembler : IAssembler<User, UserDto>
    {
        #region Implementation of IAssembler

        public User GetEntityFromDto(UserDto dto)
        {
            var user = User.CreateNewInstance(dto.LoginId);
            UpdateEntityFromDto(user, dto);
            return user;
        }

        public UserDto GetDtoFromEntity(User entity)
        {
            var dto = new UserDto();

            dto.UserId = entity.Id;
            dto.IsActive = entity.IsActive;
            dto.IsSuperAdmin = entity.IsSuperAdmin;
            dto.Locked = entity.Locked;
            dto.ChangePwdOnLogin = entity.ChangePwdOnLogin;
            dto.FailureLoginAttempt = entity.FailureLoginAttempt;
            dto.LoginId = entity.LoginId;
            dto.CreatedBy = entity.CreatedBy;
            dto.CreatedOn = entity.CreatedOn;
            dto.LastModifiedBy = entity.LastModifiedBy;
            dto.LastModifiedOn = entity.LastModifiedOn;

            return dto;
        }

        public void UpdateEntityFromDto(User entity, UserDto dto)
        {
            //Note: Id, LoginId, Password, Locked, FailureLoginAttempt, IsDeleted, IsActive, are not be updated from here
            
            //Update other fields
        }

        #endregion
    }
}
