﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Repository;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Assembler
{
    public class RoleAssembler : IAssembler<Role, RoleDto>
    {
        #region Fields

        private readonly IReadWriteRepository<Role> _roleRepository;
        private readonly IQueryableRepository<Feature> _featureRepository;
        private readonly IUserContextService _userContextService;
        
        #endregion

        #region Constructors

        public RoleAssembler(IReadWriteRepository<Role> roleRepository, IQueryableRepository<Feature> featureRepository)
        {
            _roleRepository = roleRepository;
            _featureRepository = featureRepository;
            _userContextService = ObjectLocator.GetService<IUserContextService>();
        }

        #endregion

        #region Implementation of IAssembler<Role, RoleDto>

        public Role GetEntityFromDto(RoleDto roleDto)
        {
            var role = new Role();
            role.IsActive = true;
            role.IsDeleted = false;

            UpdateEntityFromDto(role,roleDto);

            return role;
        }

        public RoleDto GetDtoFromEntity(Role role)
        {
            return new RoleDto
            {
                Id = role.Id,
                IsActive = role.IsActive,
                Name = role.Name,
            };
        }

        public void UpdateEntityFromDto(Role role, RoleDto roleDto)
        {
            role.Name = roleDto.Name;

            // Reset all role feature map entries
            role.RoleFeatureMaps.Clear();
            if (roleDto.RoleFeatureMapDtos == null || !roleDto.RoleFeatureMapDtos.Any())
                role.RemoveAllRoleFeatures();
            else
            {
                var featureIds = roleDto.RoleFeatureMapDtos.Select(x => x.FeatureId).Distinct().ToArray();
                var features = _featureRepository.Find(x => featureIds.Contains(x.Id)).ToDictionary(y => y.Id);
                var newRoleFeatureMaps = new List<RoleFeatureMap>(); 
                foreach (var roleFeatureMapDto in roleDto.RoleFeatureMapDtos)
                {
                    var feature = features[roleFeatureMapDto.FeatureId];
                    var roleFeatureMap = RoleFeatureMap.CreateNewInstance(role, feature, roleFeatureMapDto);
                    newRoleFeatureMaps.Add(roleFeatureMap);
                }
                role.SaveRoleFeatureMaps(newRoleFeatureMaps);
            }
        }

        #endregion

        #region Helper Methods

        #endregion
    }
}
