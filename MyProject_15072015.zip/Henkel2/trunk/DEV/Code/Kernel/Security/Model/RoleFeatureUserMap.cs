﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Common.Core.Model;
using System;

namespace Henkel.Business.Kernel.Security.Model
{
    public class RoleFeatureUserMap : Entity
    {
        public virtual Guid UserId { get; set; }

        public virtual User User { get; set; }

        public virtual Guid RoleId { get; set; }

        public virtual Role Role { get; set; }

        public virtual Guid FeatureId { get; set; }

        public virtual Feature Feature { get; set; }

        public virtual bool Add { get; set; }

        public virtual bool Edit { get; set; }

        public virtual bool View { get; set; }

        public virtual bool Delete { get; set; }

        public virtual bool Print { get; set; }

        public virtual bool Execute { get; set; }

        public virtual bool Activate { get; set; }

        #region Business Methods

        public static RoleFeatureUserMap CreateNewInstance(User user, RoleFeatureMap roleFeaturMap)
        {
            return new RoleFeatureUserMap
            {
                User = user,
                Role = roleFeaturMap.Role,
                Feature = roleFeaturMap.Feature,
                Add = roleFeaturMap.Add,
                Edit = roleFeaturMap.Edit,
                View = roleFeaturMap.View,
                Delete = roleFeaturMap.Delete,
                Print = roleFeaturMap.Print,
                Execute = roleFeaturMap.Execute,
                Activate = roleFeaturMap.Activate,
            };
        }

        public virtual void Update(bool add, bool edit, bool view, bool delete, bool print, bool execute, bool activate)
        {
            Add = add;
            Edit = edit;
            View = view;
            Delete = delete;
            Print = print;
            Execute = execute;
            Activate = activate;
        }

        public virtual RoleFeatureUserMapDto GetDto()
        {
            return new RoleFeatureUserMapDto
            {
                Id = Id,
                Module = Feature.Module,
                FeatureGroup = Feature.FeatureGroup,
                UserId = User.Id,
                UserName = User.LoginId,
                RoleId = Role.Id,
                RoleName = Role.Name,
                FeatureId = Feature.Id,
                FeatureName = Feature.Name,
                Add = Add,
                Edit = Edit,
                View = View,
                Delete = Delete,
                Print = Print,
                Execute = Execute,
                Activate = Activate,
            };
        }


        public static RoleFeatureUserMap CreateNewInstance(User user, Role role, Feature feature, RoleFeatureUserMapDto roleFeatureUserMapDto)
        {
            var roleFeatureUserMap = new RoleFeatureUserMap();

            roleFeatureUserMap.User = user;
            roleFeatureUserMap.Role = role;
            roleFeatureUserMap.Feature = feature;
            roleFeatureUserMap.Update(roleFeatureUserMapDto.Add, roleFeatureUserMap.Edit, roleFeatureUserMap.View, roleFeatureUserMap.Delete, roleFeatureUserMap.Print, roleFeatureUserMap.Execute, roleFeatureUserMap.Activate);

            return roleFeatureUserMap;
        }

        #endregion
    }
}
