﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Repository;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Model
{
    public class Role : AuditEntityWithSoftDelete
    {
        public virtual string Name { get; set; }

        public virtual bool IsActive { get; set; }

        private ICollection<RoleUserMap> _roleUserMaps;
        public virtual ICollection<RoleUserMap> RoleUserMaps 
        {
            get { return _roleUserMaps ?? (_roleUserMaps = new HashSet<RoleUserMap>()); }
            set { _roleUserMaps = value; }
        }

        private ICollection<RoleFeatureMap> _roleFeatureMaps;
        public virtual ICollection<RoleFeatureMap> RoleFeatureMaps 
        {
            get { return _roleFeatureMaps ?? (_roleFeatureMaps = new HashSet<RoleFeatureMap>()); }
            set { _roleFeatureMaps = value; }
        }

        private ICollection<RoleFeatureUserMap> _roleFeatureUserMaps;
        public virtual ICollection<RoleFeatureUserMap> RoleFeatureUserMaps
        {
            get { return _roleFeatureUserMaps ?? (_roleFeatureUserMaps = new HashSet<RoleFeatureUserMap>()); }
            set { _roleFeatureUserMaps = value; }
        }

        #region Business Methods

        public virtual void Add()
        {
            ValidateForAdd();

            var roleRepository = ObjectLocator.GetObject<IReadWriteRepository<Role>>();
            roleRepository.Add(this);
        }

        public virtual void Update()
        {
            ValidateForUpdate();

            var roleRepository = ObjectLocator.GetObject<IReadWriteRepository<Role>>();
            roleRepository.Update(this);
        }

        public virtual void MarkAsEnable()
        {
            IsActive = true;
        }

        public virtual void MarkAsDisable()
        {
            IsActive = false;
        }

        public virtual void AttachUser(User user)
        {
            SaveRoleFeatureUserMaps(user, RoleFeatureMaps);
            AddRoleUserMap(user, RoleUserMaps);
        }

        public virtual void DettachUser(User user)
        {
            RemoveRoleFeatureUserMaps(user);
            RemoveRoleUserMap(user);
        }

        public virtual void ResetSudoRoles()
        {
            var users = RoleUserMaps.Select(x => x.User);
            foreach(var user in users)
            {
                SaveRoleFeatureUserMaps(user, RoleFeatureMaps);
            }
        }

        public virtual void Delete()
        {
            ValidateForDelete();
            
            var roleRepository = ObjectLocator.GetObject<IReadWriteRepository<Role>>();
            roleRepository.Delete(this);
        }

        public virtual IList<RoleFeatureMapDto> GetRoleFeatureMapDtos()
        {
            var list = new List<RoleFeatureMapDto>();
            foreach(var roleFeatureMap in RoleFeatureMaps)
                list.Add(roleFeatureMap.GetDto());
            
            return list;
        }

        public virtual IList<RoleFeatureUserMapDto> GetRoleFeatureUserMapDtos()
        {
            var list = new List<RoleFeatureUserMapDto>();
            foreach (var roleFeatureUserMap in RoleFeatureUserMaps)
                list.Add(roleFeatureUserMap.GetDto());
            
            return list;
        }

        public virtual void SaveRoleFeatureMaps(ICollection<RoleFeatureMap> roleFeatureMaps)
        {
            //Clear Existing Records
            RemoveAllRoleFeatures();

            //Add new records
            foreach (var roleFeaturMap in roleFeatureMaps)
            {
                RoleFeatureMaps.Add(roleFeaturMap);
            }
        }

        public virtual void RemoveAllRoleFeatures()
        {
            RoleFeatureMaps.Clear();
        }

        public virtual void SaveRoleFeatureUserMaps(User user, ICollection<RoleFeatureMap> roleFeatureMaps)
        {
            //Clear Existing Records
            RemoveRoleFeatureUserMaps(user);

            //Add new records
            foreach (var roleFeaturMap in roleFeatureMaps)
            {
                var roleFeatureUserMap = RoleFeatureUserMap.CreateNewInstance(user, roleFeaturMap);
                RoleFeatureUserMaps.Add(roleFeatureUserMap);
            }
        }

        public virtual void SaveRoleFeatureUserMaps(User user, ICollection<RoleFeatureUserMap> newRoleFeatureUserMaps)
        {
            //Clear Existing Records
            RemoveRoleFeatureUserMaps(user);

            //Add new records
            foreach (var newRoleFeaturUserMap in newRoleFeatureUserMaps)
            {
                RoleFeatureUserMaps.Add(newRoleFeaturUserMap);
            }
        }

        public virtual void RemoveRoleFeatureUserMaps(User user)
        {
            var existingRoleFeatureUserMaps = RoleFeatureUserMaps.Where(x => x.User.Id == user.Id && x.Role.Id == this.Id).ToList();
            foreach (var existingRoleFeatureUserMap in existingRoleFeatureUserMaps)
            {
                RoleFeatureUserMaps.Remove(existingRoleFeatureUserMap);
            }
        }

        #endregion

        #region Helper Methods

        #region Validation Methods

        private void ValidateForAdd()
        {
            if (string.IsNullOrWhiteSpace(Name))
                throw new ValidationException(SecurityErrorMessage.RoleNameCanNotBeEmpty);

            var uniqueRoleValidationService = ObjectLocator.GetObject<IRoleUniquenessValidationService>();
            uniqueRoleValidationService.ValidateRoleName(Name);
        }

        private void ValidateForUpdate()
        {
            if (string.IsNullOrWhiteSpace(Name))
                throw new ValidationException(SecurityErrorMessage.RoleNameCanNotBeEmpty);

            var uniqueRoleNameValidationService = ObjectLocator.GetObject<IRoleUniquenessValidationService>();
            uniqueRoleNameValidationService.ValidateRoleName(Name, new[] { Id });
        }

        private void ValidateForDelete()
        {
            //TODO: Add Validation Here
        }

        
        private void AddRoleUserMap(User user, ICollection<RoleUserMap> roleUserMaps )
        {
            
            var existingRoleUserMap = roleUserMaps.FirstOrDefault(x => x.User.Id == user.Id && x.Role.Id == this.Id);
            if (existingRoleUserMap == null)
            {
                var roleUserMap = RoleUserMap.CreateNewInstance(user, this);
                roleUserMaps.Add(roleUserMap);
            }
        }

        private void RemoveRoleUserMap(User user)
        {
            var existingRoleUserMaps = RoleUserMaps.Where(x => x.User.Id == user.Id && x.Role.Id == this.Id).ToList();
            foreach (var existingRoleUserMap in existingRoleUserMaps)
            {
                RoleUserMaps.Remove(existingRoleUserMap);
            }
        }


        #endregion
        #endregion
    }
}
