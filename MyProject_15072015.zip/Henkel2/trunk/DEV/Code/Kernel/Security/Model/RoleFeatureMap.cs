﻿using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Common.Core.Model;
using System;

namespace Henkel.Business.Kernel.Security.Model
{
    public class RoleFeatureMap : Entity
    {
        public virtual Guid RoleId { get; set; }

        public virtual Role Role { get; set; }

        public virtual Guid FeatureId { get; set; }

        public virtual Feature Feature { get; set; }

        public virtual bool Add { get; set; }

        public virtual bool Edit { get; set; }

        public virtual bool View { get; set; }

        public virtual bool Delete { get; set; }

        public virtual bool Print { get; set; }

        public virtual bool Execute { get; set; }

        public virtual bool Activate { get; set; }

        #region Business Methods

        public virtual void Update(bool add, bool edit, bool view, bool delete, bool print, bool execute, bool activate)
        {
            Add = add;
            Edit = edit;
            View = view;
            Delete = delete;
            Print = print;
            Execute = execute;
            Activate = activate;
        }

        public virtual RoleFeatureMapDto GetDto()
        {
            return new RoleFeatureMapDto
            {
                Id = Id,
                Module = Feature.Module,
                FeatureGroup = Feature.FeatureGroup,
                RoleId = Role.Id,
                RoleName = Role.Name,
                FeatureId = Feature.Id,
                FeatureName = Feature.Name,
                Add = Add,
                Edit = Edit,
                View = View,
                Delete = Delete,
                Print = Print,
                Execute = Execute,
                Activate = Activate,
            };
        }
        
        public static RoleFeatureMap CreateNewInstance(Role role, Feature feature, RoleFeatureMapDto roleFeatureMapDto)
        {
            var roleFeatureMap = new RoleFeatureMap();
            roleFeatureMap.Role = role;
            roleFeatureMap.Feature = feature;
            roleFeatureMap.Update(roleFeatureMapDto.Add, roleFeatureMapDto.Edit, roleFeatureMapDto.View, roleFeatureMapDto.Delete, roleFeatureMapDto.Print, roleFeatureMapDto.Execute, roleFeatureMapDto.Activate);
            return roleFeatureMap;
        }

        #endregion

        
    }
}
