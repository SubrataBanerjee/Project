﻿
namespace Henkel.Business.Kernel.Security.Model
{
    public class PasswordPolicy
    {
        public string Regex { get; set; }

        public string Description { get; set; }
        
    }
}
