﻿using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Security.Notification.Resources;
using Henkel.Business.Kernel.Security.Repository;
using Henkel.Business.Kernel.Security.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Security.Model
{
    public partial class User : AggregateRootEntity
    {
        #region Fields

        public virtual string LoginId { get; set; }

        public virtual string Password { get; set; }

        public virtual bool IsActive { get; set; }

        public virtual bool Locked { get; set; }

        public virtual int FailureLoginAttempt { get; set; }

        public virtual bool ChangePwdOnLogin { get; set; }

        public virtual bool IsSuperAdmin { get; set; }

        private ICollection<RoleUserMap> _roleUserMaps;
        public virtual ICollection<RoleUserMap> RoleUserMaps 
        {
            get { return _roleUserMaps ?? (_roleUserMaps = new HashSet<RoleUserMap>()); }
            set { _roleUserMaps = value; }
        }

        private ICollection<RoleFeatureUserMap> _roleFeatureUserMaps;
        public virtual ICollection<RoleFeatureUserMap> RoleFeatureUserMaps
        {
            get { return _roleFeatureUserMaps ?? (_roleFeatureUserMaps = new HashSet<RoleFeatureUserMap>()); }
            set { _roleFeatureUserMaps = value; }
        }


        /// <summary>
        /// UnHashedNewPassword is use for temporary storage of new password in the Memory and only available in current Object life. 
        /// And there will be no mapping column required in Dadabase for this field.   
        /// </summary>
        public virtual string UnHashedNewPassword { get; set; }

        private ICollection<PasswordHistory> _passwordHistories;
        public virtual ICollection<PasswordHistory> PasswordHistories 
        {
            get { return  _passwordHistories ?? (_passwordHistories = new HashSet<PasswordHistory>()); }
            set { _passwordHistories = value; }
        }

        #endregion

        #region Constructors

        #endregion

        #region Business Methods

        public static User CreateNewInstance(string loginId)
        {
            return new User
            {
                IsActive = true,
                IsDeleted = false,
                Locked = false,
                ChangePwdOnLogin = true,
                IsSuperAdmin = false,
                LoginId = loginId
            };
        }

        public virtual void Add()
        {
            ValidateForAdd();
            
            var userRepository = ObjectLocator.GetObject<IUserRepository>();
            Id = userRepository.Add(this).Id;
            //Send Email
            SendEmail(SecurityNotificationKey.NewUser);
            ResetPassword();
        }

        public virtual void Update()
        {
            ValidateForUpdate();
            var userRepository = ObjectLocator.GetObject<IUserRepository>();
            userRepository.Update(this);
        }

        public virtual void MarkAsEnable()
        {
            IsActive = true;
        }

        public virtual void MarkAsDisable()
        {
            if(!IsSuperAdmin)
                IsActive = false;
        }

        public virtual void Delete()
        {
            ValidateForDelete();
            var userRepository = ObjectLocator.GetObject<IUserRepository>();
            userRepository.Delete(Id);
        }

        #endregion

        #region Helper Methods

        #region Validation Methods

        private void ValidateForAdd()
        {
            if (string.IsNullOrWhiteSpace(LoginId))
                throw new ValidationException(SecurityErrorMessage.UserNameCanNotBeEmpty);

            var uniqueUserNameValidationService = ObjectLocator.GetObject<IUserUniquenessValidationService>();
            uniqueUserNameValidationService.ValidateUserLoginId(LoginId);
        }

        private void ValidateForUpdate()
        {
            if (String.IsNullOrWhiteSpace(LoginId))
                throw new ValidationException(SecurityErrorMessage.UserNameCanNotBeEmpty);

            var uniqueUserNameValidationService = ObjectLocator.GetObject<IUserUniquenessValidationService>();
            uniqueUserNameValidationService.ValidateUserLoginId(LoginId, new[] {Id});
        }

        private void ValidateForDelete()
        {
            if (IsSuperAdmin)
                throw new ValidationException(SecurityErrorMessage.SuperAdminCanNotBeDeleted);
        }

        #endregion

        #region Email Sender

        private void SendEmail(string emailTemplateName, IDictionary<string, string> attachements = null)
        {
            var emailService = ObjectLocator.GetService<IEmailingService>();
            emailService.SendEmail(emailTemplateName, this, attachements);
        }

        #endregion

        #region Roles

        #endregion

        #endregion
    }
}
