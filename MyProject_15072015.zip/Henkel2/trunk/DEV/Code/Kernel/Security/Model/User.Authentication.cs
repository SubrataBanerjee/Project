﻿using Henkel.Business.Kernel.API.Customer.Helpers;
using Henkel.Business.Kernel.API.Security.Resources;
using Henkel.Business.Kernel.Security.API.DTO;
using Henkel.Business.Kernel.Security.Notification.Resources;
using Henkel.Business.Kernel.Security.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Security.Model
{
    public partial class User : AggregateRootEntity
    {
        #region Fields

        private const string USER_DEFAULT_PASSWORD = "password@123";

        #endregion

        
        #region Public Methods

        public virtual void ResetPassword()
        {
            UnHashedNewPassword = CustomerHelper.GetConfigValue(false, SecurityAdminConfigKey.DefaultUserPassword);
            if (string.IsNullOrWhiteSpace(UnHashedNewPassword))
                UnHashedNewPassword = USER_DEFAULT_PASSWORD;

            UpdatePassword(true);
        }


        public virtual void ChangePassword(string oldPassword, string newPassword, string confirmPassword)
        {
            UnHashedNewPassword = newPassword;
            var passwordValidationService = ObjectLocator.GetObject<IPasswordValidationService>();
            passwordValidationService.Validate(LoginId, oldPassword, UnHashedNewPassword, confirmPassword);

            UpdatePassword(false);
        }


        public virtual void ForgotPassword()
        {
            ResetPassword();
        }


        public virtual void Lock()
        {
            if (IsSuperAdmin)
                throw new ValidationException(SecurityErrorMessage.SuperAdminCanNotBeLocked);
                
            Locked = true;
        }


        public virtual void Unlock()
        {
            Locked = false;
            ResetFailureLoginAttempt();
        }


        public virtual void UpdateFailureLoginAttempt()
        {
            if (!IsSuperAdmin)
                FailureLoginAttempt += 1;
        }


        public virtual void ResetFailureLoginAttempt()
        {
            FailureLoginAttempt = 0;
        }


        public virtual bool IsMaxLoginAttemptExceed()
        {
            var maxFailureLoginAttemptAllowedString = CustomerHelper.GetConfigValue(false, SecurityAdminConfigKey.FailureLoginAttemptLimit);
            if (string.IsNullOrWhiteSpace(maxFailureLoginAttemptAllowedString))
                return false;

            int maxFailureLoginAttemptAllowed;
            if (!Int32.TryParse(maxFailureLoginAttemptAllowedString, out maxFailureLoginAttemptAllowed))
                return false;

            if (maxFailureLoginAttemptAllowed == 0)
                return false;

            if (FailureLoginAttempt < maxFailureLoginAttemptAllowed)
                return false;
            
            return true;
        }


        public virtual void ValidateAuthentication(string password)
        {
            if (!IsActive)
                throw new ValidationException(SecurityErrorMessage.UserIsDisabled);

            if (!IsSuperAdmin && !Locked && IsMaxLoginAttemptExceed())
                Lock();

            if (Locked)
                throw new ValidationException(SecurityErrorMessage.UserIsLocked);

            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();
            var hashedPassword = hasGeneratorService.GetHashedDataString(password);

            if (Password != hashedPassword)
            {
                UpdateFailureLoginAttempt();
                throw new ValidationException(SecurityErrorMessage.UsernameOrPasswordIsIncorrect);
            }

            //Reset 
            ResetFailureLoginAttempt();
        }


        public virtual UserToken GetToken()
        {
            var customerInfoDto = CustomerHelper.GetCustomerInfo(false);
            return new UserToken
            {
                SuccessLogin = true,
                UserId = Id,
                UserLoginId = LoginId,
                UserFullName = LoginId, //Will Override in Resource class
                CustomerFullName = customerInfoDto.CustomerFullName,
                GroupCompanyName = customerInfoDto.GroupCompanyName,
                IsActive = IsActive,
                IsDeleted = IsDeleted,
                ChangePwdOnLogin = ChangePwdOnLogin,
                UserRights = GetUserRights()
            };
        }

        

        public virtual UserRights GetUserRights()
        {
            var rights = new UserRights(Id, IsSuperAdmin);

            var roleFeatureUserMapDtos = new List<RoleFeatureUserMapDto>();
            foreach (var roleUserMap in RoleUserMaps)
            {
                if (roleUserMap.Role.RoleFeatureUserMaps.Any())
                    roleFeatureUserMapDtos.AddRange(roleUserMap.Role.RoleFeatureUserMaps.Select(x => x.GetDto()));
            }

            rights.UpdateState(roleFeatureUserMapDtos);

            return rights;
        }
        
        #endregion

        #region Helper Methods


        private void UpdatePassword(bool changePwdOnLogin)
        {
            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();
            var hashedPassword = hasGeneratorService.GetHashedDataString(UnHashedNewPassword);
            
            Password = hashedPassword;
            ChangePwdOnLogin = changePwdOnLogin;

            UpdatePasswordHistory();
            SendEmail(changePwdOnLogin ? SecurityNotificationKey.ResetPassword : SecurityNotificationKey.ChangePassword);
        }


        private void UpdatePasswordHistory()
        {
            foreach(var passwordHistory in PasswordHistories.Where(x => x.IsActive))
            {
                passwordHistory.IsActive = false;
            }
            var newPasswordHistory = PasswordHistory.CreateNewIntance(this);
            PasswordHistories.Add(newPasswordHistory);
        }

        

        #endregion
    }
}
