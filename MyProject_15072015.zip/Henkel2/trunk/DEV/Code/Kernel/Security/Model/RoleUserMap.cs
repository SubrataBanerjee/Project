﻿using Henkel.Common.Core.Model;
using System;

namespace Henkel.Business.Kernel.Security.Model
{
    public class RoleUserMap : Entity
    {
        #region Fields

        public virtual Guid UserId { get; set; }

        public virtual User User { get; set; }

        public virtual Guid RoleId { get; set; }

        public virtual Role Role { get; set; }

        #endregion

        #region Constructors


        #endregion

        #region Business Methods

        public static RoleUserMap CreateNewInstance(User user, Role role)
        {
            return new RoleUserMap
            {
                User = user,
                Role = role,
            };
        }

        #endregion


        #region Helper Methods


        #endregion



        
    }    
}
