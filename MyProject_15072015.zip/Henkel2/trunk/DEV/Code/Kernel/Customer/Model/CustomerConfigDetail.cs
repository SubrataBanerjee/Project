﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Common.Core.Model;
using System;

namespace Henkel.Business.Kernel.Customer.Model
{
    public class CustomerConfigDetail : Entity
    {
        #region Fields

        public virtual Guid CustomerInfoId { get; set; }

        public virtual string ConfigKey { get; set; }

        public virtual string ConfigValue { get; set; }

        #endregion


        #region Methods

        public virtual CustomerConfigDetailDto GetDto()
        {
            return new CustomerConfigDetailDto
            {
                Id = Id,
                CustomerInfoId = CustomerInfoId,
                ConfigKey = ConfigKey,
                ConfigValue = ConfigValue
            };
        }

        #endregion
    }
}
