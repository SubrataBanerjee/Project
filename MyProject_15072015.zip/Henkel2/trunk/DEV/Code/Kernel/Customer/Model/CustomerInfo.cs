﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Common.Core.API.DTO.ComplexType;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Repository;

namespace Henkel.Business.Kernel.Customer.Model
{
    public class CustomerInfo : AuditEntityWithSoftDelete
    {
        #region Fields

        public virtual string GroupCompanyName { get; set; }

        public virtual Contact Contact { get; set; }

        public virtual Address Address { get; set; }

        public virtual bool IsActive { get; set; }

        #endregion


        #region Public Methods

        public virtual CustomerInfoDto GetDto()
        {
            return new CustomerInfoDto
            {
                Id = Id,
                IsActive = IsActive,
                IsDeleted = IsDeleted,
                CustomerFullName = GetCustomerFullName(),
                GroupCompanyName = GroupCompanyName,
                Contact = Contact,
                Address = Address,
            };
        }

        public virtual void UpdateGeneralInfo(CustomerInfoDto customerInfoDto)
        {
            GroupCompanyName = customerInfoDto.GroupCompanyName;
            Address = customerInfoDto.Address;

            var customerInfoRepository = ObjectLocator.GetObject<IReadWriteRepository<CustomerInfo>>();
            customerInfoRepository.Update(this);
        }

        public virtual void UpdateContactDetail(CustomerInfoDto customerInfoDto)
        {
            Contact = customerInfoDto.Contact;
            var customerInfoRepository = ObjectLocator.GetObject<IReadWriteRepository<CustomerInfo>>();
            customerInfoRepository.Update(this);
        }

        public virtual string GetCustomerFullName()
        {
            if (Contact != null && Contact.PersonName != null)
                return Contact.PersonName.ToString();
            if (!string.IsNullOrWhiteSpace(GroupCompanyName))
                return GroupCompanyName;

            return string.Empty;
        }

        #endregion
    }
}
