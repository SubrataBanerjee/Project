﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Business.Kernel.Customer.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Customer.Services.Impl
{
    public class CustomerManagementService : TransactionSupportBaseService, ICustomerManagementService
    {
        #region Fields

        private readonly ICacheCustomerManagementService _cacheCustomerManagementService;
        
        #endregion

        #region Constructors

        public CustomerManagementService()
        {
            _cacheCustomerManagementService = ObjectLocator.GetObject<ICacheCustomerManagementService>();
        }

        #endregion

        #region Implementation of ICustomerManagementService

        #region Queries

        public CustomerInfoDto GetCustomerInfo()
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    return _cacheCustomerManagementService.GetCustomerInfo();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }


        public string GetCustomerFullName()
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    return _cacheCustomerManagementService.GetCustomerFullName();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }


        public string GetGroupCompanyName()
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    return _cacheCustomerManagementService.GetGroupCompanyName();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        public IList<CustomerConfigDetailDto> GetCustomerConfigDetails()
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    return _cacheCustomerManagementService.GetCustomerConfigDetails();
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }


        public string GetConfigValue(string key)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    return _cacheCustomerManagementService.GetConfigValue(key);
                }
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #region Commands


        public void UpdateCustomerGeneralInfo(CustomerInfoDto customerInfoDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    var customerInfoRepository = ObjectLocator.GetObject<IReadWriteRepository<CustomerInfo>>();
                    var customerInfo = customerInfoRepository.Find().FirstOrDefault();
                    if (customerInfo == null)
                        throw new ValidationException(CoreErrorMessage.KeyCustomerNotFoundForUpdate);

                    try
                    {
                        customerInfo.UpdateGeneralInfo(customerInfoDto);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }

                _cacheCustomerManagementService.ResetCacheData();
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }


        public void UpdateCustomerContactDetail(CustomerInfoDto customerInfoDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    var customerInfoRepository = ObjectLocator.GetObject<IReadWriteRepository<CustomerInfo>>();
                    var customerInfo = customerInfoRepository.Find().FirstOrDefault();
                    if (customerInfo == null)
                        throw new ValidationException(CoreErrorMessage.KeyCustomerNotFoundForUpdate);

                    try
                    {
                        customerInfo.UpdateContactDetail(customerInfoDto);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }

                _cacheCustomerManagementService.ResetCacheData();
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }
        #endregion

        #endregion
    }
}