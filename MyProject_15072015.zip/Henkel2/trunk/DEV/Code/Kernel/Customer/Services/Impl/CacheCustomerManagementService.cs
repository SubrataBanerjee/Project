﻿using Henkel.Business.Kernel.API.Customer.DTO;
using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Business.Kernel.Customer.Model;
using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Utils.Unity;
using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;

namespace Henkel.Business.Kernel.Customer.Services.Impl
{
    public class CacheCustomerManagementService : ICacheCustomerManagementService
    {
        #region Fields

        private readonly IReadWriteRepository<CustomerInfo> _customerInfoRepository;
        private readonly IQueryableRepository<CustomerConfigDetail> _customerConfigDetailRepository;
        private readonly ICachingService _cachingService;

        #endregion

        #region Constructors

        public CacheCustomerManagementService(IReadWriteRepository<CustomerInfo> customerInfoRepository, IQueryableRepository<CustomerConfigDetail> customerConfigDetailRepository)
        {
            _customerInfoRepository = customerInfoRepository;
            _customerConfigDetailRepository = customerConfigDetailRepository;
            _cachingService = UnityContainerFactory.Instance.Resolve<ICachingService>();
        }

        #endregion

        #region Implementation of ICacheCustomerManagementService


        public CustomerInfoDto GetCustomerInfo()
        {
            var customerInfo = GetCachedCustomerInfo();
            if (customerInfo == null)
                throw new ValidationException(CoreErrorMessage.KeyCustomerNotRegisteredIntoSystem);
            
            return customerInfo.GetDto();
        }


        public string GetCustomerFullName()
        {
            var customerInfo = GetCachedCustomerInfo();

            if (customerInfo == null)
                throw new ValidationException(CoreErrorMessage.KeyCustomerNotRegisteredIntoSystem);

            return customerInfo.GetCustomerFullName();
        }


        public string GetGroupCompanyName()
        {
            var customerInfo = GetCachedCustomerInfo();

            if (customerInfo == null)
                throw new ValidationException(CoreErrorMessage.KeyCustomerNotRegisteredIntoSystem);

            return customerInfo.GroupCompanyName;
        }


        public IList<CustomerConfigDetailDto> GetCustomerConfigDetails()
        {
            var cacheTimeOut = CoreHelper.GetCacheTimeOut();

            var allCustomerConfigDetails = _cachingService.Get(GlobalConstant.CUSTOMER_CONFIG_DETAIL_CACHE_KEY, GetAllCustomerConfigDetailDtos,
            new CachingOptions
            {
                CacheType = CoreHelper.GetCacheType(),
                CachePolicy = new CacheItemPolicy { AbsoluteExpiration = DateTime.UtcNow.AddMinutes(cacheTimeOut) }
            });

            return allCustomerConfigDetails;
        }

        public string GetConfigValue(string key)
        {
            var configDetails = GetCustomerConfigDetails();
            var configDetail = configDetails.FirstOrDefault(x => x.ConfigKey == key);
            return configDetail == null ? string.Empty : configDetail.ConfigValue;
        }

        public void ResetCacheData()
        {
            var cacheType = CoreHelper.GetCacheType();
            _cachingService.Remove(GlobalConstant.CUSTOMERINFO_CACHE_KEY, cacheType);
            _cachingService.Remove(GlobalConstant.CUSTOMER_CONFIG_DETAIL_CACHE_KEY, cacheType);
        }

        #endregion

        #region Helper Methods

        private CustomerInfo GetCachedCustomerInfo()
        {
            var cacheTimeOut = CoreHelper.GetCacheTimeOut();

            var allCustomerInfos = _cachingService.Get(GlobalConstant.CUSTOMERINFO_CACHE_KEY, GetAllCustomerInfos,
            new CachingOptions
            {
                CacheType = CoreHelper.GetCacheType(),
                CachePolicy = new CacheItemPolicy { AbsoluteExpiration = DateTime.UtcNow.AddMinutes(cacheTimeOut) }
            });

            return allCustomerInfos.FirstOrDefault();
        }

        

        private IList<CustomerInfo> GetAllCustomerInfos()
        {
            return _customerInfoRepository.Find().ToList();
        }

        private IList<CustomerConfigDetailDto> GetAllCustomerConfigDetailDtos()
        {
            var result = new List<CustomerConfigDetailDto>();

            var CustomerConfigDetails = _customerConfigDetailRepository.Find().ToList();
            result.AddRange(CustomerConfigDetails.Select(x=>x.GetDto()));
            return result;
        }

        #endregion
    }
}
