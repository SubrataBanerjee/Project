﻿using Henkel.Business.Kernel.Customer.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Customer.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class CustomerInfoConfiguration : EntityTypeConfiguration<CustomerInfo>, IEntityConfiguration
    {
        public CustomerInfoConfiguration()
        {
            var s = Map(m =>
            {
                m.ToTable("Cust_CustomerInfo");
                m.Requires("IsDeleted").HasValue(false);
            });

            s.HasKey(x => x.Id);

            s.Property(x => x.GroupCompanyName);
            s.Property(x => x.IsActive);
            s.Property(x => x.CreatedBy).HasMaxLength(50).IsUnicode(true);
            s.Property(x => x.CreatedOn);
            s.Property(x => x.LastModifiedBy).HasMaxLength(50).IsUnicode(true);
            s.Property(x => x.LastModifiedOn);
            s.Ignore(e => e.IsDeleted);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
