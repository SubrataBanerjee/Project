﻿using Henkel.Business.Kernel.Customer.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;

namespace Henkel.Business.Kernel.Customer.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class CustomerConfigDetailConfiguration : EntityTypeConfiguration<CustomerConfigDetail>, IEntityConfiguration
    {
        public CustomerConfigDetailConfiguration()
        {
            ToTable("Cust_CustomerConfigDetail");
            HasKey(x => x.Id);

            Property(x => x.ConfigKey).IsRequired();
            Property(x => x.ConfigValue);
            Property(x => x.CustomerInfoId).IsRequired();
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
