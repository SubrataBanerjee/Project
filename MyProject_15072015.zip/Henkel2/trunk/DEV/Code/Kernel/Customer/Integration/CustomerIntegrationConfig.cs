﻿using Henkel.Business.Kernel.API.Customer.Services;
using Henkel.Business.Kernel.Customer.Model;
using Henkel.Business.Kernel.Customer.Services.Impl;
using Henkel.Common.Core.Integration.Services.Impl;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Repository.EntityFramework.Impl;
using Microsoft.Practices.Unity;

namespace Henkel.Business.Kernel.Customer.Integration
{
    public class CustomerIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterRepositories(container);
            RegisterServices(container);
        }

        #region Helper Methods



        private void RegisterRepositories(IUnityContainer container)
        {
            container.RegisterType<IReadWriteRepository<CustomerInfo>, EFReadWriteRepository<CustomerInfo>>(new ContainerControlledLifetimeManager());
            container.RegisterType<IQueryableRepository<CustomerConfigDetail>, EFQueryableRepository<CustomerConfigDetail>>(new ContainerControlledLifetimeManager());
        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<ICacheCustomerManagementService, CacheCustomerManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<ICustomerManagementService, CustomerManagementService>(new ContainerControlledLifetimeManager());
        }

        #endregion
    }
}
