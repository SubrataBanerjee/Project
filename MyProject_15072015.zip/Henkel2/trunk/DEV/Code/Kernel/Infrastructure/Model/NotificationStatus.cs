﻿
namespace Henkel.Business.Kernel.Infrastructure.Model
{
    public enum NotificationStatus
    {
        Processed,
        Failed,
    }
}
