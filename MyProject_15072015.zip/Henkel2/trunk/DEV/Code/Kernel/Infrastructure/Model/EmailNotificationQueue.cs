﻿using Henkel.Business.Kernel.Infrastructure.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Text;

namespace Henkel.Business.Kernel.Infrastructure.Model
{
    public partial class EmailNotificationQueue : Entity
    {
        #region Fields

        #region Private

        private readonly IEmailSender _emailSender;

        #endregion

        public virtual Guid EmailTemplateId { get; set; }

        public virtual string To { get; set; }

        public virtual string From { get; set; }

        public virtual string CC { get; set; }

        public virtual string BCC { get; set; }

        public virtual string Subject { get; set; }

        public virtual string Body { get; set; }

        public virtual string Attachments { get; set; }

        public virtual string RaisedBy { get; set; }

        public virtual DateTime RaisedOn { get; set; }

        #endregion

        #region Constructors

        public EmailNotificationQueue()
        {
            _emailSender = ObjectLocator.GetObject<IEmailSender>();
        }

        #endregion

        #region public Business Methods

        public virtual void Add()
        {
            var notificationQueueRepository = ObjectLocator.GetObject<IReadWriteRepository<EmailNotificationQueue>>();
            notificationQueueRepository.Add(this);
        }

        public virtual void Delete()
        {
            var notificationQueueRepository = ObjectLocator.GetObject<IReadWriteRepository<EmailNotificationQueue>>();
            notificationQueueRepository.Delete(this);
        }

        public virtual void Dispatch()
        {
            EmailNotificationQueueHistory queueHistory;
            try
            {
                var to = To.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                var bcc = BCC == null ? null : BCC.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                var cc = CC == null ? null : CC.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
                var attachments = GetAttachmentDictionary(Attachments);

                _emailSender.SendEmail(Subject, Body, From, to, bcc, cc, attachments);

                queueHistory = EmailNotificationQueueHistory.CreateNewInstance(this);
            }
            catch(Exception ex)
            {
                var errorMessage = string.Format("Error sending e-mail. {0}", GetErrorMessage(ex));
                Logger.Error(GetType().Name, errorMessage);
                queueHistory = EmailNotificationQueueHistory.CreateNewInstance(this, errorMessage);
            }

            var notificationQueueHistoryRepository = ObjectLocator.GetObject<IReadWriteRepository<EmailNotificationQueueHistory>>();
            notificationQueueHistoryRepository.Add(queueHistory);
        }

        public static EmailNotificationQueue CreateNewInstance(Guid emailTemplateId, string fromEmail, string toEmail, string bccEmails, string ccEmails, string subject, string body, IDictionary<string, string> attachements = null)
        {
            var userContextService = ObjectLocator.GetService<IUserContextService>();
            return new EmailNotificationQueue
            {
                EmailTemplateId = emailTemplateId,
                From = fromEmail,
                To = toEmail,
                BCC = bccEmails,
                CC = ccEmails,
                Subject = subject,
                Body = body,
                Attachments = GetAttachmentString(attachements),
                RaisedBy = userContextService.CurrentUserName,
                RaisedOn = DateTime.UtcNow
            };
        }

        #endregion

        #region Helper Methods

        private static IDictionary<string, string> GetAttachmentDictionary(string attachments)
        {
            if (string.IsNullOrWhiteSpace(attachments))
                return null;

            var attachmentDics = new Dictionary<string, string>();

            var filePathNamePairs = attachments.Split(new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (var filePathNamePair in filePathNamePairs)
            {
                var filePathFileName = attachments.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                if(filePathFileName.Length >= 2)
                {
                    attachmentDics.Add(filePathFileName[0], filePathFileName[1]);
                }
            }
            return attachmentDics;
        }

        private static string GetAttachmentString(IDictionary<string, string> attachementDics)
        {
            if (attachementDics == null || attachementDics.Count == 0)
                return null;

            var attachments = new StringBuilder();
            foreach(var attachementDic in attachementDics)
            {
                attachments.AppendFormat("{0}|{1};", attachementDic.Key, attachementDic.Value);
            }
            return attachments.ToString();
        }

        private static string GetErrorMessage(Exception ex)
        {
            if (ex.InnerException != null)
                return GetErrorMessage(ex.InnerException);
            return ex.Message;
        }

        #endregion

        
    }
}
