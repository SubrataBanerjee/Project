﻿using Henkel.Business.Kernel.Infrastructure.API.DTO;
using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Infrastructure.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Model
{
    public partial class EmailTemplate : Entity
    {
        #region Fields

        #region private

        private IEmailTokenProvider _emailTokenProvider;

        #endregion

        /// <summary>
        /// Gets or sets the name
        /// </summary>
        public virtual string Name { get; set; }


        /// <summary>
        /// Gets or sets the From
        /// </summary>
        public virtual string From { get; set; }


        /// <summary>
        /// Gets or sets the To
        /// </summary>
        public virtual string To { get; set; }


        /// <summary>
        /// Gets or sets the CC
        /// </summary>
        public virtual string CC { get; set; }


        /// <summary>
        /// Gets or sets the BCC
        /// </summary>
        public virtual string BCC { get; set; }


        /// <summary>
        /// Gets or sets the subject
        /// </summary>
        public virtual string Subject { get; set; }


        /// <summary>
        /// Gets or sets the body
        /// </summary>
        public virtual string Body { get; set; }


        /// <summary>
        /// Gets or sets a value indicating whether the template is active
        /// </summary>
        public virtual bool IsActive { get; set; }


        /// <summary>
        /// /// Get Token Provider Name
        /// </summary>
        public virtual string EmailTokenProviderName { get; set; }

        #endregion

        #region Business Logic


        /// <summary>
        /// Get Token Provider Service as per configuration
        /// </summary>
        public virtual IEmailTokenProvider EmailTokenProvider
        {
            get
            {
                if (string.IsNullOrWhiteSpace(EmailTokenProviderName))
                    return null;

                if (_emailTokenProvider == null)
                    _emailTokenProvider = ObjectLocator.TryGetObject<IEmailTokenProvider>(EmailTokenProviderName);
                return _emailTokenProvider;
            }
        }

        public virtual void SendEmail(Guid entityId, IDictionary<string, string> attachements = null, bool sendInQueue = true)
        {
            var tokens = new List<Token>();
            if (EmailTokenProvider != null)
                EmailTokenProvider.AddTokens(tokens, entityId);
            SendEmailNotification(tokens, attachements);
        }


        public virtual void SendEmail(IEntity entity, IDictionary<string, string> attachements = null, bool sendInQueue = true)
        {
            var tokens = new List<Token>();
            if (EmailTokenProvider != null)
                EmailTokenProvider.AddTokens(tokens, entity);
            SendEmailNotification(tokens, attachements,sendInQueue);
        }

        #endregion

        #region Helper Methods

        private void SendEmailNotification(List<Token> tokens, IDictionary<string, string> attachements = null, bool sendInQueue = true)
        {
            //tokens
            var tokenizer = ObjectLocator.GetObject<ITokenizer>();

            var fromEmail = tokenizer.Replace(From, tokens, false);
            var toEmail = tokenizer.Replace(To, tokens, false);
            var subject = tokenizer.Replace(Subject, tokens, false);
            var body = tokenizer.Replace(Body, tokens, true);
            var bccEmails = String.IsNullOrWhiteSpace(BCC) ? null : tokenizer.Replace(BCC, tokens, false);
            var ccEmails = String.IsNullOrWhiteSpace(CC) ? null : tokenizer.Replace(CC, tokens, false);

            if(!sendInQueue)
            {
                var emailDispatchingService = ObjectLocator.GetService<IEmailDispatchingService>();
                emailDispatchingService.DispatchEmail(Id, fromEmail, toEmail, bccEmails, ccEmails, subject, body, attachements);
            }
            else
            {
                var emailNotificationQueueService = ObjectLocator.GetObject<IEmailNotificationQueueService>();
                var notificationQueue = EmailNotificationQueue.CreateNewInstance(Id, fromEmail, toEmail, bccEmails, ccEmails, subject, body, attachements);
                emailNotificationQueueService.AddNotificationQueue(notificationQueue);
            }
        }

        #endregion
    }
}
