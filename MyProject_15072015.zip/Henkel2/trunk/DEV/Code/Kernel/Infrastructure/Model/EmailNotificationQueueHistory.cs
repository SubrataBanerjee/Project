﻿using Henkel.Common.Core.Model;
using System;

namespace Henkel.Business.Kernel.Infrastructure.Model
{
    public class EmailNotificationQueueHistory : Entity
    {
        #region Fields

        public virtual Guid EmailTemplateId { get; set; }

        public virtual string To { get; set; }

        public virtual string From { get; set; }

        public virtual string CC { get; set; }

        public virtual string BCC { get; set; }

        public virtual string Subject { get; set; }

        public virtual string Body { get; set; }

        public virtual string Attachments { get; set; }

        public virtual string RaisedBy { get; set; }

        public virtual DateTime RaisedOn { get; set; }

        public virtual DateTime ProcessedOn { get; set; }

        public virtual NotificationStatus Status { get; set; }

        public virtual string ErrorMessage { get; set; }

        #endregion

        #region Methods

        public static EmailNotificationQueueHistory CreateNewInstance(EmailNotificationQueue notificationQueue, string errorMessage = null)
        {
            return new EmailNotificationQueueHistory
            {
                EmailTemplateId = notificationQueue.EmailTemplateId,
                From = notificationQueue.From,
                To = notificationQueue.To,
                CC = notificationQueue.CC,
                BCC = notificationQueue.BCC,
                Subject = notificationQueue.Subject,
                Body = notificationQueue.Body,
                Attachments = notificationQueue.Attachments,
                RaisedBy = notificationQueue.RaisedBy,
                RaisedOn = notificationQueue.RaisedOn,
                ProcessedOn = DateTime.UtcNow,
                ErrorMessage = errorMessage,
                Status = string.IsNullOrWhiteSpace(errorMessage) ? NotificationStatus.Processed : NotificationStatus.Failed,
            };
        }

        #endregion
    }
}
