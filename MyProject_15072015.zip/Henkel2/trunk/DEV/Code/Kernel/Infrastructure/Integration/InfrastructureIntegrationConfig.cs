﻿using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Infrastructure.Model;
using Henkel.Business.Kernel.Infrastructure.Services;
using Henkel.Business.Kernel.Infrastructure.Services.Impl;
using Henkel.Common.Core.Integration.Services.Impl;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Repository.EntityFramework.Impl;
using Microsoft.Practices.Unity;

namespace Henkel.Business.Kernel.Infrastructure.Integration
{
    public class InfrastructureIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterRepository(container);
            RegisterAssemblers(container);
            RegisterServices(container);
            RegisterScheduledTasks(container);
        }

        private void RegisterRepository(IUnityContainer container)
        {
            container.RegisterType<IQueryableRepository<EmailTemplate>, EFQueryableRepository<EmailTemplate>>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<EmailNotificationQueue>, EFReadWriteRepository<EmailNotificationQueue>>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<EmailNotificationQueueHistory>, EFReadWriteRepository<EmailNotificationQueueHistory>>(new ContainerControlledLifetimeManager());
        }

        private void RegisterAssemblers(IUnityContainer container)
        {

        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<IEmailValidationService, EmailValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailSender, EmailSender>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailTemplateService, EmailTemplateService>(new ContainerControlledLifetimeManager());
            container.RegisterType<ITokenizer, Tokenizer>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailingService, EmailingService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailNotificationQueueService, EmailNotificationQueueService>(new ContainerControlledLifetimeManager());
        }

        private void RegisterScheduledTasks(IUnityContainer container)
        {
            container.RegisterType<IEmailDispatchingService, EmailDispatchingService>(new ContainerControlledLifetimeManager());
        }
    }
}
