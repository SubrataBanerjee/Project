﻿using Henkel.Business.Kernel.Infrastructure.API.DTO;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Services
{
    public interface ITokenizer
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="template"></param>
        /// <param name="tokens"></param>
        /// <param name="htmlEncode"></param>
        /// <returns></returns>
        string Replace(string template, IEnumerable<Token> tokens, bool htmlEncode);
    }
}
