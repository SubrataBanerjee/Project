﻿using Henkel.Business.Kernel.Infrastructure.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;

namespace Henkel.Business.Kernel.Infrastructure.Services.Impl
{
    public class EmailNotificationQueueService : IEmailNotificationQueueService
    {
        #region fields
        #endregion

        #region Constructor

        public EmailNotificationQueueService()
        {
        }

        #endregion
        
        #region Implementation of IEmailNotificationQueueService

        public void AddNotificationQueue(EmailNotificationQueue notificationQueue)
        {
             notificationQueue.Add();
        }

        public IList<EmailNotificationQueue> GetNotificationQueueEntries(int count)
        {
            var notificationQueueRepository = ObjectLocator.GetObject<IReadWriteRepository<EmailNotificationQueue>>();
            return notificationQueueRepository.Find(sortExpression: x => x.RaisedOn, maxRows: count).ToList();
        }

        #endregion
    }
}
