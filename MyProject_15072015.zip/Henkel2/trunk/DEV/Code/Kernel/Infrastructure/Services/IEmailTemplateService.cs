﻿using Henkel.Business.Kernel.Infrastructure.Model;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Services
{
    /// <summary>
    /// Email template service
    /// </summary>
    public partial interface IEmailTemplateService
    {
        /// <summary>
        /// Gets a email template by name
        /// </summary>
        /// <param name="EmailTemplateName">Email template name</param>
        /// <returns>Message template</returns>
        EmailTemplate GetEmailTemplateByName(string EmailTemplateName);

        /// <summary>
        /// Gets all email templates
        /// </summary>
        /// <returns>Email template list</returns>
        IList<EmailTemplate> GetAllEmailTemplates();
    }
}
