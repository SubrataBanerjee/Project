﻿using Henkel.Business.Kernel.API.Customer.Helpers;
using Henkel.Business.Kernel.API.Infrastructure.Resources;
using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Infrastructure.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Services.Impl
{
    public class EmailDispatchingService : IEmailDispatchingService
    {
        #region Fields

        private readonly IReadWriteRepository<EmailNotificationQueue> _notificationQueueRepository;
        private const int DEFAULT_NOTIFICATION_QUEUE_COUNT_FOR_DISPACH = 50;

        #endregion

        #region Constructors

        public EmailDispatchingService(IReadWriteRepository<EmailNotificationQueue> notificationQueueRepository)
        {
            _notificationQueueRepository = notificationQueueRepository;
        }

        #endregion

        #region Implemetation of IEmailDispatchingService

        public void DispatchQueuedEmail()
        {
            var emailNotificationQueueService = ObjectLocator.GetObject<IEmailNotificationQueueService>();
            
            var notificationQueueCountForDispatchStr = CustomerHelper.GetConfigValue(false, InfrastructureAdminConfigKey.NotificationQueueCountForDispatch);
            int notificationQueueCountForDispatch;
            if (string.IsNullOrWhiteSpace(notificationQueueCountForDispatchStr) || !int.TryParse(notificationQueueCountForDispatchStr, out notificationQueueCountForDispatch))
                notificationQueueCountForDispatch = DEFAULT_NOTIFICATION_QUEUE_COUNT_FOR_DISPACH;
            
            var notificationQueues = emailNotificationQueueService.GetNotificationQueueEntries(notificationQueueCountForDispatch);

            foreach (var notificationQueue in notificationQueues)
            {
                try
                {
                    notificationQueue.Dispatch();
                    notificationQueue.Delete();
                }
                catch(Exception)
                {
                    //Ignore
                }
            }
        }

        public void DispatchEmail(Guid emailTemplateId, string fromEmail, string toEmail, string bccEmails, string ccEmails, string subject, string body, IDictionary<string, string> attachements = null)
        {
            var notificationQueue  = EmailNotificationQueue.CreateNewInstance(emailTemplateId, fromEmail, toEmail, bccEmails, ccEmails, subject, body, attachements);
            notificationQueue.Dispatch();
        }

        #endregion

        #region Helper Methods

        
        #endregion
    }
}
