﻿using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Services
{
    public interface IEmailSender
    {
        void SendEmail(string subject, string body, string fromAddress, IList<string> toAddress, IList<string> bcc = null, IList<string> cc = null, IDictionary<string, string> attachements = null);
    }
}
