﻿using Henkel.Business.Kernel.Infrastructure.Model;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Services
{
    public interface IEmailNotificationQueueService
    {
        void AddNotificationQueue(EmailNotificationQueue notificationQueue);
        IList<EmailNotificationQueue> GetNotificationQueueEntries(int count);
    }
}
