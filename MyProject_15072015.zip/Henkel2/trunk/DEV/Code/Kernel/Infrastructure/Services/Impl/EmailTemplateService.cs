﻿using Henkel.Business.Kernel.API.Infrastructure.Resources;
using Henkel.Business.Kernel.Infrastructure.Model;
using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;

namespace Henkel.Business.Kernel.Infrastructure.Services.Impl
{
    public partial class EmailTemplateService : IEmailTemplateService
    {
        #region Fields

        private readonly IQueryableRepository<EmailTemplate> _emailTemplateRepository;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="cacheService"></param>
        /// <param name="emailTemplateRepository"></param>
        public EmailTemplateService(IQueryableRepository<EmailTemplate> emailTemplateRepository)
        {
            _emailTemplateRepository = emailTemplateRepository;
        }

        #endregion

        #region Implementation of IEmailTemplateService

        /// <summary>
        /// Gets a message template
        /// </summary>
        /// <param name="EmailTemplateName">Message template name</param>
        /// <returns>Message template</returns>
        public virtual EmailTemplate GetEmailTemplateByName(string emailTemplateName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(emailTemplateName))
                    throw new ValidationException(InfrastructureErrorMessage.EmailTemplateNameCanNotBeBlank);
                
                var allEmailTemplates = GetAllEmailTemplates();
                return allEmailTemplates.FirstOrDefault(x => x.Name == emailTemplateName);
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        /// <summary>
        /// Gets all message templates
        /// </summary>
        /// <returns>Message template list</returns>
        public virtual IList<EmailTemplate> GetAllEmailTemplates()
        {
            string key = GlobalConstant.EMAILTEMPLATE_CACHE_KEY;
            var cacheTimeOut = CoreHelper.GetCacheTimeOut();

            var cacheService = ObjectLocator.GetService<ICachingService>();
            return cacheService.Get(key, () => { return GetAllTemplates(); },
            new CachingOptions
            {
                CacheType = CoreHelper.GetCacheType(),
                CachePolicy = new CacheItemPolicy { AbsoluteExpiration = DateTime.UtcNow.AddMinutes(cacheTimeOut) }
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IList<EmailTemplate> GetAllTemplates()
        {
            try
            {
                var result = _emailTemplateRepository.Find().ToList();
                return result.Count == 0 ? null : result;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        #endregion

        #region Helpers


        #endregion
    }
}
