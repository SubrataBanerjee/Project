﻿using Henkel.Business.Kernel.API.Infrastructure.Resources;
using Henkel.Business.Kernel.Infrastructure.API.Services;
using Henkel.Business.Kernel.Infrastructure.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Exceptions;
using System;
using System.Collections.Generic;

namespace Henkel.Business.Kernel.Infrastructure.Services.Impl
{
    public class EmailingService : IEmailingService
    {
        #region Fields

        #endregion

        #region Ctor

        public EmailingService()
        {
        }

        #endregion

        #region Implementation of IEmailService

        public virtual void SendEmail(string emailTemplateName, IEntity entity, IDictionary<string, string> attachements = null)
        {
            try
            {
                var emailTemplate = GetEmailTemplateByName(emailTemplateName);
                emailTemplate.SendEmail(entity, attachements);
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }
        #endregion

        #region Utilities

        private static EmailTemplate GetEmailTemplateByName(string emailTemplateName)
        {
            var emailTemplateService = ObjectLocator.GetObject<IEmailTemplateService>();
            var emailTemplate = emailTemplateService.GetEmailTemplateByName(emailTemplateName);
            if (emailTemplate == null)
                throw new ValidationException(InfrastructureErrorMessage.EmailTemplateIsNotExist);
            return emailTemplate;
        }

        #endregion
    }
}
