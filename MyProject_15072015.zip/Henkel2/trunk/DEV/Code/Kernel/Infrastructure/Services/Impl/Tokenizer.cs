﻿using Henkel.Business.Kernel.API.Infrastructure.Resources;
using Henkel.Business.Kernel.Infrastructure.API.DTO;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Resources;
using Henkel.Common.Core.Exceptions;
using System;
using System.Collections.Generic;
using System.Web;

namespace Henkel.Business.Kernel.Infrastructure.Services.Impl
{
    public partial class Tokenizer : ITokenizer
    {
        public string Replace(string template, IEnumerable<Token> tokens, bool htmlEncode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(template))
                    throw new ValidationException(InfrastructureErrorMessage.EmailTemplateNameCanNotBeBlank);

                if (tokens == null)
                    throw new ValidationException(InfrastructureErrorMessage.TokenCanNotBeBlank);

                foreach (var token in tokens)
                {
                    string tokenValue = token.Value;
                    //do not encode URLs
                    if (htmlEncode && !token.NeverHtmlEncoded)
                        tokenValue = HttpUtility.HtmlEncode(tokenValue);
                    template = Replace(template, String.Format(@"%{0}%", token.Key), tokenValue);
                }
                return template;
            }
            catch (ValidationException)
            {
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new ValidationException(CoreErrorMessage.KeyErrorProcessingRequest);
            }
        }

        private string Replace(string original, string pattern, string replacement)
        {
            return original.Replace(pattern, replacement);
        }
    }
}
