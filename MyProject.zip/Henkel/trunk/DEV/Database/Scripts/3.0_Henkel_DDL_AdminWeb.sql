IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Sys_Feature]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Sys_Feature](
	[Id] [uniqueidentifier] CONSTRAINT [DF_Feature_Id] DEFAULT (NEWID()) NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[Module] [nvarchar](50) NOT NULL,
	[Add] [bit] NOT NULL,
	[Edit] [bit] NOT NULL,
	[View] [bit] NOT NULL,
	[Delete] [bit] NOT NULL,
	[Print] [bit] NOT NULL,
	[Execute] [bit] NOT NULL,
	[Activate] [bit] NOT NULL,
	CONSTRAINT [PK_Feature] PRIMARY KEY CLUSTERED ([Id] ASC),
    CONSTRAINT [UQ_Feature_Name] UNIQUE NONCLUSTERED ([Name] ASC),
)
END

GO

------------------------------------------------

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_User]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_User] (
	[Id] [uniqueidentifier] CONSTRAINT [DF_User_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[LoginId] [nvarchar](50) NOT NULL,
	[Password] [nvarchar] (200) NULL,
	[IsActive] [bit] CONSTRAINT [DF_User_IsActive] DEFAULT ((1)) NOT NULL,
	[Locked] [bit] CONSTRAINT [DF_User_Locked] DEFAULT ((0)) NULL,
	[ChangePwdOnLogin] [BIT] CONSTRAINT [DF_User_ChangePwdOnLogin] DEFAULT ((1)) NULL,
	[FailureLoginAttempt] [int] CONSTRAINT [DF_User_FailureLoginAttempt] DEFAULT ((0)) NULL,
	[IsSuperAdmin] [bit] NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NULL,
	[LastModifiedBy] [nvarchar](50) NULL,
	[LastModifiedOn] [datetime] NULL,
	[IsDeleted] [bit] CONSTRAINT [DF_User_IsDeleted] DEFAULT ((0)) NOT NULL,
    CONSTRAINT [PK_User] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
	CONSTRAINT [UQ_User_LoginId] UNIQUE NONCLUSTERED ([LoginId] ASC, [CustomerId] ASC),
 )
END

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_PasswordHistory]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_PasswordHistory] (
	[Id] [uniqueidentifier] CONSTRAINT [DF_PasswordHistory_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[Password] [nvarchar] (200) NOT NULL,
	[UserId] [uniqueidentifier] NOT NULL,
	[IsActive] [bit] CONSTRAINT [DF_PasswordHistory_IsActive] DEFAULT ((1)) NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NULL,
 CONSTRAINT [PK_PasswordHistory] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
 CONSTRAINT [FK_PasswordHistory_User] FOREIGN KEY ([UserId], [CustomerId]) REFERENCES [Cust_User] ([Id], [CustomerId]),
 )
END

GO


IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_Resource]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_Resource](
	[Id] [uniqueidentifier] CONSTRAINT [DF_Resource_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[Code] [nvarchar](50) NOT NULL,
	[UserId] [uniqueidentifier] NULL,
	[Address_Line1] [nvarchar](300) NULL,
	[Address_Line2] [nvarchar](300) NULL,
	[Address_Line3] [nvarchar](300) NULL,
	[Address_City] [nvarchar](100) NULL,
	[Address_State] [nvarchar](100) NULL,
	[Address_CountryId] [nvarchar](100) NULL,
	[Address_Pin] [nvarchar](50) NULL,
	[Contact_PersonName_Prefix] [nvarchar](10) NULL,
	[Contact_PersonName_FirstName] [nvarchar](100) NULL,
	[Contact_PersonName_MiddleName] [nvarchar](100) NULL,
	[Contact_PersonName_LastName] [nvarchar](100) NULL,
	[Contact_PhoneNumber] [nvarchar](100) NULL,
	[Contact_Email] [nvarchar](200) NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NULL,
	[LastModifiedBy] [nvarchar](50) NULL,
	[LastModifiedOn] [datetime] NULL,
	[IsActive] [bit] CONSTRAINT [DF_Resource_IsActive] DEFAULT ((1)) NOT NULL,
	[IsDeleted] [bit] CONSTRAINT [DF_Resource_IsDeleted] DEFAULT ((0)) NOT NULL,
	CONSTRAINT [PK_Resource] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
    CONSTRAINT [FK_Resource_User] FOREIGN KEY ([UserId], [CustomerId]) REFERENCES [Cust_User] ([Id], [CustomerId]),
    CONSTRAINT [UQ_Resource_Code] UNIQUE NONCLUSTERED ([Code] ASC, [CustomerId] ASC),
)
END

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_Role]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_Role](
	[Id] [uniqueidentifier] CONSTRAINT [DF_Role_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](50) NOT NULL,
	[CreatedBy] [nvarchar](50) NULL,
	[CreatedOn] [datetime] NULL,
	[LastModifiedBy] [nvarchar](50) NULL,
	[LastModifiedOn] [datetime] NULL,
	[IsActive] [bit] CONSTRAINT [DF_Role_IsActive] DEFAULT ((1)) NOT NULL,
	[IsDeleted] [bit] CONSTRAINT [DF_Role_IsDeleted] DEFAULT ((0)) NOT NULL,
	CONSTRAINT [PK_Role] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
    CONSTRAINT [UQ_Role_Name] UNIQUE NONCLUSTERED ([Name] ASC, [CustomerId] ASC),
)
END

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_RoleFeatureMap]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_RoleFeatureMap](
	[Id] [uniqueidentifier] CONSTRAINT [DF_RoleFeatureMap_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[RoleId] [uniqueidentifier] NOT NULL,
	[FeatureId] [uniqueidentifier] NOT NULL,
	[Add] [bit] NOT NULL,
	[Edit] [bit] NOT NULL,
	[View] [bit] NOT NULL,
	[Delete] [bit] NOT NULL,
	[Print] [bit] NOT NULL,
	[Execute] [bit] NOT NULL,
	[Activate] [bit] NOT NULL,
	CONSTRAINT [PK_RoleFeatureMap] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
    CONSTRAINT [FK_RoleFeatureMap_Role] FOREIGN KEY ([RoleId], [CustomerId]) REFERENCES [Cust_Role] ([Id], [CustomerId]),
	CONSTRAINT [FK_RoleFeatureMap_Feature] FOREIGN KEY ([FeatureId]) REFERENCES [Sys_Feature] ([Id]),
)
END

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_RoleUserMap]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_RoleUserMap](
	[Id] [uniqueidentifier] CONSTRAINT [DF_RoleUserMap_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[RoleId] [uniqueidentifier] NOT NULL,
	[UserId] [uniqueidentifier] NOT NULL,
	CONSTRAINT [PK_RoleUserMap] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
    CONSTRAINT [FK_RoleUserMap_Role] FOREIGN KEY ([RoleId], [CustomerId]) REFERENCES [Cust_Role] ([Id], [CustomerId]),
	CONSTRAINT [FK_RoleUserMap_User] FOREIGN KEY ([UserId], [CustomerId]) REFERENCES [Cust_User] ([Id], [CustomerId]),
)
END

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Cust_RoleFeatureUserMap]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Cust_RoleFeatureUserMap](
	[Id] [uniqueidentifier] CONSTRAINT [DF_RoleFeatureUserMap_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[RoleId] [uniqueidentifier] NOT NULL,
	[UserId] [uniqueidentifier] NOT NULL,
	[FeatureId] [uniqueidentifier] NOT NULL,
	[Add] [bit] NOT NULL,
	[Edit] [bit] NOT NULL,
	[View] [bit] NOT NULL,
	[Delete] [bit] NOT NULL,
	[Print] [bit] NOT NULL,
	[Execute] [bit] NOT NULL,
	[Activate] [bit] NOT NULL,
	CONSTRAINT [PK_RoleFeatureUserMap] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
    CONSTRAINT [FK_RoleFeatureUserMap_Role] FOREIGN KEY ([RoleId], [CustomerId]) REFERENCES [Cust_Role] ([Id], [CustomerId]),
	CONSTRAINT [FK_RoleFeatureUserMap_User] FOREIGN KEY ([UserId], [CustomerId]) REFERENCES [Cust_User] ([Id], [CustomerId]),
	CONSTRAINT [FK_RoleFeatureUserMap_Feature] FOREIGN KEY ([FeatureId]) REFERENCES [Sys_Feature] ([Id]),
)
END

GO






















-----------------------
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Infra_EmailTemplate]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Infra_EmailTemplate](
	[Id] [uniqueidentifier] CONSTRAINT [DF_EmailTemplate_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[Name] [nvarchar](200) NOT NULL,
	[From] [nvarchar](200) NOT NULL,
	[To] [nvarchar](1000) NOT NULL,
	[CC] [nvarchar](MAX) NULL,
	[BCC] [nvarchar](MAX) NULL,
	[Subject] [nvarchar](1000) NOT NULL,
	[Body] [nvarchar](max) NOT NULL,
	[EmailTokenProviderName] [nvarchar](200) NULL,
	[IsActive] [bit] NOT NULL,
	CONSTRAINT [PK_EmailTemplate] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
)
END
-----------------------

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Infra_NotificationQueue]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Infra_NotificationQueue](
	[Id] [uniqueidentifier] CONSTRAINT [DF_NotificationQueue_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[EmailTemplateId] [uniqueidentifier] NOT NULL,
	[From] [nvarchar] (200) NOT NULL,
	[To] [nvarchar] (1000) NOT NULL,
	[CC] [nvarchar](MAX) NULL,
	[BCC] [nvarchar](MAX) NULL,
	[Subject] [nvarchar] (1000) NOT NULL,
	[Body] [nvarchar](max) NOT NULL,
	[Attachments] [nvarchar] (1000) NULL,
	[RaisedBy] [nvarchar] (50) NULL,
	[RaisedOn] [datetime] NULL,
	CONSTRAINT [PK_NotificationQueue] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
)
END

----------------------

GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Infra_NotificationQueueHist]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Infra_NotificationQueueHist](
	[Id] [uniqueidentifier] CONSTRAINT [DF_NotificationQueueHist_Id] DEFAULT (NEWID()) NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[EmailTemplateId] [uniqueidentifier] NOT NULL,
	[From] [nvarchar] (200) NOT NULL,
	[To] [nvarchar] (1000) NOT NULL,
	[CC] [nvarchar](MAX) NULL,
	[BCC] [nvarchar](MAX) NULL,
	[Subject] [nvarchar] (1000) NOT NULL,
	[Body] [nvarchar](max) NOT NULL,
	[Attachments] [nvarchar] (1000) NULL,
	[RaisedBy] [nvarchar] (50) NULL,
	[RaisedOn] [datetime] NULL,
	[ProcessedOn] [datetime] NULL,
	[Status] [nvarchar] (50) NULL,
	[ErrorMessage] [nvarchar] (1000) NULL,
	CONSTRAINT [PK_NotificationQueueHist] PRIMARY KEY CLUSTERED ([Id] ASC, [CustomerId] ASC),
)
END

---------------------
GO