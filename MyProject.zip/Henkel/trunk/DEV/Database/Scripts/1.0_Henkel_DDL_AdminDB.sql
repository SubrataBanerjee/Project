IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Admin_CustomerDetail]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Admin_CustomerDetail](
	[CustomerId] [uniqueidentifier] NOT NULL,
	[SubDomain] [varchar](20) NULL,
	[Suffix] [nvarchar](20) NULL,
	[Name] [nvarchar](50) NULL,
	[ConnectionString] [nvarchar](200) NULL
) ON [PRIMARY]
END

GO

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Admin_CustomerDetailConfig]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[Admin_CustomerDetailConfig](
	[Id] [uniqueidentifier]  NOT NULL,
	[CustomerId] [uniqueidentifier] NOT NULL,
	[ConfigKey] [nvarchar](100) NULL,
	[ConfigValue] [nvarchar](500) NULL,
 CONSTRAINT [PK_Admin_CustomerDetailConfig] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

END

GO