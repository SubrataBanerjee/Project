--SELECT NEWID()
BEGIN TRAN
--**************ADMIN DB SCRIPT**********************************

--**************HENKEL_ICMS RELATED SCRIPT***********************

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetail WHERE CustomerId = '221DFD48-75A0-4C58-8185-7F0238DC170D')
BEGIN
INSERT INTO Admin_CustomerDetail (CustomerId, SubDomain, Suffix, Name, ConnectionString)
VALUES ('221DFD48-75A0-4C58-8185-7F0238DC170D', 'localhost', 'HenkelICMS', 'HenkelICMS', 'Data Source=(local);Initial Catalog=Henkel_ICMS; Integrated Security=True')
END

--******Config entries****************************
IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'E87A58E7-D36C-4F69-83D7-3352F3B68214')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('E87A58E7-D36C-4F69-83D7-3352F3B68214', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'CacheTimeOut', '5')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'DE0C4F88-39C8-4624-9FDA-A47095A797E4')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('DE0C4F88-39C8-4624-9FDA-A47095A797E4', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'SmtpHost', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'EEBE771A-CDDC-4FBC-8081-CEE3508D95C9')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('EEBE771A-CDDC-4FBC-8081-CEE3508D95C9', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'SmtpPort', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'BAC81339-7110-4E99-A919-D0E90FB7EF9F')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('BAC81339-7110-4E99-A919-D0E90FB7EF9F', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'FromEmailId', 'abc@xyz.com')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '86E4B889-C789-44C0-B141-6E778247CD3C')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('86E4B889-C789-44C0-B141-6E778247CD3C', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'UploadPath', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'E308B6DD-8B9A-4C43-9213-7AAEDCC81744')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('E308B6DD-8B9A-4C43-9213-7AAEDCC81744', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'MaxFailureLoginAttemptAllowed', '3')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '44B69A23-20D0-452B-AD3B-F1266B9E38EC')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('44B69A23-20D0-452B-AD3B-F1266B9E38EC', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'DefaultPassword', 'password@123')
END

--**************END OF HENKEL_ICMS RELATED SCRIPT****************

--*************END OF ADMIN DB SCRIPT****************************

--ROLLBACK TRAN
COMMIT TRAN