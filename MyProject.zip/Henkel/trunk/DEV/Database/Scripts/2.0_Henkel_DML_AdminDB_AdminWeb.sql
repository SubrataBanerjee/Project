--SELECT NEWID()
BEGIN TRAN 
--**************ADMIN DB SCRIPT**********************************

--**************HENKEL_ADMINWEB RELATED SCRIPT*******************

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetail WHERE CustomerId = 'A0631E03-0CC1-4938-976D-89DAF94DC20C')
BEGIN
INSERT INTO Admin_CustomerDetail (CustomerId, SubDomain, Suffix, Name, ConnectionString)
VALUES ('A0631E03-0CC1-4938-976D-89DAF94DC20C', 'localhost', 'HenkelAdmin', 'HenkelAdmin', 'Data Source=(local);Initial Catalog=Henkel_AdminWeb; Integrated Security=True')
END

--******Config entries****************************
IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '50244644-1890-46C9-A03C-BF37CBA836FA')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('50244644-1890-46C9-A03C-BF37CBA836FA', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'CacheTimeOut', '5')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '57EE4153-3B07-4547-A258-C1B85246C16C')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('57EE4153-3B07-4547-A258-C1B85246C16C', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'SmtpHost', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '21F7AC19-171D-403D-A82E-DAABA7C616BD')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('21F7AC19-171D-403D-A82E-DAABA7C616BD', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'SmtpPort', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'D0C69D3A-B956-4C98-9D96-91E5455FB5CF')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('D0C69D3A-B956-4C98-9D96-91E5455FB5CF', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'FromEmailId', 'abc@xyz.com')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '8487C1D8-761E-4FEC-85A1-638CF5A15913')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('8487C1D8-761E-4FEC-85A1-638CF5A15913', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'UploadPath', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '89610707-6906-4016-BBD5-1213D8DBC400')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('89610707-6906-4016-BBD5-1213D8DBC400', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'MaxFailureLoginAttemptAllowed', '3')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'F2EC6F5A-0963-4A9C-AEA9-9DD4E20E6963')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('F2EC6F5A-0963-4A9C-AEA9-9DD4E20E6963', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'DefaultPassword', 'password@123')
END
--**************END OF HENKEL_ADMINWEB RELATED SCRIPT************

--*************END OF ADMIN DB SCRIPT****************************

--ROLLBACK TRAN
COMMIT TRAN