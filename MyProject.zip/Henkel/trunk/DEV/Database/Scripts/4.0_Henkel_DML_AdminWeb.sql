BEGIN TRAN

---System Table entries-----------------
IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = 'EE9C8823-9C14-4C4A-B249-37D74B325A9C')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('EE9C8823-9C14-4C4A-B249-37D74B325A9C', 'Role', 'Security', 1, 1, 1, 1, 1, 0, 1)
END

IF NOT EXISTS (SELECT 1 FROM Sys_Feature WHERE Id = '836A8C0F-A754-4101-A6D4-0B2B4E13A668')
BEGIN
INSERT INTO Sys_Feature ([Id], [Name], [Module], [Add], [Edit], [View], [Delete], [Print], [Execute], [Activate])
VALUES ('836A8C0F-A754-4101-A6D4-0B2B4E13A668', 'User', 'Security', 1, 1, 1, 1, 1, 0, 1)
END



--- Infrastructure table entries

IF NOT EXISTS (SELECT 1 FROM Infra_EmailTemplate WHERE Id = 'D9767197-DA3A-4B38-AA98-17E281658979')
BEGIN
INSERT INTO Infra_EmailTemplate (Id, CustomerId, [Name], [From], [To], [CC], [BCC], [Subject], Body, EmailTokenProviderName, IsActive) 
VALUES ('D9767197-DA3A-4B38-AA98-17E281658979', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'NewUser', 'abc@xyz.com', 'abc@xyz.com',null, null, 'New User %User.Username% has been created.', 'Dear %User.Username%, Your account has been created in the system. Your will shortly get the One Time password to Login into the system. Thank You for register with us.', 'UserEmailTokenProvider', 1)
END

IF NOT EXISTS (SELECT 1 FROM Infra_EmailTemplate WHERE Id = '3FDBE728-19A9-4D41-A3ED-B2DE6BCB3945')
BEGIN
INSERT INTO Infra_EmailTemplate (Id, CustomerId, [Name], [From], [To], [CC], [BCC], [Subject], Body, EmailTokenProviderName, IsActive) 
VALUES ('3FDBE728-19A9-4D41-A3ED-B2DE6BCB3945', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'ResetPassword', 'abc@xyz.com', 'abc@xyz.com',null, null, 'A new Password has been generated.', 'Dear %User.Username%, Your newly generated one time Password is: %User.Password%. You can now LogIn into the system using this password and after successful LogIn system will prompt you for Password Change. Thanks for Business with us.', 'UserEmailTokenProvider', 1)
END

IF NOT EXISTS (SELECT 1 FROM Infra_EmailTemplate WHERE Id = 'E92E650C-24BF-403D-83FC-519361F4D6D1')
BEGIN
INSERT INTO Infra_EmailTemplate (Id, CustomerId, [Name], [From], [To], [CC], [BCC], [Subject], Body, EmailTokenProviderName, IsActive) 
VALUES ('E92E650C-24BF-403D-83FC-519361F4D6D1', 'A0631E03-0CC1-4938-976D-89DAF94DC20C', 'ChangePassword', 'abc@xyz.com', 'abc@xyz.com',null, null, 'Your Password Has been changed.', 'Dear %User.Username%, Your Password has been changed successfully. Thanks for business with us.', 'UserEmailTokenProvider', 1)
END
--ROLLBACK TRAN
COMMIT TRAN