--SELECT NEWID()
BEGIN TRAN
--**************ADMIN DB SCRIPT**********************************

--**************HENKEL_SLMS RELATED SCRIPT***********************

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetail WHERE CustomerId = 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B')
BEGIN
INSERT INTO Admin_CustomerDetail (CustomerId, SubDomain, Suffix, Name, ConnectionString)
VALUES ('CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'localhost', 'HenkelSLMS', 'HenkelSLMS', 'Data Source=(local);Initial Catalog=Henkel_SLMS; Integrated Security=True')
END

--******Config entries****************************
IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '6E765EF0-988A-4E69-AE28-77F267B588E5')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('6E765EF0-988A-4E69-AE28-77F267B588E5', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'CacheTimeOut', '5')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '03BAD2B6-3BB9-4B66-B7B0-DBB226BFABD9')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('03BAD2B6-3BB9-4B66-B7B0-DBB226BFABD9', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'SmtpHost', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '6518998B-5469-49D2-9EFE-940312FF0C43')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('6518998B-5469-49D2-9EFE-940312FF0C43', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'SmtpPort', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'B25460E1-02FC-4099-A50D-530ED808A08B')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('B25460E1-02FC-4099-A50D-530ED808A08B', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'FromEmailId', 'abc@xyz.com')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = 'CC9A2B57-1B85-4993-AEBB-8A32CD5D1186')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('CC9A2B57-1B85-4993-AEBB-8A32CD5D1186', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'UploadPath', '')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '27471699-9D02-4573-9416-83FB71F93DFE')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('27471699-9D02-4573-9416-83FB71F93DFE', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'MaxFailureLoginAttemptAllowed', '3')
END

IF NOT EXISTS (SELECT 1 FROM Admin_CustomerDetailConfig WHERE Id = '07B33352-AD4C-4AF7-8E2C-082958812643')
BEGIN
INSERT INTO Admin_CustomerDetailConfig (Id, CustomerId, ConfigKey, ConfigValue)
VALUES ('07B33352-AD4C-4AF7-8E2C-082958812643', 'CA820AF9-58EA-46CC-A0A9-7D3606E0F71B', 'DefaultPassword', 'password@123')
END

--**************END OF HENKEL_SLMS RELATED SCRIPT****************

--*************END OF ADMIN DB SCRIPT****************************

--ROLLBACK TRAN
COMMIT TRAN