﻿using Henkel.Common.Core.API.DTO.SearchCriteria;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO.SearchCriteria
{
    public class UserSearchCriteria : ISearchCriteria
    {
        public Guid? UserId { get; set; }
        public string UserName { get; set; }
        public bool? IsActive { get; set; }
    }
}
