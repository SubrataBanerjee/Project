﻿using Henkel.Common.Core.API.DTO.SearchCriteria;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO.SearchCriteria
{
    public class ResourceSearchCriteria : ISearchCriteria
    {
        public virtual bool? IsActive { get; set; }

        public virtual Guid? ResourceId { get; set; }

        public virtual string ResourceCode { get; set; }
    }
}
