﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO
{
    public class UserDto
    {
        public Guid UserId { get; set; }

        public Guid CustomerId { get; set; }

        public string LoginId { get; set; }

        public string Password { get; set; }

        public bool IsActive { get; set; }

        public bool IsSuperAdmin { get; set; }

        public bool ChangePwdOnLogin { get; set; }

        public int FailureLoginAttempt { get; set; }

        public bool Locked { get; set; }

        public bool IsDeleted { get; set; }

        public string CreatedBy { get; set; }

        public DateTime? CreatedOn { get; set; }

        public string LastModifiedBy { get; set; }

        public DateTime? LastModifiedOn { get; set; }
    }
}
