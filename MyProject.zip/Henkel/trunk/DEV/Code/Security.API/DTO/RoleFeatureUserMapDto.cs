﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO
{
    public class RoleFeatureUserMapDto
    {
        public Guid Id { get; set; }

        public Guid CustomerId { get; set; }

        public Guid UserId { get; set; }

        public string UserName { get; set; }

        public Guid RoleId { get; set; }

        public string RoleName { get; set; }

        public Guid FeatureId { get; set; }

        public string FeatureName { get; set; }

        public bool Add { get; set; }

        public bool Edit { get; set; }

        public bool View { get; set; }

        public bool Delete { get; set; }

        public bool Print { get; set; }

        public bool Execute { get; set; }

        public bool Activate { get; set; }

        public bool IsActive { get; set; }
    }
}
