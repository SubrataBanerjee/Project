﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO
{
    public class RoleDto
    {
        public Guid Id { get; set; }

        public Guid CustomerId { get; set; }

        public string Name { get; set; }

        public bool IsActive { get; set; }

        public IList<RoleFeatureMapDto> RoleFeatureMapDtos { get; set; }
    }
}
