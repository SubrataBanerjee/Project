﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO
{
    public class UserToken
    {
        public bool SuccessLogin { get; set; }

        public string ErrorMessage { get; set; }

        public Guid UserId { get; set; }

        public Guid CustomerId { get; set; }

        public string UserName { get; set; }

        public bool IsActive { get; set; }

        public bool IsSuperAdmin { get; set; }

        public bool IsDeleted { get; set; }

        public IList<RoleFeatureUserMapDto> Roles { get; set; } 
    }
}
