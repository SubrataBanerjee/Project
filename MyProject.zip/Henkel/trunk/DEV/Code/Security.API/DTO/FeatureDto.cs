﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.DTO
{
    public class FeatureDto
    {
        public string Module { get; set; }

        public string Code { get; set; }

        public string Name { get; set; }

        public string FeatureGroup { get; set; }

        public bool Add { get; set; }

        public bool Edit { get; set; }

        public bool View { get; set; }

        public bool Delete { get; set; }

        public bool Print { get; set; }

        public bool Execute { get; set; }

        public bool CanActivate { get; set; }

        public string Sequence { get; set; }
    }
}
