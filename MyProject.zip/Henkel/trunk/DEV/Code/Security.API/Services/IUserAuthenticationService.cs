﻿using Henkel.Business.Security.API.DTO;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.Services
{
    public interface IUserAuthenticationService : IBusinessService
    {
        UserToken SignIn(string loginId, string password, bool rememberMe = false);

        void SignOut();

        void ResetPassword(Guid userId);

        void ChangePassword(Guid userId, string oldPassword, string newPassword, string confirmPassword);

        void ForgotPassword(string emailId);

        void LockUser(Guid userId);

        void UnlockUser(Guid userId);
    }
}
