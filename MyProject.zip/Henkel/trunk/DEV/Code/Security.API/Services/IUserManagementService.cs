﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.Services
{
    public interface IUserManagementService : IBusinessService
    {
        /// <summary>
        /// Method to get User By Id
        /// </summary>
        /// <param name="userId">userId</param>
        /// <returns>UserDto</returns>
        UserDto GetUserById(Guid userId);

        /// <summary>
        /// Method to Get User By LoginId
        /// </summary>
        /// <param name="loginId">loginId</param>
        /// <returns>UserDto</returns>
        UserDto GetUserByLoginId(string loginId);


        /// <summary>
        /// Method to Find paginated and sorted Users by Search Criteria and PageInfo 
        /// </summary>
        /// <param name="searchCriteria">searchCriteria</param>
        /// <param name="pageInfo">pageInfo</param>
        /// <returns>Page<UserDto></returns>
        Page<UserDto> FindUserByCriteria(UserSearchCriteria searchCriteria, PageInfo pageInfo);

        /// <summary>
        /// Method to Find Users by Search Criteria
        /// </summary>
        /// <param name="searchCriteria">searchCriteria</param>
        /// <returns>IList<UserDto></returns>
        IList<UserDto> FindUserByCriteria(UserSearchCriteria searchCriteria);

        /// <summary>
        /// Method to Get All paginated and sorted Users by pageinfo
        /// </summary>
        /// <param name="pageInfo">pageInfo</param>
        /// <returns>Page<UserDto></returns>
        Page<UserDto> GetAllUsers(PageInfo pageInfo);


        /// <summary>
        /// Method to Get All Users
        /// </summary>
        /// <returns></returns>
        IList<UserDto> GetAllUsers();

        /// <summary>
        /// Method to Add a new User
        /// </summary>
        /// <param name="userDto">userDto</param>
        /// <returns>Id of that newly created User</returns>
        Guid AddUser(UserDto userDto);

        /// <summary>
        /// Method to Update User
        /// </summary>
        /// <param name="userDto">userDto</param>
        void UpdateUser(UserDto userDto);

        /// <summary>
        /// Method to Delete an existing User
        /// </summary>
        /// <param name="userId">UserId to Delete</param>
        void DeleteUser(Guid userId);

        /// <summary>
        /// Method to Enable an user
        /// </summary>
        /// <param name="userId">userId</param>
        void MarkUserAsEnabled(Guid userId);

        /// <summary>
        /// Method to Disable an User
        /// </summary>
        /// <param name="userId">userId</param>
        void MarkUserAsDisabled(Guid userId);
    }
}
