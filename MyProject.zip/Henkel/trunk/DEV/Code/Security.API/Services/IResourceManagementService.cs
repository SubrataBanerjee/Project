﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.API.Services
{
    public interface IResourceManagementService : IBusinessService
    {
        /// <summary>
        /// Method to get Resource By Id
        /// </summary>
        /// <param name="resourceId">resourceId</param>
        /// <returns>ResourceDto</returns>
        ResourceDto GetResourceById(Guid resourceId);

        /// <summary>
        /// Method to Find paginated and sorted Resources by Search Criteria and PageInfo 
        /// </summary>
        /// <param name="searchCriteria">searchCriteria</param>
        /// <param name="pageInfo">pageInfo</param>
        /// <returns>Page<ResourceDto></returns>
        Page<ResourceDto> FindResourceByCriteria(ResourceSearchCriteria searchCriteria, PageInfo pageInfo);

        /// <summary>
        /// Method to Find Resources by Search Criteria
        /// </summary>
        /// <param name="searchCriteria">searchCriteria</param>
        /// <returns>IList<ResourceDto></returns>
        IList<ResourceDto> FindResourceByCriteria(ResourceSearchCriteria searchCriteria);

        /// <summary>
        /// Method to Get All paginated and sorted Resources by pageinfo
        /// </summary>
        /// <param name="pageInfo">pageInfo</param>
        /// <returns>Page<ResourceDto></returns>
        Page<ResourceDto> GetAllResources(PageInfo pageInfo);


        /// <summary>
        /// Method to Get All Resources
        /// </summary>
        /// <returns>IList<ResourceDto></returns>
        IList<ResourceDto> GetAllResources();

        /// <summary>
        /// Method to Add a new Resource
        /// </summary>
        /// <param name="ResourceDto">ResourceDto</param>
        /// <returns>Id of that newly created ResourceDto</returns>
        Guid AddResource(ResourceDto resourceDto);

        /// <summary>
        /// Method to Update Resource
        /// </summary>
        /// <param name="resourceDto">resourceDto</param>
        void UpdateResource(ResourceDto resourceDto);

        /// <summary>
        /// Method to Update Resource EmailId
        /// </summary>
        /// <param name="resourceId">resourceId</param>
        /// /// <param name="email">email to Update</param>
        void UpdateResourceEmailId(Guid resourceId, string email);

        /// <summary>
        /// Method to Delete an existing Resource
        /// </summary>
        /// <param name="resourceId">resourceId to Delete</param>
        void DeleteResource(Guid resourceId);

        /// <summary>
        /// Method to Enable an Resource
        /// </summary>
        /// <param name="resourceId">resourceId</param>
        void MarkResourceAsEnabled(Guid resourceId);

        /// <summary>
        /// Method to Disable an Resource
        /// </summary>
        /// <param name="resourceId">resourceId</param>
        void MarkResourceAsDisabled(Guid resourceId);


        /// <summary>
        /// Method to create Login (User) for the Resource
        /// </summary>
        /// <param name="resourceId">resourceId</param>
        /// <param name="loginId">loginId</param>
        void CreateLogin(Guid resourceId, string loginId);

        /// <summary>
        /// Method to Delete Login (User) for the Resource
        /// </summary>
        /// <param name="resourceId">resourceId</param>
        void DeleteLogin(Guid resourceId);


    }
}
