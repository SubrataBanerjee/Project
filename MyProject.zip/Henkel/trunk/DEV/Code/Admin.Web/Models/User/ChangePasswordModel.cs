﻿using Henkel.Admin.Web.Framework.Model;
using Henkel.Admin.Web.Validators.User;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Mvc;
using FluentValidation.Attributes;
using Henkel.Common.Resources;

namespace Henkel.Admin.Web.Models.User
{
    [Validator(typeof(ChangePasswordValidator))]
    public partial class ChangePasswordModel : BaseModel
    {
        [AllowHtml]
        [DataType(DataType.Password)]
        [Display(ResourceType = typeof(GlobalResources), Name = "ChangePassword_Fields_OldPassword")]
        public string OldPassword { get; set; }

        [AllowHtml]
        [DataType(DataType.Password)]
        [Display(ResourceType = typeof(GlobalResources), Name = "ChangePassword_Fields_NewPassword")]
        public string NewPassword { get; set; }

        [AllowHtml]
        [DataType(DataType.Password)]
        [Display(ResourceType = typeof(GlobalResources), Name = "ChangePassword_Fields_ConfirmNewPassword")]
        public string ConfirmNewPassword { get; set; }
    }
}
