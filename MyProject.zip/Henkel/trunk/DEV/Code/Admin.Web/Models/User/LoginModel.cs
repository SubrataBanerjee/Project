﻿using Henkel.Admin.Web.Framework.Model;
using Henkel.Admin.Web.Validators.User;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using FluentValidation.Attributes;
using Henkel.Common.Resources;

namespace Henkel.Admin.Web.Models.User
{
    [Validator(typeof(LoginValidator))]
    public partial class LoginModel : BaseModel
    {
        [Display(ResourceType = typeof(GlobalResources), Name = "Login_Fields_UserName")]
        [AllowHtml]
        public string UserName { get; set; }

        [Display(ResourceType = typeof(GlobalResources), Name = "Login_Fields_Password")]
        [DataType(DataType.Password)]
        [AllowHtml]
        public string Password { get; set; }

        [Display(ResourceType = typeof(GlobalResources), Name = "Login_Fields_RememberMe")]
        public bool RememberMe { get; set; }
    }
}