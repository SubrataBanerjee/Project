﻿using FluentValidation;
using Henkel.Admin.Web.Models.User;
using Henkel.Common.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Admin.Web.Validators.User
{
    public class ChangePasswordValidator : AbstractValidator<ChangePasswordModel>
    {
        private const int passwordMinLength = 10;//TODO configure
        
        public ChangePasswordValidator()
        {
            RuleFor(x => x.OldPassword).NotEmpty().WithMessage(GlobalResources.ChangePassword_Fields_OldPassword_Required);
            RuleFor(x => x.NewPassword).NotEmpty().WithMessage(GlobalResources.ChangePassword_Fields_NewPassword_Required);
            RuleFor(x => x.NewPassword).Length(passwordMinLength, 999).WithMessage(string.Format(GlobalResources.ChangePassword_Fields_NewPassword_LengthValidation, passwordMinLength));
            RuleFor(x => x.ConfirmNewPassword).NotEmpty().WithMessage(GlobalResources.ChangePassword_Fields_ConfirmNewPassword_Required);
            RuleFor(x => x.ConfirmNewPassword).Equal(x => x.NewPassword).WithMessage(GlobalResources.ChangePassword_Fields_NewPassword_EnteredPasswordsDoNotMatch);
        }
    }
}
