﻿using FluentValidation;
using Henkel.Admin.Web.Models.User;
using Henkel.Common.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Admin.Web.Validators.User
{
    public class LoginValidator : AbstractValidator<LoginModel>
    {
        public LoginValidator()
        {
            RuleFor(x => x.UserName).NotEmpty().WithMessage(GlobalResources.Login_Fields_UserName_Required);
            RuleFor(x => x.Password).NotEmpty().WithMessage(GlobalResources.Login_Fields_Password_Required);
        }
    }
}
