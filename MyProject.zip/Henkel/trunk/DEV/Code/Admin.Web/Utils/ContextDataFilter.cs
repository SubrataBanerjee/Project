﻿using Henkel.Common.Core.API.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;

namespace Henkel.Admin.Web.Utils
{
    public class ContextDataFilter : System.Web.Http.Filters.ActionFilterAttribute
    {
        public override void OnActionExecuting(HttpActionContext actionContext)
        {
            // pre-processing
            if (HttpContext.Current.Session != null)
            {
                SetContextData();
            }
        }

        private void SetContextData()
        {
            if (HttpContextFactory.Current.Session == null)
                return;

            var currentContext = AppContext.Current;
            ThreadUtils.SetThreadData(currentContext.CustomerId, currentContext.CustomerName, currentContext.UserId, currentContext.UserName);
        }
    }
}