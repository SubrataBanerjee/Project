﻿using Henkel.Common.Core.API.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;

namespace Henkel.Admin.Web.Utils
{
    public class AppContext
    {
        private const string CustomerIdKey = "CustomerId";
        private const string UserRightsKey = "UserRights";
        private const string UserIdKey = "UserId";
        private const string UserNameKey = "UserName";
        private const string CustomerNameKey = "CustomerName";

        private static readonly AppContext _instance = new AppContext();

        public static AppContext Current
        {
            get { return _instance; }
        }

        public Guid CustomerId
        {
            get { return (Guid)(CurrentSession[CustomerIdKey] ?? Guid.Empty); }
            set { CurrentSession[CustomerIdKey] = value; }
        }

        //public UserRights UserRights
        //{
        //    get { return (UserRights)CurrentSession[UserRightsKey]; }
        //    set { CurrentSession[UserRightsKey] = value; }
        //}

        public Guid UserId
        {
            get { return (Guid)(CurrentSession[UserIdKey] ?? Guid.Empty); }
            set { CurrentSession[UserIdKey] = value; }
        }

        public string UserName
        {
            get { return (string)CurrentSession[UserNameKey]; }
            set { CurrentSession[UserNameKey] = value; }
        }

        public string CustomerName
        {
            get { return (string)CurrentSession[CustomerNameKey]; }
            set { CurrentSession[CustomerNameKey] = value; }
        }

        private static HttpSessionStateBase CurrentSession
        {
            get { return HttpContextFactory.Current.Session; }
        }

        public static void SetThreadData()
        {
            var currentContext = Current;
            ThreadUtils.SetThreadData(currentContext.CustomerId, currentContext.CustomerName, currentContext.UserId, currentContext.UserName);
        }
    }
}