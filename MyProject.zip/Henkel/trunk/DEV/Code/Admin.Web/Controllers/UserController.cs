﻿using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Admin.Web.Framework.Controllers;
using Henkel.Admin.Web.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Henkel.Admin.Web.Utils;

namespace Henkel.Admin.Web.Controllers
{
    public class UserController : BaseController
    {
        #region Fields

        private readonly IUserAuthenticationService _userAuthenticationService;
        private readonly IUserManagementService _userManagementService;

        #endregion

        #region Ctor

        public UserController()
        {
            this._userAuthenticationService = ObjectLocator.GetService<IUserAuthenticationService>();
            this._userManagementService = ObjectLocator.GetService<IUserManagementService>();
        }

        #endregion

        #region Login / logout

        public ActionResult Login()
        {
            var model = new LoginModel();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginModel model, string returnUrl)
        {
            if (ModelState.IsValid)
            {
                if (model.UserName != null)
                {
                    model.UserName = model.UserName.Trim();
                }
                UserToken loginResult = _userAuthenticationService.SignIn(model.UserName, model.Password, model.RememberMe);
                if (loginResult.SuccessLogin)
                {
                    SetAppContextData(loginResult);
                    

                    //user activity log
                    //TODO

                    if (!String.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                        return Redirect(returnUrl);
                    else
                        return RedirectToRoute("Home");
                }
                else
                {
                    ModelState.AddModelError("", GetResource(loginResult.ErrorMessage));
                }
            }
            return View(model);
        }

        private void SetAppContextData(UserToken userToken)
        {
            AppContext.Current.UserId = userToken.UserId;
            AppContext.Current.UserName = userToken.UserName;
            AppContext.Current.CustomerId = userToken.CustomerId;
            //AppContext.Current.CustomerName = userToken.CustomerId; Todo
            //Todo Add Role Details
            AppContext.SetThreadData();
        }

        public ActionResult Logout()
        {
            //activity log
            _userAuthenticationService.SignOut();
            return RedirectToRoute("Home");
        }

        #endregion

        #region My account

        #region Change password

        [Authorize]
        public ActionResult ChangePassword()
        {
            var model = new ChangePasswordModel();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {
                _userAuthenticationService.ChangePassword(AppContext.Current.UserId, model.NewPassword, model.OldPassword, model.ConfirmNewPassword);
                SuccessNotification(GetResource("ChangePassword_Success"));
            }

            //If we got this far, something failed, redisplay form
            return View(model);
        }

        #endregion

        #endregion
    }
}
