﻿using Henkel.Business.Infrastructure.Resources;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Resources;
using Henkel.Common.SupportForTests.Model;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.SupportForTests.Services.Impl
{
    public class DummyCustomerAdminService : ICustomerAdminService
    {
        #region Implementation of ICustomerAdminService

        public CustomerAdminDetail GetCustomerAdminDetail()
        {
            return GetCustomerAdminDetailObject();
        }

        public IList<CustomerAdminDetail> GetAllCustomerAdminDetails()
        {
            var obj = GetCustomerAdminDetailObject();
            return new List<CustomerAdminDetail>() { obj };
        }

        #endregion

        #region Helper Methods

        private CustomerAdminDetail _customerAdminDetail;

        private CustomerAdminDetail GetCustomerAdminDetailObject()
        {
            if(_customerAdminDetail == null)
            {
                var index = ConfigurationManager.ConnectionStrings.Count - 1;
                var conStr = ConfigurationManager.ConnectionStrings[index];

                var detail = new CustomerAdminDetail
                {
                    Name = "test",
                    SubDomain = "localhost",
                    Suffix = "Henkel",
                    ConnectionString = conStr.ConnectionString,
                    CustomerId = BaseTest.CustomerId
                };

                double cacheTimeOut = 5;
                var adminDbCacheTimeOut = ConfigurationManager.AppSettings["AdminDBCacheTimeOut"];
                if (!string.IsNullOrWhiteSpace(adminDbCacheTimeOut))
                    cacheTimeOut = Convert.ToDouble(adminDbCacheTimeOut);

                detail.CustomerAdminConfigs = new Dictionary<string, string>();
                detail.CustomerAdminConfigs.Add(CoreAdminConfigKey.CacheTimeOut, adminDbCacheTimeOut);
                detail.CustomerAdminConfigs.Add(CoreAdminConfigKey.UploadPath, "");
                detail.CustomerAdminConfigs.Add(CoreAdminConfigKey.StorageContainerDirectory, "");
                detail.CustomerAdminConfigs.Add(CoreAdminConfigKey.StorageContainerDirectoryCredential, "");
                detail.CustomerAdminConfigs.Add(SecurityAdminConfigKey.DefaultUserPassword, "password@123");
                detail.CustomerAdminConfigs.Add(SecurityAdminConfigKey.FailureLoginAttemptLimit, "3");
                detail.CustomerAdminConfigs.Add(SecurityAdminConfigKey.PasswordHistoryLimit, "3");
                detail.CustomerAdminConfigs.Add(SecurityAdminConfigKey.PasswordPolicy, "");
                detail.CustomerAdminConfigs.Add(InfrastructureAdminConfigKey.SMTPEmailId, "");
                detail.CustomerAdminConfigs.Add(InfrastructureAdminConfigKey.SMTPPassword, "");
                detail.CustomerAdminConfigs.Add(InfrastructureAdminConfigKey.SmtpHost, "");
                detail.CustomerAdminConfigs.Add(InfrastructureAdminConfigKey.SmtpPort, "");

                _customerAdminDetail = detail;
            }

            return _customerAdminDetail;
        }

        #endregion

    }
}
