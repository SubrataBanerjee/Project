﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.SupportForTests.Repository.EntityFramework
{
    public abstract class RequireEFDatabaseSupport : RequireDatabaseSupport
    {
        public RequireEFDatabaseSupport()
            : base(ObjectResolverType.Composite)
        {
        }

        protected override string[] CustomUnityConfigs
        {
            get { return null; }
        }
    }
}
