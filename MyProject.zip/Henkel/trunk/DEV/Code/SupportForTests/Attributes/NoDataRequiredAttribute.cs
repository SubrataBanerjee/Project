﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.SupportForTests.Attributes
{
    /// <summary>
    /// Attribute to indicate if the data cleanup and insert is required by test method
    /// </summary>
    public sealed class NoDataRequiredAttribute : Attribute { }
}
