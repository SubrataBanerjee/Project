﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Locator;
using Henkel.Common.SupportForTests.Services.Impl;
using Rhino.Mocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.SupportForTests.Model
{
    public abstract class BaseTest
    {
        public static readonly Guid CustomerId = new Guid("85276F22-8FF4-4EB7-A6AA-69BA26D22012");

        public BaseTest(ObjectResolverType objectResolverType)
        {
            ObjectLocator.SetObjectResolver(objectResolverType);
        }

        protected virtual void Initialize()
        {
            ObjectLocator.ClearAllObjects();
            var dummayCustomerAdminService = new DummyCustomerAdminService();
            ObjectLocator.RegisterObject<ICustomerAdminService>(dummayCustomerAdminService);
            var userContextService = MockRepository.GenerateMock<IUserContextService>();
            userContextService.Expect(x => x.CustomerId).Repeat.Any().Return(CustomerId);
            userContextService.Expect(x => x.CurrentUserName).Repeat.Any().Return("UnitTest_User");
            ObjectLocator.RegisterObject<IUserContextService>(userContextService);

            DatabaseSupportInitialize();
        }

        protected virtual void DatabaseSupportInitialize()
        {

        }
    }
}
