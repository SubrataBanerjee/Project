﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.API.Services
{
    public partial interface IEmailingService : IBusinessService
    {
        #region Methods

        void SendEmail(string templateName, IEntity entity, IDictionary<string, string> attachements = null);

        #endregion
    }
}
