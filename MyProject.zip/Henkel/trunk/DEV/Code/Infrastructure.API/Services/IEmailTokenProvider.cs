﻿using Henkel.Business.Infrastructure.API.DTO;
using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.API.Services
{
    public interface IEmailTokenProvider
    {
        void AddTokens(IList<Token> tokens, Guid entityId);

        void AddTokens(IList<Token> tokens, IEntity entity);
    }
}
