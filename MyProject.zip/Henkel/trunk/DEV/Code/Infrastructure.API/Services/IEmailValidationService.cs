﻿using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.API.Services
{
    public interface IEmailValidationService : IBusinessService
    {
        /// <summary>
        /// Method to validate Email Id format
        /// </summary>
        /// <param name="email">email to Validate</param>
        bool IsValid(string email);
    }
}
