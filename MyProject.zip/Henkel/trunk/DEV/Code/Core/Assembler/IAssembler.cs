﻿using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Assembler
{
    public interface IAssembler<TEntity, TDto> where TEntity : class, IEntity
    {
        TEntity GetEntityFromDto(TDto dto);

        TDto GetDtoFromEntity(TEntity entity);

        void UpdateEntityFromDto(TEntity entity, TDto dto);
    }
}
