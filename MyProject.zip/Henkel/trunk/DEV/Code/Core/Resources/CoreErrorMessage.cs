﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Resources
{
    public class CoreErrorMessage
    {
        public const string ErrorProcessingRequest = "Key_ErrorProcessingRequest."; // "Internal Error occurred to Process Request."
        public const string ExceptionOccurred = "Exception occourred !!!";
    }
}
