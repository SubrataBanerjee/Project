﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Model
{
    public abstract class CustomerEntity : Entity
    {
        public virtual Guid CustomerId { get; set; }
    }
}
