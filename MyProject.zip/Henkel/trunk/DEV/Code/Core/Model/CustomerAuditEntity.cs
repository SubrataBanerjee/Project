﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Locator;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Model
{
    public abstract class CustomerAuditEntity : CustomerEntity, IAuditEntity
    {
        #region Implementation of IAuditEntity

        #region Fields

        public virtual string CreatedBy { get; set; }

        public virtual DateTime? CreatedOn { get; set; }

        public virtual string LastModifiedBy { get; set; }

        public virtual DateTime? LastModifiedOn { get; set; }

        #endregion

        #region Constructor

        public CustomerAuditEntity()
        {
            CreatedOn = DateTime.UtcNow;
            LastModifiedOn = DateTime.UtcNow;
        }

        #endregion

        #region Methods

        public virtual void SetCreationInfo()
        {
            CreatedOn = DateTime.UtcNow;
            CreatedBy = ObjectLocator.GetService<IUserContextService>().CurrentUserName;
            SetModificationInfo();
        }

        public virtual void SetModificationInfo()
        {
            LastModifiedOn = DateTime.UtcNow;
            LastModifiedBy = ObjectLocator.GetService<IUserContextService>().CurrentUserName;
        }

        #endregion

        #endregion
    }
}
