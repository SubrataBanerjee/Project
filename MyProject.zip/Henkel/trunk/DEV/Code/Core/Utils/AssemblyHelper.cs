﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Utils
{
    public class AssemblyHelper
    {
        public static IEnumerable<Assembly> GetAllAssemblies()
        {
            var callingAssembly = Assembly.GetCallingAssembly();
            return GetAllAssemblies(callingAssembly);
        }

        public static IEnumerable<Assembly> GetAllAssemblies(Assembly callingAssembly)
        {
            var assemblyNames = callingAssembly.GetReferencedAssemblies().ToList();

            var assemblies = assemblyNames.Where(a => a.FullName.StartsWith("Henkel")).Select(Assembly.Load).Where(
                a => !a.Location.EndsWith("Tests.dll", StringComparison.OrdinalIgnoreCase)).ToList();

            var allAssemblies = new HashSet<Assembly>();
            foreach (var assembly in assemblies)
            {
                allAssemblies.Add(assembly);
            }

            var currDomainAssemblies = AppDomain.CurrentDomain.GetAssemblies().Where(a => a.FullName.StartsWith("Henkel")).Where(
                a => !a.Location.EndsWith("Tests.dll", StringComparison.OrdinalIgnoreCase)).ToList();

            foreach (var assembly in currDomainAssemblies)
            {
                allAssemblies.Add(assembly);
            }
            string path = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            if (Directory.Exists(path) && path.IndexOf("asp.net", StringComparison.OrdinalIgnoreCase) < 0)
                foreach (string dll in Directory.GetFiles(path, "Henkel*.dll"))
                {
                    if (dll.IndexOf("Tests.dll", StringComparison.OrdinalIgnoreCase) < 0)
                        allAssemblies.Add(Assembly.LoadFile(dll));
                }

            return allAssemblies;
        }
    }
}
