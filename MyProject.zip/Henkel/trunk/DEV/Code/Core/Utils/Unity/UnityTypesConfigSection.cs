﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Utils.Unity
{
    /// <summary>
    /// The Class that will have the XML config file data loaded into it via the configuration Manager.
    /// </summary>
    public class UnityTypesConfigSection : ConfigurationSection
    {
        /// <summary>
        /// The value of the property here "Folders" needs to match that of the config file section
        /// </summary>
        [ConfigurationProperty("Types")]
        public UnityTypesCollection Types
        {
            get { return ((UnityTypesCollection)(base["Types"])); }
        }

    }

    /// <summary>
    /// The collection class that will store the list of each element/item that
    ///        is returned back from the configuration manager.
    /// </summary>
    [ConfigurationCollection(typeof(UnityTypeElement), AddItemName = "Type")]
    public class UnityTypesCollection : ConfigurationElementCollection
    {
        protected override ConfigurationElement CreateNewElement()
        {
            return new UnityTypeElement();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((UnityTypeElement)(element)).TypeName;
        }
        public UnityTypeElement this[int idx]
        {
            get
            {
                return (UnityTypeElement)BaseGet(idx);
            }
        }
    }

    /// <summary>
    /// The class that holds onto each element returned by the configuration manager.
    /// </summary>
    public class UnityTypeElement : ConfigurationElement
    {
        [ConfigurationProperty("typeName", DefaultValue = "", IsKey = true, IsRequired = true)]
        public string TypeName
        {
            get
            {
                return ((string)(base["typeName"]));
            }
            set
            {
                base["typeName"] = value;
            }
        }

    }
}
