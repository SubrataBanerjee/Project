﻿using log4net;
using Microsoft.Practices.ObjectBuilder2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Logging.Unity
{
    public class LogBuildPlanPolicy : IBuildPlanPolicy
    {
        public LogBuildPlanPolicy(Type logType)
        {
            this.LogType = logType;
        }

        public Type LogType { get; private set; }

        public void BuildUp(IBuilderContext context)
        {
            if (context.Existing == null)
            {
                ILog log = LogManager.GetLogger(this.LogType);
                context.Existing = log;
            }
        }
    }
}
