﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.ObjectBuilder;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Logging.Unity
{
    public class LogUnityContainerExtension : UnityContainerExtension
    {
        private static int _log4netInitialized;
        private static void InitLog4NetForErrorAndUserLogs()
        {
            Interlocked.CompareExchange(ref _log4netInitialized, 1, 0);
            log4net.GlobalContext.Properties["ErrorTraceLogName"] = "ErrorTraceLog.log";
        }

        private static void InitLog4NetForEntityFrameworkLogs()
        {
            Interlocked.CompareExchange(ref _log4netInitialized, 1, 0);
            log4net.GlobalContext.Properties["EntityFrameworkLogName"] = "EntityFrameworkTraceLog.log";
        }


        protected override void Initialize()
        {
            this.Context.Strategies.AddNew<LogBuilderStrategy>(UnityBuildStage.PreCreation);
            if (_log4netInitialized == 0)
            {
                InitLog4NetForErrorAndUserLogs();
                InitLog4NetForEntityFrameworkLogs();
            }
            log4net.Config.XmlConfigurator.Configure();
        }
    }
}
