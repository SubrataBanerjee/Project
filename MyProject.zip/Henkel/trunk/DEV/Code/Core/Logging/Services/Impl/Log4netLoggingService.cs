﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Logging.Services;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Services;
using log4net;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Logging.Services.Impl
{
    public class Log4NetLoggingService : BaseService, ILoggingService
    {
        private static readonly ILog _logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public Log4NetLoggingService()
        {
        }

        #region ILoggingService Members

        /// <summary>
        /// Logs messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="severity">The severity.</param>
        /// <param name="args">The args.</param>
        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private static void Log(string module, string message, TraceEventType severity, params object[] args)
        {
            if (module == "UserActivityLog")
                log4net.ThreadContext.Properties["Version"] = "2";
            else
                log4net.ThreadContext.Properties["Version"] = "1";
            string moduleSeverity = ConfigurationManager.AppSettings[module] ?? "";
            var userContextService = ObjectLocator.GetService<IUserContextService>();
            var currentUserName = userContextService == null ? "Unknown" : userContextService.CurrentUserName;

            var stackTrace = new StackTrace();
            var callingMethodName = stackTrace.GetFrame(3) != null ? stackTrace.GetFrame(3).GetMethod().Name : stackTrace.GetFrame(2).GetMethod().Name;
            if ((string.IsNullOrWhiteSpace(moduleSeverity) || moduleSeverity.Equals(severity.ToString().ToLower(), StringComparison.OrdinalIgnoreCase)))
            {
                var msg = args == null ? message : string.Format(message, args);
                msg = module == "UserActivityLog" ? string.Format("{0}|{1}", currentUserName, msg) : string.Format("{0}|{1}|{2}|{3}", currentUserName, module, callingMethodName, msg);
                switch (severity)
                {
                    case TraceEventType.Verbose:
                        _logger.Debug(msg);
                        break;
                    case TraceEventType.Critical:
                    case TraceEventType.Error:
                        _logger.Error(msg);
                        break;
                    case TraceEventType.Warning:
                        _logger.Warn(msg);
                        break;
                    case TraceEventType.Information:
                        _logger.Info(msg);
                        break;
                }
            }
            log4net.ThreadContext.Properties["Version"] = "0";
        }

        /// <summary>
        /// Logs Critical messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        public void Critical(string module, string message, params object[] args)
        {
            Log(module, message, TraceEventType.Critical, args);
        }

        /// <summary>
        /// Logs Errors for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        public void Error(string module, string message, params object[] args)
        {
            Log(module, message, TraceEventType.Error, args);
        }

        /// <summary>
        /// Logs Warnings for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        public void Warning(string module, string message, params object[] args)
        {
            Log(module, message, TraceEventType.Warning, args);
        }

        /// <summary>
        /// Logs Informational messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        public void Info(string module, string message, params object[] args)
        {
            Log(module, message, TraceEventType.Information, args);
        }

        /// <summary>
        /// Logs Verbose messages for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="args">The args.</param>
        public void Verbose(string module, string message, params object[] args)
        {
            Log(module, message, TraceEventType.Verbose, args);
        }

        /// <summary>
        /// Logs Exceptions for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="message">The message.</param>
        /// <param name="stackTrace">The stack trace.</param>
        /// <param name="args">The args.</param>
        public void Exception(string module, string message, string stackTrace, params object[] args)
        {
            var msg = string.Format("Error Message : {0} \r\n StackTrace : {1}", message, stackTrace);

            Log(module, msg, TraceEventType.Error, args);
        }

        /// <summary>
        /// Logs Exceptions for the specified module.
        /// </summary>
        /// <param name="module">The module.</param>
        /// <param name="operationStatus">The operation status.</param>
        public void Exception(string module, OperationStatus operationStatus)
        {
            var msg = new StringBuilder();
            msg.AppendFormat("Error Message : {0}  \r\n Exception Message : {1} \r\n StackTrace : {2}", operationStatus.Message, operationStatus.ExceptionMessage, operationStatus.ExceptionStackTrace);
            if (operationStatus.InnerOperationStatus != null)
            {
                msg.AppendFormat(InnerException(1, operationStatus.InnerOperationStatus));
            }

            Log(module, msg.ToString(), TraceEventType.Error, null);
        }

        private string InnerException(int level, OperationStatus operationStatus)
        {
            var msg = new StringBuilder();
            msg.AppendFormat("\r\n Level{0} Inner Exception Message : {1} \r\n StackTrace: {2}", level, operationStatus.ExceptionMessage, operationStatus.ExceptionStackTrace);

            if (operationStatus.InnerOperationStatus != null)
                msg.AppendFormat(InnerException(level + 1, operationStatus.InnerOperationStatus));

            return msg.ToString();
        }

        #endregion
    }
}
