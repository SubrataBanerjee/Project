﻿using Microsoft.Practices.Unity;
using Henkel.Common.Core.API.Integration.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Locator.Services.Impl
{
    public class InMemoryObjectResolver : IObjectResolver
    {
        private readonly IDictionary<Type, IDictionary<String, object>> _registeredObjects = new Dictionary<Type, IDictionary<string, object>>();

        public InMemoryObjectResolver()
        {
        }

        #region Implementation of IObjectResolver

        #region Service Registration

        public virtual void RegisterObject<T>(T service, string name)
        {
            var registeredObjectsForType = _registeredObjects.ContainsKey(typeof(T))
                                               ? _registeredObjects[typeof(T)]
                                               : new Dictionary<string, object>();
            if (name == null)
                registeredObjectsForType["default"] = service;
            else
                registeredObjectsForType[name] = service;

            if (!_registeredObjects.ContainsKey(typeof(T)))
                _registeredObjects[typeof(T)] = registeredObjectsForType;
        }

        public virtual void RegisterUnityTypes<T>(IEnumerable<T> unityServices) where T : class, IRegisterWithUnityService
        {
            throw new NotImplementedException("Unity Registration not supported from This In Memory implementation");
        }


        public virtual void ClearAllObjects()
        {
            _registeredObjects.Clear();
        }

        public void ClearObject<T>()
        {
            if (_registeredObjects.ContainsKey(typeof(T)))
                _registeredObjects.Remove(typeof(T));
        }

        public virtual IUnityContainer UnityContainer { get { return null; } }
        

        #endregion

        #region Get Methods

        public virtual T GetService<T>() where T : class, IBusinessService
        {
            if (_registeredObjects.ContainsKey(typeof(T)))
                return _registeredObjects[typeof(T)]["default"] as T;

            return null;
        }

        public virtual T GetService<T>(string name) where T : class, IBusinessService
        {
            if (_registeredObjects.ContainsKey(typeof(T)))
                return _registeredObjects[typeof(T)][name] as T;

            return null;
        }

        public virtual T GetType<T>() where T : class
        {
            if (_registeredObjects.ContainsKey(typeof(T)))
                return _registeredObjects[typeof(T)]["default"] as T;

            return null;
        }

        public virtual T GetType<T>(string name) where T : class
        {
            if (_registeredObjects.ContainsKey(typeof(T)))
                return _registeredObjects[typeof(T)][name] as T;

            return null;
        }

        /// <summary>
        /// Gets all the objects that implements the specified Type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public virtual IEnumerable<T> GetAll<T>()
        {
            if (_registeredObjects.ContainsKey(typeof(T)))
                return _registeredObjects[typeof(T)].Values.Select(x => (T)x);

            return new List<T>();
        }

        #endregion

        #endregion
    }
}
