﻿using Microsoft.Practices.Unity;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Locator.Services.Impl
{
    public class CompositeObjectResolver : InMemoryObjectResolver
    {
        readonly IObjectResolver _unityResolver = new UnityObjectResolver();

        public CompositeObjectResolver()
        {
        }

        #region Implementation of IObjectResolver

        #region Service Registration

        public override void RegisterUnityTypes<T>(IEnumerable<T> unityServices)
        {
            _unityResolver.RegisterUnityTypes<T>(unityServices);
        }

        public override IUnityContainer UnityContainer 
        {
            get { return _unityResolver.UnityContainer; }
        }

        #endregion

        #region Get Methods

        public override T GetService<T>()
        {
            var service = base.GetService<T>();
            if (service == null)
                return _unityResolver.GetService<T>();
            return service;
        }

        public override T GetService<T>(string name)
        {
            var service = base.GetService<T>(name);
            if (service == null)
                service = _unityResolver.GetService<T>(name);

            return service;
        }

        public override T GetType<T>()
        {
            var obj = base.GetType<T>();
            if (obj == null)
                obj = _unityResolver.GetType<T>();
            return obj;
        }

        public override T GetType<T>(string name)
        {
            var obj = base.GetType<T>(name);
            if (obj == null)
                obj = _unityResolver.GetType<T>(name);

            return obj;
        }

        public override IEnumerable<T> GetAll<T>()
        {
            var enumerable = base.GetAll<T>();
            var all = enumerable as List<T> ?? enumerable.ToList();
            return !all.Any() ? _unityResolver.GetAll<T>() : all;
        }

        #endregion

        #endregion
    }
}
