﻿using Microsoft.Practices.Unity;
using Henkel.Common.Core.API.Integration.Services;
using Henkel.Common.Core.API.Integration.Services.Impl;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Utils.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Locator.Services.Impl
{
    public class UnityObjectResolver : IObjectResolver
    {
        private Dictionary<string, List<ContainerRegistration>> _registeredNamedTypes;

        public UnityObjectResolver()
        {
            RegisteredNamedTypes();
        }

        #region Implementation of IObjectResolver

        #region Service Registration Methods

        public virtual void RegisterObject<T>(T service, string name)
        {
            throw new NotImplementedException("All objects must be registered with Unity");
        }

        public void RegisterUnityTypes<T>(IEnumerable<T> unityServices) where T : class, IRegisterWithUnityService
        {
            if (unityServices != null && unityServices.Any())
            {
                foreach (var unityService in unityServices)
                    unityService.RegisterTypes(UnityContainerFactory.Instance);

                RegisteredNamedTypes();
            }
        }

        public void ClearObject<T>()
        {
            throw new NotImplementedException("Objects registered with Unity cannot be cleared.");
        }

        public void ClearAllObjects()
        {
            throw new NotImplementedException("Objects registered with Unity cannot be cleared.");
        }

        public virtual IUnityContainer UnityContainer
        {
            get
            {
                return UnityContainerFactory.Instance;
            }
        }

        #endregion

        #region Get Methods

        public virtual T GetService<T>() where T : class, IBusinessService
        {
            var result = GetService<T>("");
            if (result != null)
                return result;
            return UnityContainerFactory.Instance.Resolve<T>();
        }

        public virtual T GetService<T>(string name) where T : class, IBusinessService
        {
            var prefix = GetCustomerPrefixForUnity();
            if (!string.IsNullOrWhiteSpace(prefix))
            {
                var result = GetRegisteredTypes<T>(prefix, name).FirstOrDefault();
                if (result != null)
                    return result;
            }
            return UnityContainerFactory.Instance.Resolve<T>(name);
        }

        public virtual T GetType<T>() where T : class
        {
            T result = null;
            try
            {
                result = GetType<T>("");
            }
            catch(Exception) { }
            
            if (result != null)
                return result;
            
            return UnityContainerFactory.Instance.Resolve<T>();
        }

        public virtual T GetType<T>(string name) where T : class
        {
            var prefix = GetCustomerPrefixForUnity();
            if (!string.IsNullOrWhiteSpace(prefix))
            {
                var result = GetRegisteredTypes<T>(prefix, name).FirstOrDefault();
                if (result != null)
                    return result;
            }
            return UnityContainerFactory.Instance.Resolve<T>(name);
        }

        /// <summary>
        /// Gets all the objects that implements the specified Type
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public IEnumerable<T> GetAll<T>()
        {
            var prefix = GetCustomerPrefixForUnity();
            return GetRegisteredTypes<T>(prefix, "", true);
        }

        #endregion

        #endregion

        #region Helper Methods

        private void RegisteredNamedTypes()
        {
            _registeredNamedTypes = new Dictionary<string, List<ContainerRegistration>>();
            var all = UnityContainerFactory.Instance.Registrations.Where(x => !string.IsNullOrWhiteSpace(x.Name)).ToList();
            foreach (var item in all)
            {
                var prefix = "default";
                if (item.Name.StartsWith("#") && item.Name.IndexOf('_') > 0)
                    prefix = item.Name.Substring(0, item.Name.IndexOf('_') + 1);
                if (_registeredNamedTypes.ContainsKey(prefix))
                {
                    _registeredNamedTypes[prefix].Add(item);
                }
                else
                {
                    var list = new List<ContainerRegistration> { item };
                    _registeredNamedTypes.Add(prefix, list);
                }
            }
        }


        private IList<T> GetRegisteredTypes<T>(string prefix, string name, bool getMultiple = false)
        {
            var results = new List<T>();
            var types = new List<Type>();
            if (!string.IsNullOrWhiteSpace(prefix))
            {
                var registeredName = IntegrationConfigBase.GetRegistryName(prefix, name);
                if (_registeredNamedTypes.ContainsKey(prefix))
                    types = _registeredNamedTypes[prefix].Where(x => x.RegisteredType == typeof(T) && x.Name == registeredName).Select(x => x.MappedToType).ToList();
            }
            if (!string.IsNullOrWhiteSpace(name))
            {
                if (UnityContainerFactory.Instance.Registrations.Any(x => x.Name == name))
                    results.Add(UnityContainerFactory.Instance.Resolve<T>(name));
            }
            else if (getMultiple)
            {
                if (_registeredNamedTypes.ContainsKey("default"))
                    types = _registeredNamedTypes["default"].Where(x => x.RegisteredType == typeof(T)).Select(x => x.MappedToType).ToList();
                if (!string.IsNullOrWhiteSpace(prefix) && _registeredNamedTypes.ContainsKey(prefix))
                    types.AddRange(_registeredNamedTypes[prefix].Where(x => x.RegisteredType == typeof(T)).Select(x => x.MappedToType).ToList());
            }

            results.AddRange(types.Select(x => (T)UnityContainerFactory.Instance.Resolve(x.UnderlyingSystemType)).ToList());
            return results;
        }

        private static string GetCustomerPrefixForUnity()
        {
            var svc = UnityContainerFactory.Instance.Resolve<ICustomerAdminService>();
            var customerAdminDetail = svc.GetCustomerAdminDetail();
            return customerAdminDetail == null || string.IsNullOrWhiteSpace(customerAdminDetail.Suffix) ? string.Empty : IntegrationConfigBase.GetCustomerPrefixForUnity(customerAdminDetail.Suffix);
        }

        #endregion

    }
}
