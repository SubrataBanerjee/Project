﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.API.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Henkel.Common.Core.Repository.Model
{
    public abstract class BaseBootstrapper
    {
        public static Guid CustomerId
        {
            get
            {
                var userContextService = ObjectLocator.GetService<IUserContextService>();
                var custId = userContextService.CustomerId;
                if (custId == Guid.Empty)
                    custId = GetCustomerIdFromContext();

                return custId;
            }

        }

        #region Helper methods

        private static Guid GetCustomerIdFromContext()
        {
            if (HttpContext.Current != null)
            {
                if (HttpContext.Current.Session != null)
                {
                    var custId = (Guid)(HttpContext.Current.Session["CustomerId"] ?? Guid.Empty);
                    if (custId == Guid.Empty)
                        return GetCustomerIdFromAdminDB();
                }
                return GetCustomerIdFromAdminDB();
            }
            return Guid.Empty;
        }

        private static Guid GetCustomerIdFromAdminDB()
        {
            var hostName = GetHostName();
            if (!string.IsNullOrWhiteSpace(hostName))
            {
                var customersAdminDetails = CustomerAdminUtil.GetAllCustomerAdminDetails();
                var customerAdminDetail = customersAdminDetails.FirstOrDefault(x => x.SubDomain == hostName);
                if (customerAdminDetail != null)
                {
                    return customerAdminDetail.CustomerId;
                }
            }

            return Guid.Empty;
        }

        private static string GetHostName()
        {
            var request = HttpContext.Current.Request;
            var hostName = request.IsLocal ? request.Headers["Host"] : request.Url.Host;

            if (hostName.Length > 0)
                hostName = hostName.Split(new[] { '.' })[0].Split(new[] { ':' })[0];
            return hostName;
        }

        #endregion
    }
}
