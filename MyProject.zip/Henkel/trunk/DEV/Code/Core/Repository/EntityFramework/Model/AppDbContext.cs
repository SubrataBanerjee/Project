﻿using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Data.Entity;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.Composition;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.API.Model;
using System.Data.Entity.Infrastructure.Interception;
using EntityFramework.Filters;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.API.Services;
using Microsoft.Practices.EnterpriseLibrary.Common.Utility;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Common.Core.Repository.EntityFramework.Model
{
    public class AppDbContext : DbContext
    {

        private readonly IEnumerable<Assembly> _assemblies;
        private readonly bool _actionFilterEnabled;
        private readonly Guid? _customerId;

        /// <summary>
        /// Initializes a new instance of the <see cref="AppDbContext"/> class.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <param name="connectionString">The connection string.</param>
        public AppDbContext(IEnumerable<Assembly> assemblies, string connectionString, bool actionFilterEnabled, Guid? customerId)
            : base(connectionString)
        {
            _assemblies = assemblies;
            _actionFilterEnabled = actionFilterEnabled;
            _customerId = customerId;
        }

        /// <summary>
        /// This method is called when the model for a derived context has been initialized, but
        /// before the model has been locked down and used to initialize the context.  The default
        /// implementation of this method does nothing, but it can be overridden in a derived class
        /// such that the model can be further configured before it is locked down.
        /// </summary>
        /// <param name="modelBuilder">The builder that defines the model for the context being created.</param>
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            AddCustomEntityConfigurations(_assemblies, modelBuilder);
            CreateModelFromAssemblies(_assemblies, modelBuilder);
            AttachedFilters(modelBuilder);
            base.OnModelCreating(modelBuilder);
        }



        /// <summary>
        /// Adds the custom entity configurations.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <param name="modelBuilder">The model builder.</param>
        private static void AddCustomEntityConfigurations(IEnumerable<Assembly> assemblies, DbModelBuilder modelBuilder)
        {
            var contextConfiguration = new ContextConfiguration();
            var aggregateCatalog = new AggregateCatalog();
            foreach (var catalog in assemblies.Select(assembly => new AssemblyCatalog(assembly)))
            {
                aggregateCatalog.Catalogs.Add(catalog);
            }
            var container = new CompositionContainer(aggregateCatalog);
            container.ComposeParts(contextConfiguration);

            contextConfiguration.Configurations.ForEach(configuration =>
                                                        configuration.AddConfiguration(modelBuilder.Configurations));
        }

        /// <summary>
        /// Creates the model from assemblies.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <param name="modelBuilder">The model builder.</param>
        private static void CreateModelFromAssemblies(IEnumerable<Assembly> assemblies, DbModelBuilder modelBuilder)
        {
            var entityTypes = GetValidEntities(assemblies);

            foreach (var entityType in entityTypes)
            {
                try
                {
                    AddEntityTypeToModel(entityType, modelBuilder);
                }
                catch (Exception e)
                {
                    throw new RepositoryException(string.Format("Error adding to model, entity: {0}. Original exception: {1}", entityType.Name, e.Message));
                }
            }
        }

        /// <summary>
        /// Gets the valid entities.
        /// </summary>
        /// <param name="assemblies">The assemblies.</param>
        /// <returns></returns>
        private static IEnumerable<Type> GetValidEntities(IEnumerable<Assembly> assemblies)
        {
            Type entityInterfaceType = typeof(IEntity);
            return
                assemblies.SelectMany(x => x.GetTypes()).Where(entityInterfaceType.IsAssignableFrom).Where(
                    t => !t.IsInterface && !t.IsAbstract);
        }

        /// <summary>
        /// Adds the entity type to model.
        /// </summary>
        /// <param name="entityType">Type of the entity.</param>
        /// <param name="modelBuilder">The model builder.</param>
        private static void AddEntityTypeToModel(Type entityType, DbModelBuilder modelBuilder)
        {
            Type modelBuilderType = modelBuilder.GetType();
            MethodInfo method = modelBuilderType.GetMethod("Entity").MakeGenericMethod(entityType);
            method.Invoke(modelBuilder, null);
        }

        private void AttachedFilters(DbModelBuilder modelBuilder)
        {
            if (_actionFilterEnabled)
            {
                DbInterception.Add(new FilterInterceptor());
                modelBuilder.Conventions.Add(FilterConvention.Create<CustomerEntity, Guid>("CustomerFilter", (e, customerId) => e.CustomerId == customerId));

                this.EnableFilter("CustomerFilter")
                    .SetParameter("customerId", _customerId ?? ObjectLocator.GetService<IUserContextService>().CustomerId);
            }
        }
    }
}
