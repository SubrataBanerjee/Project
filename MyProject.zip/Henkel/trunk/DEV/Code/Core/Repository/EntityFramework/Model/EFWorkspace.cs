﻿using Henkel.Common.Core.Repository.EntityFramework.Transaction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Model
{
    public class EFWorkspace
    {
        [ThreadStatic]
        private static IEFSession _currentSession;

        /// <summary>
        /// Gets or sets the current EF Session.
        /// </summary>
        /// <value>
        /// The current EF Session.
        /// </value>
        public static IEFSession CurrentSession
        {
            get
            {
                return _currentSession;
            }
            set
            {
                _currentSession = value;
            }
        }
    }
}
