﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction
{
    public interface IEFSessionFactory
    {
        IEFSession OpenSession(bool isReadWrite, bool actionFilterEnabled, Guid? customerId, IsolationLevel isolationLevel);
    }
}
