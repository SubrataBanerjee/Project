﻿using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Repository.EntityFramework.Transaction;
using Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl;
using Henkel.Common.Core.Repository.Model;
using Henkel.Common.Core.Utils;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Model
{
    public class EFBootstrapper : BaseBootstrapper
    {
        #region Fields
        private static ConcurrentDictionary<Guid, IEFSessionFactory> _sessionFactoryForCustomers = new ConcurrentDictionary<Guid, IEFSessionFactory>();
        private static string _isMultiCustomer;
        private static IEFSessionFactory _sessionFactory;
        private static object syncRoot = new Object();
        private static volatile Assembly _callingAssembly;
        private static IEnumerable<Assembly> _allAssemblies;
        private static object _lockForAssemblies = new object();

        #endregion

        #region Public Members

        public static IEFSessionFactory SessionFactory
        {
            get
            {
                if (string.IsNullOrWhiteSpace(_isMultiCustomer))
                    _isMultiCustomer = ConfigurationManager.AppSettings["ConnStringInAdminDb"] ?? "false";
                if (_isMultiCustomer == "true")
                    return GetSessionFactoryForMultiCustomer();

                return GetDefaultSessionFactory();
            }
        }

        #endregion


        #region Helper Methods

        private static IEFSessionFactory GetSessionFactoryForMultiCustomer()
        {
            IEFSessionFactory sessionFactory;
            var custId = CustomerId;
            if (!_sessionFactoryForCustomers.TryGetValue(custId, out sessionFactory))
            {
                lock (syncRoot)
                {
                    if (!_sessionFactoryForCustomers.TryGetValue(custId, out sessionFactory))
                        sessionFactory = CreateSessionFactoryForCustomer(custId);
                }
            }
            return sessionFactory;
        }

        private static IEFSessionFactory CreateSessionFactoryForCustomer(Guid customerId)
        {
            if (_allAssemblies == null)
            {
                lock (_lockForAssemblies)
                {
                    if (_allAssemblies == null)
                        _allAssemblies = AssemblyHelper.GetAllAssemblies(Assembly.GetCallingAssembly());
                }
            }

            if (customerId == Guid.Empty)
                throw new Exception(string.Format("Unable to Initialize Entity Framework. Invalid CustomerId: {0}", customerId));

            var customerAdminDetail = CustomerAdminUtil.GetAllCustomerAdminDetails().FirstOrDefault(x => x.CustomerId == customerId);
            if (customerAdminDetail == null)
                throw new Exception("Unable to Initialize  Entity Framework. CustomerAdmin DB is not configured.");
            try
            {
                var sessionFactory = new EFSessionFactory(_allAssemblies, customerAdminDetail.ConnectionString);
                if (!_sessionFactoryForCustomers.TryAdd(customerId, sessionFactory))
                    throw new Exception("Unable to Initialize  Entity Framework");
                return sessionFactory;
            }
            catch (Exception ex)
            {
                LogLoaderExceptions(ex);
                throw;
            }
        }

        private static IEFSessionFactory GetDefaultSessionFactory()
        {
            if (_callingAssembly == null)
            {
                lock (syncRoot)
                {
                    if (_callingAssembly == null)
                    {
                        _callingAssembly = Assembly.GetCallingAssembly();
                        InitializeAppDbContext(_callingAssembly);
                    }
                }
            }
            int counter = 0;
            while (_sessionFactory == null)
            {
                counter += 1;
                if (counter > 5)
                    break;

                Thread.Sleep(100);
            }
            return _sessionFactory;
        }

        private static void InitializeAppDbContext(Assembly callingAssembly)
        {
            var allAssemblies = AssemblyHelper.GetAllAssemblies(callingAssembly);
            var index = ConfigurationManager.ConnectionStrings.Count - 1;
            var conStr = ConfigurationManager.ConnectionStrings[index];
            if (conStr == null)
                throw new ConfigurationErrorsException("Failed to find connection string named in app/web.config.");

            try
            {
                _sessionFactory = new EFSessionFactory(allAssemblies, conStr.ConnectionString);
            }
            catch (Exception ex)
            {
                LogLoaderExceptions(ex);
                throw;
            }
        }

        private static void LogLoaderExceptions(Exception ex)
        {
            Logger.Exception("EFBootStrapper", ex.Message, ex.StackTrace);
            while (ex.InnerException != null)
            {
                Logger.Exception("EFBootStrapper-Inner", ex.InnerException.Message, ex.InnerException.StackTrace);
                var typeLoadException = ex.InnerException as ReflectionTypeLoadException;
                if (typeLoadException != null)
                {
                    foreach (var item in typeLoadException.LoaderExceptions)
                    {
                        Logger.Exception("EFBootStrapper-Loader", item.Message, item.StackTrace);
                    }
                }
                ex = ex.InnerException;
            }
        }

        #endregion
    }
}
