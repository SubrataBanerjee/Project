﻿using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction
{
    public interface IEFSession
    {
        string SessionId { get; }

        void Commit();

        void Rollback();

        void SaveChanges();

        void Dispose();

        bool IsReadOnly { get; }

        DbSet Set(Type entityType);

        DbSet<T> Set<T>() where T : class, IEntity;

        DbEntityEntry Entry(object entity);

        DbEntityEntry<T> Entry<T>(T entity) where T : class, IEntity;
    }
}
