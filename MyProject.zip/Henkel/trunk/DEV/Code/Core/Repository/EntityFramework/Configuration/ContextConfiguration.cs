﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Configuration
{
    /// <summary>
    /// Context Configuration container used to configure the DbContext with Custom Entity Configurations
    /// </summary>
    public class ContextConfiguration
    {
        /// <summary>
        /// Gets or sets the configurations.
        /// </summary>
        /// <value>
        /// The configurations.
        /// </value>
        [ImportMany(typeof(IEntityConfiguration))]
        public IEnumerable<IEntityConfiguration> Configurations
        {
            get;
            set;
        }
    }
}
