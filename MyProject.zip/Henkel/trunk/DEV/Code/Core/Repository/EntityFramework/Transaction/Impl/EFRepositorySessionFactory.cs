﻿using Henkel.Common.Core.API.Repository;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.Repository.EntityFramework.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl
{
    public class EFRepositorySessionFactory : IRepositorySessionFactory
    {
        #region Implementation of IRepositorySessionFactory

        public IRepositorySession GetNewSession(bool isReadWrite, bool actionFilterEnabled, Guid? customerId, IsolationLevel isolationLevel = IsolationLevel.ReadCommitted)
        {
            return new EFRepositorySession(isReadWrite, actionFilterEnabled, customerId, isolationLevel);
        }

        public bool RepositorySessionExists()
        {
            return EFWorkspace.CurrentSession != null;
        }

        public void Unbind()
        {
            //No Implementation - Ignore
        }

        #endregion
    }
}
