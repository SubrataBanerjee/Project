﻿using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Repository;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.Events.Model;
using Henkel.Common.Core.Repository.EntityFramework.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository.EntityFramework.Transaction.Impl
{
    public class EFRepositorySession : IRepositorySession
    {
        #region Fields

        private bool _isRollback = false;

        #endregion

        #region Constructors

        public EFRepositorySession(bool isReadWrite, bool actionFilterEnabled, Guid? customerId, System.Data.IsolationLevel isolationLevel = System.Data.IsolationLevel.ReadCommitted)
        {
            Initialize(isReadWrite, actionFilterEnabled, customerId, isolationLevel);
        }

        #endregion

        #region Implementation of IRepositorySession

        public void Rollback()
        {
            _isRollback = true;
        }

        public void Flush()
        {
            EFWorkspace.CurrentSession.SaveChanges();
        }

        #endregion

        #region Implementation of IDisposable

        public void Dispose()
        {
            Dispose(true);
            
            GC.SuppressFinalize(this);
        }


        #endregion


        #region Helper Methods

        private void Initialize(bool isReadWrite, bool actionFilterEnabled, Guid? customerId, System.Data.IsolationLevel isolationLevel)
        {
            EFWorkspace.CurrentSession = EFBootstrapper.SessionFactory.OpenSession(isReadWrite, actionFilterEnabled, customerId, isolationLevel);
        }

        private void Dispose(bool disposing)
        {
            if (disposing)
            {
                var currentSession = EFWorkspace.CurrentSession;
                try
                {
                    try
                    {
                        if (currentSession != null)
                        {
                            Console.WriteLine("Disposing RepositorySession: {0}", currentSession.SessionId);
                            if (_isRollback)
                                currentSession.Rollback();
                            else
                                currentSession.Commit();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine("Error: {0},   \n\r StarckStrace: {1} ", ex.Message, ex.StackTrace);

                        Logger.Exception(GetType().Name, OperationStatus.CreateFromException("Error Occurred", ex));
                        if (currentSession != null)
                            currentSession.Rollback();
                    }
                }
                finally
                {
                    // free managed resources
                    EFWorkspace.CurrentSession.Dispose();
                    EFWorkspace.CurrentSession = null;
                    EventsList.DispatchEvents();
                }
            }
        }

        #endregion
    }
}
