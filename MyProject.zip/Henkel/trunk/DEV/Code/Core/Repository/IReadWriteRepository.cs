﻿using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Repository
{
    /// <summary>
    /// Interface for Read Write Repository
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IReadWriteRepository<T> : IQueryableRepository<T> where T : class, IEntity
    {
        T Add(T obj);

        void Update(T entity);

        void Delete(Guid id);

        void Delete(T entity);
    }
}
