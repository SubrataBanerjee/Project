﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.Utils.Unity;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Practices.Unity;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Logging.Model;

namespace Henkel.Common.Core.Services.Impl
{
    public class CustomerAdminService : ICustomerAdminService
    {
        public CustomerAdminDetail GetCustomerAdminDetail()
        {
            var ucs = UnityContainerFactory.Instance.Resolve<IUserContextService>();
            var custId = ucs.CustomerId;

            return custId == Guid.Empty ? null : GetAllCustomerAdminDetails().FirstOrDefault(x => x.CustomerId == custId);
        }

        public IList<CustomerAdminDetail> GetAllCustomerAdminDetails()
        {
            var adminDbCacheKey = string.Format("{0}-CustomerAdmin", ConfigurationManager.AppSettings["AdminDBCacheKey"] ?? "Henkel");
            double cacheTimeOut = 5;
            var adminDbCacheTimeOut = ConfigurationManager.AppSettings["AdminDBCacheTimeOut"];
            if (!string.IsNullOrWhiteSpace(adminDbCacheTimeOut))
                cacheTimeOut = Convert.ToDouble(adminDbCacheTimeOut);

            var cacheSvc = UnityContainerFactory.Instance.Resolve<ICachingService>();
            var result = cacheSvc.Get(adminDbCacheKey, GetAllCustomerInfoFromDatabase,
            new CachingOptions
            {
                CacheType = CacheType.Distributed,
                CachePolicy = new CacheItemPolicy { AbsoluteExpiration = DateTime.UtcNow.AddMinutes(cacheTimeOut) }
            });
            return result;
        }

        private static IList<CustomerAdminDetail> GetAllCustomerInfoFromDatabase()
        {
            var connString = ConfigurationManager.ConnectionStrings["AdminDb"].ConnectionString;
            var connProvider = ConfigurationManager.AppSettings["AdminDBProvider"] ?? "SqlClient";
            const string queryString = "SELECT * FROM Admin_CustomerDetail";
            var list = new List<CustomerAdminDetail>();
            try
            {
                using (var connection = GetConnection(connString, connProvider))
                {
                    using (var command = GetCommand(queryString, connection, connProvider))
                    {
                        connection.Open();
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader != null && reader.Read())
                            {
                                var cInfo = new CustomerAdminDetail
                                {
                                    CustomerId = reader.GetGuid(0),
                                    SubDomain = reader.GetString(1),
                                    Suffix = reader.GetString(2),
                                    Name = reader.GetString(3),
                                    ConnectionString = reader.GetString(4)
                                };
                                list.Add(cInfo);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Exception("CustomerAdminService", ex.Message, ex.StackTrace);
            }
            return GetAllCustomerConfigFromDatabase(list);
        }

        private static IList<CustomerAdminDetail> GetAllCustomerConfigFromDatabase(IList<CustomerAdminDetail> customerDetails)
        {
            var connString = ConfigurationManager.ConnectionStrings["AdminDb"].ConnectionString;
            var connProvider = ConfigurationManager.AppSettings["AdminDBProvider"] ?? "SqlClient";

            foreach (var customerDetail in customerDetails)
            {
                try
                {
                    string queryString = string.Format("SELECT * FROM [dbo].[Admin_CustomerDetailConfig] where [CustomerId] = '{0}'", customerDetail.CustomerId.ToString());
                    var configvalues = new Dictionary<string, string>();
                    using (var connection = GetConnection(connString, connProvider))
                    {
                        using (var command = GetCommand(queryString, connection, connProvider))
                        {
                            connection.Open();
                            using (var reader = command.ExecuteReader())
                            {
                                while (reader != null && reader.Read())
                                {
                                    var key = reader.GetString(2);
                                    var value = reader.GetString(3);
                                    if (configvalues.ContainsKey(key))
                                        configvalues[key] = value;
                                    else
                                        configvalues.Add(key, value);
                                }
                            }
                        }
                    }
                    customerDetail.CustomerAdminConfigs = configvalues;
                }
                catch (Exception ex)
                {
                    Logger.Exception("CustomerAdminService", ex.Message, ex.StackTrace);
                }
            }
            return customerDetails;
        }


        private static IDbConnection GetConnection(string connString, string provider)
        {
            if (provider == "OracleClient")
                return new OleDbConnection(connString);
            return new SqlConnection(connString);
        }

        private static IDbCommand GetCommand(string queryString, IDbConnection conn, string provider)
        {
            if (provider == "OracleClient")
                return new OleDbCommand(queryString, (OleDbConnection)conn);
            return new SqlCommand(queryString, (SqlConnection)conn);
        }
    }
}
