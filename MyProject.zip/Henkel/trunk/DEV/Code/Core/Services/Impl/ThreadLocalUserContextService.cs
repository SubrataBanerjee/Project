﻿using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Henkel.Common.Core.Services.Impl
{
    public class ThreadLocalUserContextService : BaseService, IUserContextService
    {
        #region Constructors

        /// <summary>
        /// Initializes the <see cref="ThreadLocalUserContextService"/> class.
        /// </summary>
        public static void Initialize()
        {
            Thread.AllocateNamedDataSlot("Context_CustomerId");
            Thread.AllocateNamedDataSlot("Context_UserId");
            Thread.AllocateNamedDataSlot("Context_UserName");
            Thread.AllocateNamedDataSlot("Context_IPAddress");
            Thread.AllocateNamedDataSlot("Context_CustomData");
        }

        #endregion

        #region Implementation of IUserContextService

        public Guid CustomerId
        {
            get
            {
                var dataInThread = GetDataFromThreadSlot("Context_CustomerId");
                return dataInThread == null ? Guid.Empty : new Guid(dataInThread.ToString());
            }
        }

        public string CustomerName
        {
            get
            {
                object dataInThread = GetDataFromThreadSlot("Context_CustomerName");
                if (dataInThread == null)
                    return "<Unknown>";
                return (string)dataInThread;
            }
        }

        public Guid CurrentUserId
        {
            get
            {
                var dataInThread = GetDataFromThreadSlot("Context_UserId");
                return dataInThread == null ? Guid.Empty : new Guid(dataInThread.ToString());
            }
        }

        public string CurrentUserName
        {
            get
            {
                object dataInThread = GetDataFromThreadSlot("Context_UserName");
                if (dataInThread == null)
                    return "<Unknown>";
                return (string)dataInThread;
            }
        }

        public IPAddress IPAddress
        {
            get
            {
                object dataInThread = GetDataFromThreadSlot("Context_IPAddress");
                if (dataInThread == null)
                    return IPAddress.None;
                return IPAddress.Parse((string)dataInThread);
            }
        }

        /// <summary>
        /// Gets the current time.
        /// </summary>
        public DateTime CurrentTime
        {
            get { return DateTime.UtcNow; }
        }

        public string CustomData
        {
            get
            {
                return GetDataFromThreadSlot("Context_CustomData") as string;
            }
        }

        #endregion

        #region Helper Methods

        /// <summary>
        /// Gets the data from thread slot.
        /// </summary>
        /// <param name="slotName">Name of the slot.</param>
        /// <returns></returns>
        private static object GetDataFromThreadSlot(string slotName)
        {
            var customDataDataStoreSlot = Thread.GetNamedDataSlot(slotName);
            var dataInThread = Thread.GetData(customDataDataStoreSlot);
            return dataInThread;
        }

        #endregion
    }
}
