﻿using PMS.Common.Core.API.Locator;
using PMS.Common.Core.API.Services;
using PMS.Common.Core.Resources;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS.Common.Core.Services.Impl
{
    public class LocalFileService : IFileService
    {
        #region Implementation of IFileService

        /// <summary>
        /// Saves the file.
        /// </summary>
        /// <param name="fileStream">The file stream.</param>
        /// <param name="fileName">Name of the file.</param>
        /// <param name="path">The path.</param>
        /// <param name="contentType">Type of the content.</param>
        /// <returns>File Full path with name</returns>
        public string SaveFile(Stream fileStream, string fileName, string path, string contentType)
        {
            var actualPath = path.Replace("\\", "/");
            if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                actualPath = Path.Combine(StorageContainerInfo.StoragePath, actualPath);

            if (!Directory.Exists(actualPath))
                Directory.CreateDirectory(actualPath);

            if (Directory.Exists(actualPath))
            {
                var filePath = Path.Combine(actualPath, fileName);

                using (var targetStream = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None))
                {
                    //read from the input stream in 4K chunks
                    //and save to output stream
                    const int bufferLen = 4096;
                    var buffer = new byte[bufferLen];
                    int count;
                    fileStream.Position = 0;
                    while ((count = fileStream.Read(buffer, 0, bufferLen)) > 0)
                    {
                        targetStream.Write(buffer, 0, count);
                    }
                    targetStream.Close();
                    fileStream.Close();
                }
                return Path.Combine(actualPath, fileName);
            }

            return string.Empty;
        }

        /// <summary>
        /// Deletes the file.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        public void DeleteFile(string pathWithFileName)
        {
            if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                pathWithFileName = Path.Combine(StorageContainerInfo.StoragePath, pathWithFileName);

            if (File.Exists(pathWithFileName))
            {
                File.Delete(pathWithFileName);
            }
        }

        /// <summary>
        /// Renames the file.
        /// </summary>
        /// <param name="pathWithFileName">Name of the path with file.</param>
        /// <param name="newFileName">New name of the file.</param>
        public void RenameFile(string pathWithFileName, string newFileName)
        {
            if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                pathWithFileName = Path.Combine(StorageContainerInfo.StoragePath, pathWithFileName);

            if (File.Exists(pathWithFileName))
            {
                var directory = Path.GetDirectoryName(pathWithFileName);
                if (!string.IsNullOrEmpty(directory))
                {
                    var newFilePath = Path.Combine(directory, newFileName);
                    File.Move(pathWithFileName, newFilePath);
                }
            }
        }

        public Stream GetFile(string pathWithFileName)
        {
            if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                pathWithFileName = Path.Combine(StorageContainerInfo.StoragePath, pathWithFileName);
            var memStream = new MemoryStream();
            if (File.Exists(pathWithFileName))
            {
                using (FileStream fileStream = File.OpenRead(pathWithFileName))
                {
                    memStream.SetLength(fileStream.Length);
                    fileStream.Read(memStream.GetBuffer(), 0, (int)fileStream.Length);
                }
            }
            return memStream;
        }


        public string GetFilePath(string pathWithFileName)
        {
            return pathWithFileName;
        }

        public bool FileExists(string pathWithFileName)
        {
            if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                pathWithFileName = Path.Combine(StorageContainerInfo.StoragePath, pathWithFileName);

            return File.Exists(pathWithFileName);
        }

        /// <summary>
        /// Move the file from one location to another location.
        /// </summary>
        /// <param name="fileToMove">name of the file</param>
        /// <param name="existingPath">Existing storage Path</param>
        /// <param name="newPath">New storage Path</param>
        public void MoveFile(string fileToMove, string existingPath, string newPath)
        {
            var pathWithFileName = Path.Combine(existingPath, fileToMove);
            if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                pathWithFileName = Path.Combine(StorageContainerInfo.StoragePath, pathWithFileName);

            if (File.Exists(pathWithFileName))
            {
                var effectiveNewPath = newPath;
                if (StorageContainerInfo != null && !string.IsNullOrEmpty(StorageContainerInfo.StoragePath))
                    effectiveNewPath = Path.Combine(StorageContainerInfo.StoragePath, newPath);

                var directory = Path.GetDirectoryName(effectiveNewPath);

                if (!string.IsNullOrEmpty(directory))
                {
                    var newFilePathWithFileName = Path.Combine(directory, fileToMove);
                    File.Move(pathWithFileName, newFilePathWithFileName);
                }
            }
        }

        #endregion

        #region Helper Members

        private string StorageContainerDirectory
        {
            get
            {
                return ObjectLocator.GetService<ICustomerAdminService>().GetCustomerAdminDetail().GetConfigValue(CoreAdminConfigKey.StorageContainerDirectory);
            }
        }

        private string StorageContainerDirectoryCredential
        {
            get
            {
                return ObjectLocator.GetService<ICustomerAdminService>().GetCustomerAdminDetail().GetConfigValue(CoreAdminConfigKey.StorageContainerDirectoryCredential);
            }
        }

        private StorageContainerDetail StorageContainerInfo
        {
            get
            {
                var storageContainerDetail = new StorageContainerDetail { StoragePath = StorageContainerDirectory };

                var storageContainerDirectoryCred = StorageContainerDirectoryCredential;
                if (!string.IsNullOrWhiteSpace(storageContainerDirectoryCred))
                {
                    var storageContainerInfoArr = storageContainerDirectoryCred.Split(new[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                    if (storageContainerInfoArr.Length > 0)
                    {
                        storageContainerDetail.UserName = storageContainerInfoArr[0];
                        storageContainerDetail.ConnectionString = storageContainerInfoArr[0];
                    }
                    if (storageContainerInfoArr.Length > 1)
                        storageContainerDetail.Password = storageContainerInfoArr[1];
                }

                return storageContainerDetail;
            }
        }

        #endregion
    }

    public class StorageContainerDetail
    {
        public string StoragePath { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string ConnectionString { get; set; }
    }
}
