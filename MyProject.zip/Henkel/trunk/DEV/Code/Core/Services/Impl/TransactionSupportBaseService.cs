﻿using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Repository;
using Henkel.Common.Core.API.Repository.Transaction;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Common.Core.Services.Impl
{
    public class TransactionSupportBaseService : BaseService
    {
        #region Fields

        private readonly IRepositorySessionFactory _repositorySessionFactory;

        #endregion

        #region Constructors

        public TransactionSupportBaseService()
        {
            _repositorySessionFactory = ObjectLocator.GetObject<IRepositorySessionFactory>();
        }

        #endregion

        #region Properties

        protected IRepositorySession RepositorySession
        {
            get
            {
                return _repositorySessionFactory.GetNewSession(true,true,null);
            }
        }

        protected IRepositorySession RepositoryReadOnlySession
        {
            get
            {
                return _repositorySessionFactory.GetNewSession(false,true,null);
            }
        }

        protected IRepositorySession RepositorySessionWithoutFilter
        {
            get
            {
                return _repositorySessionFactory.GetNewSession(true, false, null);
            }
        }

        protected IRepositorySession RepositoryReadOnlySessionWithoutFilter
        {
            get
            {
                return _repositorySessionFactory.GetNewSession(false, false, null);
            }
        }


        #endregion
    }
}
