﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Tests
{
    internal class FileLocator
    {
        internal const string CONNECTION_STRING_KEY = "Henkel.Business.Security.Tests.Properties.Settings.TestDBConnectionString";

        internal class DataFile
        {
            public const string SYSTEM_DATA = "Henkel.Business.Security.Tests.Support.Data.SystemData.xml";
            public const string USER = "Henkel.Business.Security.Tests.Support.Data.Users.xml";
            public const string PASSWORD_HISTORY = "Henkel.Business.Security.Tests.Support.Data.PasswordHistory.xml";
            public const string EMAIL_TEMPLATE = "Henkel.Business.Security.Tests.Support.Data.EmailTemplate.xml";
        }

        internal class Schema
        {
            internal const string SECURITY = "Henkel.Business.Security.Tests.Support.Schema.Security.xsd";
        }
    }
}
