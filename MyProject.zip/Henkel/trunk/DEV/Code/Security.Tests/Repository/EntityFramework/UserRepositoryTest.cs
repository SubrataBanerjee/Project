﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Tests.Repository.Helper;
using Henkel.Common.Core.API.Model;
using Henkel.Common.SupportForTests.Repository;
using Henkel.Common.SupportForTests.Repository.EntityFramework;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Business.Security.Tests.Repository.EntityFramework
{
    //[Ignore]
    [TestClass]
    public class UserRepositoryTest :  RequireEFDatabaseSupport
    {
        #region Fields

        private IUserRepository _userRepository;
        private UserRepositoryTestHelper _userRepositoryTestHelper;

        #endregion

        #region Settings

        protected override DatabaseInfo DatabaseInfo
        {
            get
            {
                return new DatabaseInfo
                {
                    ConnectionString = ConfigurationManager.ConnectionStrings[FileLocator.CONNECTION_STRING_KEY].ToString(),
                    XSDPath = FileLocator.Schema.SECURITY,
                    DataFiles = {
                                    FileLocator.DataFile.SYSTEM_DATA,
                                    FileLocator.DataFile.USER,
                                }
                };
            }
        }

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _userRepository = ObjectLocator.GetObject<IUserRepository>();
            _userRepositoryTestHelper = new UserRepositoryTestHelper(_userRepository);
        }

        [TestCleanup]
        public void TestCleanup()
        {
            DatabaseSupportCleanup();
        }

        #endregion

        #region Tests

        #region Query Tests


        [TestMethod]
        public void EFShouldGetUserCountBySearchExpression()
        {
            _userRepositoryTestHelper.ShouldGetUserCountBySearchExpression();
        }

        [TestMethod]
        public void EFShouldGetUserById()
        {
            _userRepositoryTestHelper.ShouldGetUserById();
        }

        [TestMethod]
        public void EFShouldFindAllUsersWithoutAnySearchExpressionAndPagination()
        {
            _userRepositoryTestHelper.ShouldFindAllUsersWithoutAnySearchExpressionAndPagination();
        }
        
        [TestMethod]
        public void EFShouldFindAllUsersWithPagination()
        {
            _userRepositoryTestHelper.ShouldFindAllUsersWithPagination();
        }

        [TestMethod]
        public void EFShouldFindUserBySearchExpressionAndPagination()
        {
            _userRepositoryTestHelper.ShouldFindUserBySearchExpressionAndPagination();
        }

        [TestMethod]
        public void EFShouldFindUserBySearchExpression()
        {
            _userRepositoryTestHelper.ShouldFindUserBySearchExpression();
        }

        #endregion

        #region Command tests

        [TestMethod]
        public void EFShouldAddUser()
        {
            _userRepositoryTestHelper.ShouldAddUser();
        }

        [TestMethod]
        public void EFShouldRollbackTransactionOnFailureToAddForMultipleRecords()
        {
            _userRepositoryTestHelper.ShouldRollbackTransactionOnFailureToAddForMultipleRecords();
        }

        [TestMethod]
        public void EFShouldUpdateUser()
        {
            _userRepositoryTestHelper.ShouldUpdateUser();
        }

        [TestMethod]
        public void EFShouldDeleteUser()
        {
            _userRepositoryTestHelper.ShouldDeleteUser();
        }

        #endregion

        #endregion
    }
}
