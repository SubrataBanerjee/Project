﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Business.Security.Model;
using Henkel.Business.Security.Repository;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.SupportForTests.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Business.Security.Tests.Repository.Helper
{
    public class UserRepositoryTestHelper
    {
        IUserRepository _userRepository;

        public UserRepositoryTestHelper(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        #region Settings

        private static IRepositorySession RepositorySession
        {
            get
            {
                return ObjectLocator.GetObject<IRepositorySessionFactory>().GetNewSession(true, true, BaseTest.CustomerId);
            }
        }

        private static IRepositorySession RepositoryReadOnlySession
        {
            get
            {
                return ObjectLocator.GetObject<IRepositorySessionFactory>().GetNewSession(false, true, BaseTest.CustomerId);
            }
        }

        #endregion

        #region Tests

        #region Queries

        public void ShouldGetUserCountBySearchExpression()
        {
            int userCount;
            using (RepositoryReadOnlySession)
            {
                userCount = _userRepository.GetCount(x=>x.IsActive == true);
            }

            Assert.AreEqual(7, userCount);
        }

        public void ShouldGetUserById()
        {
            var userId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");
            User user;
            using (RepositoryReadOnlySession)
            {
                user = _userRepository.GetById(userId);
            }

            Assert.AreEqual(userId, user.Id);
            Assert.AreEqual("User00", user.LoginId);
            Assert.AreEqual("System", user.CreatedBy);
            Assert.AreEqual("System", user.LastModifiedBy);
            Assert.AreEqual(Convert.ToDateTime("2015-01-01T10:32:52Z").ToString("ddMMyyyy"), user.CreatedOn.Value.ToString("ddMMyyyy"));
            Assert.AreEqual(Convert.ToDateTime("2015-01-01T10:32:52Z").ToString("ddMMyyyy"), user.LastModifiedOn.Value.ToString("ddMMyyyy"));
            Assert.AreEqual(true, user.IsActive);
            Assert.AreEqual(false, user.IsDeleted);
        }

        public void ShouldFindAllUsersWithoutAnySearchExpressionAndPagination()
        {
            using (RepositoryReadOnlySession)
            {
                var usersCount = _userRepository.Find().Count();
                Assert.AreEqual(8, usersCount);
            }
        }

        public void ShouldFindAllUsersWithPagination()
        {
            using (RepositoryReadOnlySession)
            {
                var totalCount = _userRepository.GetCount();
                var users = _userRepository.Find(null, x=>x.LoginId, 6, 5, "desc");

                Assert.AreEqual(8, totalCount);
                Assert.AreEqual(3, users.Count());
            }
        }

        public void ShouldFindUserBySearchExpressionAndPagination()
        {
            using (RepositoryReadOnlySession)
            {
                var totalCount = _userRepository.GetCount(x => x.IsActive);
                var users = _userRepository.Find(x => x.IsActive, x => x.LoginId, 6, 5, "DESC");

                Assert.IsNotNull(users);
                Assert.AreEqual(7, totalCount);
                Assert.AreEqual(2, users.Count());
            }
        }

        public void ShouldFindUserBySearchExpression()
        {
            using (RepositoryReadOnlySession)
            {
                var users = _userRepository.Find(x=>x.IsActive).ToList();

                Assert.IsNotNull(users);
                Assert.AreEqual(7, users.Count);
            }
        }

        #endregion

        #region Command

        public void ShouldAddUser()
        {
            var userId = new Guid("FA10D3AA-00DC-46A0-AE2C-0BB1CB1C71FB");

            User userToAdd = new User()
            {
                Id = userId,
                CustomerId = BaseTest.CustomerId,
                LoginId = "test",
                IsActive = true,
                IsDeleted = false,
                ChangePwdOnLogin = true,
                FailureLoginAttempt = 0,
                IsSuperAdmin = true,
                CreatedBy = "System",
                LastModifiedBy = "System",
                CreatedOn = DateTime.Now,
                LastModifiedOn = DateTime.Now,
            };

            User savedUser;
            using (RepositorySession)
            {
                savedUser = _userRepository.Add(userToAdd);
                savedUser = _userRepository.GetById(savedUser.Id);
            }
            Assert.IsNotNull(savedUser);

            Assert.AreEqual(userToAdd.Id, savedUser.Id);
            Assert.AreEqual(userToAdd.CustomerId, savedUser.CustomerId);
            Assert.AreEqual(userToAdd.LoginId, savedUser.LoginId);
            Assert.AreEqual(userToAdd.CreatedBy, savedUser.CreatedBy);
            Assert.AreEqual(userToAdd.LastModifiedBy, savedUser.LastModifiedBy);
            Assert.AreEqual(userToAdd.CreatedOn.Value.ToString("ddMMyyyy"), savedUser.CreatedOn.Value.ToString("ddMMyyyy"));
            Assert.AreEqual(userToAdd.LastModifiedOn.Value.ToString("ddMMyyyy"), savedUser.LastModifiedOn.Value.ToString("ddMMyyyy"));
            Assert.AreEqual(userToAdd.IsActive, savedUser.IsActive);
            Assert.AreEqual(userToAdd.IsDeleted, savedUser.IsDeleted);
            Assert.AreEqual(userToAdd.IsSuperAdmin, savedUser.IsSuperAdmin);
            Assert.AreEqual(userToAdd.ChangePwdOnLogin, savedUser.ChangePwdOnLogin);
            Assert.AreEqual(userToAdd.FailureLoginAttempt, savedUser.FailureLoginAttempt);
        }

        public void ShouldRollbackTransactionOnFailureToAddForMultipleRecords()
        {
            var userId1 = new Guid("FA10D3AA-00DC-46A0-AE2C-0BB1CB1C71FB");
            var userId2 = new Guid("42679E33-10C5-467E-B07B-8A3E85F87301");

            //Record with Valid data should initially Save
            User user1ToAdd = new User()
            {
                Id = userId1,
                LoginId = "BBB",
                IsActive = true,
                IsDeleted = false,
                ChangePwdOnLogin = true,
                FailureLoginAttempt = 0,
                IsSuperAdmin = true,
                CreatedBy = "System",
                LastModifiedBy = "System",
                CreatedOn = DateTime.Now,
                LastModifiedOn = DateTime.Now,
            };

            //Record with invalid data should force to rollback trancation
            var nameWithMaxLength50Exceed = "AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA";
            User user2ToAdd = new User()
            {
                Id = userId2,
                LoginId = nameWithMaxLength50Exceed,
                IsActive = true,
                IsDeleted = false,
                ChangePwdOnLogin = true,
                FailureLoginAttempt = 0,
                IsSuperAdmin = true,
                CreatedBy = "System",
                LastModifiedBy = "System",
                CreatedOn = DateTime.Now,
                LastModifiedOn = DateTime.Now,
            };

            try
            {
                using (RepositorySession)
                {
                    _userRepository.Add(user1ToAdd);

                    var savedUser = _userRepository.GetById(user1ToAdd.Id);
                    Assert.IsNotNull(savedUser);

                    //attempt to Add Invalid record which should cause Rollback transaction
                    _userRepository.Add(user2ToAdd);
                }
            }
            catch (Exception)
            {
                //Ignore
            }

            using (RepositoryReadOnlySession)
            {
                var savedUser1 = _userRepository.GetById(user1ToAdd.Id);
                Assert.IsNull(savedUser1);

                var savedUser2 = _userRepository.GetById(user2ToAdd.Id);
                Assert.IsNull(savedUser2);
            }
        }

        public void ShouldUpdateUser()
        {
            var userId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");
            User user;
            using (RepositorySession)
            {
                user = _userRepository.GetById(userId);

                Assert.IsNotNull(user);
                Assert.AreEqual("User00", user.LoginId);

                user.LoginId = "XXX";
                _userRepository.Update(user);

                user = _userRepository.GetById(userId);
            }

            Assert.IsNotNull(user);
            Assert.AreEqual("XXX", user.LoginId);
        }

        public void ShouldDeleteUser()
        {
            var userId = new Guid("8970C5C7-0D23-47A7-824F-27FC1CCCC520");
            User user;
            using (RepositorySession)
            {
                user = _userRepository.GetById(userId);

                Assert.IsNotNull(user);
                Assert.IsFalse(user.IsDeleted);

                _userRepository.Delete(userId);

                user = _userRepository.GetById(userId);
            }

            Assert.IsNull(user);
        }

        #endregion

        #endregion
    }
}
