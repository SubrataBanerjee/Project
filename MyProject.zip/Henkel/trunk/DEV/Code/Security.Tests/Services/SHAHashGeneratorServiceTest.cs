﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Henkel.Business.Security.Services;
using Henkel.Business.Security.Services.Impl;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.SupportForTests.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Tests.Services
{
    [TestClass]
    public class SHAHashGeneratorServiceTest : BaseTest
    {
        #region Fields

        private IHashGeneratorService _sHAHashGeneratorService;

        #endregion

        public SHAHashGeneratorServiceTest()
            : base(ObjectResolverType.Composite)
        {

        }

        #region Settings

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _sHAHashGeneratorService = new SHAHashGeneratorService();
        }

        #endregion

        #region Tests
        
        [TestMethod]
        public void ShouldGetHashedDataString()
        {
            string expectedhashedDataStr1 = "g6D+bEA71S0hqf7ZmPSMekzYfVndkt8tZ4rW16CPH48="; // => abc@1234
            string expectedhashedDataStr2 = "WcRkYtw40nBl4pZdjZskWFQ+gQpqRxXuZRt81NK6VcU="; // => def@1234
            string expectedhashedDataStr3 = "4elBWasU1RAUchg1PoHg2pQnVcOsT4q1Jx56fN/NNso="; // => ghi@1234
            string expectedhashedDataStr4 = "5+TgeuNX5XiS5rjujpH1tSjfu/ZdAPYYTrD8hMgipB0="; // => jkl@1234
            string value1 = "abc@1234";
            string value2 = "def@1234";
            string value3 = "ghi@1234";
            string value4 = "jkl@1234";
            
            var hashedDataStr1 = _sHAHashGeneratorService.GetHashedDataString(value1);
            var hashedDataStr2 = _sHAHashGeneratorService.GetHashedDataString(value2);
            var hashedDataStr3 = _sHAHashGeneratorService.GetHashedDataString(value3);
            var hashedDataStr4 = _sHAHashGeneratorService.GetHashedDataString(value4);

            Assert.AreEqual(expectedhashedDataStr1,hashedDataStr1);
            Assert.AreEqual(expectedhashedDataStr2, hashedDataStr2);
            Assert.AreEqual(expectedhashedDataStr3, hashedDataStr3);
            Assert.AreEqual(expectedhashedDataStr4, hashedDataStr4);
        }

        #endregion
    }
}
