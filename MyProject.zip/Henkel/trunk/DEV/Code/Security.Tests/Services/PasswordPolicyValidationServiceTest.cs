﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Henkel.Business.Security.Resources;
using Henkel.Business.Security.Services;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.SupportForTests.Model;
using Henkel.Common.SupportForTests.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Business.Security.Tests.Services
{
    [TestClass]
    public class PasswordPolicyValidationServiceTest : BaseTest
    {
        #region Fields
        IPasswordPolicyValidationService _passwordPolicyValidationService;
        #endregion

        public PasswordPolicyValidationServiceTest()
            : base(ObjectResolverType.Composite)
        {

        }

        #region Settings

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _passwordPolicyValidationService = ObjectLocator.GetObject<IPasswordPolicyValidationService>();
        }

        #endregion

        #region Tests
        
        #region Positive tests

        [TestMethod]
        public void ShouldValidatePasswordWithAllSatisfiedCondition()
        {
            var password = "Abc@1234";
            _passwordPolicyValidationService.Validate(password);
        }

        #endregion
        
        #region Negetive tests

        [TestMethod]
        public void ShouldThrowErrorForNullPassword()
        {
            string password = null;
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.PasswordCanNotBeEmpty, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForEmptyPassword()
        {
            string password = string.Empty;
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.PasswordCanNotBeEmpty, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForPasswordWithWhiteSpace()
        {
            string password = "          ";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.PasswordCanNotBeEmpty, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForPasswordLengthLessThan8()
        {
            var password = "Abc@123";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForPasswordLengthGreaterThan15()
        {
            var password = "Abc@1234567890123456";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForPasswordWithoutAnyLowerCaseCharacter()
        {
            var password = "ABC@1234";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }


        [TestMethod]
        public void ShouldThrowErrorForPasswordWithoutAnyUpperCaseCharacter()
        {
            var password = "abc@1234";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }


        [TestMethod]
        public void ShouldThrowErrorForPasswordWithoutAnyNumericCharacter()
        {
            var password = "Abcd@Xyz";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }


        [TestMethod]
        public void ShouldThrowErrorForPasswordWithoutAnySpecialCharacter()
        {
            var password = "Abcd1234";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForPasswordWithSpaceInBetween()
        {
            var password = "Abc @1234";
            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => _passwordPolicyValidationService.Validate(password));
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.InvalidPasswordFormatAsPerPasswordPolicy, exception.Message);
        }
        #endregion

        #endregion

    }
}
