﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.Model;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Assembler;
using Henkel.Common.SupportForTests.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Business.Security.Tests.Assembler
{
    [TestClass]
    public class UserAssemblerTest : BaseTest
    {
        IAssembler<User, UserDto> _userAssembler;

        public UserAssemblerTest()
            : base(ObjectResolverType.Composite)
        {

        }

        [TestInitialize]
        public void TestInitialize()
        {
            base.Initialize();
            _userAssembler = ObjectLocator.GetObject<IAssembler<User, UserDto>>();
        }

        [TestMethod]
        public void ShouldGetEntityFromDto()
        {
            var userDto = GetDefaultUserDto();
            var user = _userAssembler.GetEntityFromDto(userDto);

            Assert.IsNotNull(user);
            Assert.AreEqual(userDto.UserId, user.Id);
            Assert.AreEqual(userDto.CustomerId, user.CustomerId);
            Assert.AreEqual(userDto.LoginId, user.LoginId);
            Assert.AreEqual(true, user.IsActive);
            Assert.AreEqual(false, user.IsDeleted);
        }

        [TestMethod]
        public void ShouldGetDtoFromEntity()
        {
            var user = GetDefaultUser();
            var userDto = _userAssembler.GetDtoFromEntity(user);

            Assert.IsNotNull(userDto);
            Assert.AreEqual(user.Id, userDto.UserId);
            Assert.AreEqual(user.CustomerId, userDto.CustomerId);
            Assert.AreEqual(user.LoginId, userDto.LoginId);
            Assert.AreEqual(user.IsActive, userDto.IsActive);
            Assert.AreEqual(user.IsDeleted, userDto.IsDeleted);
            Assert.AreEqual(user.CreatedBy, userDto.CreatedBy);
            Assert.AreEqual(user.CreatedOn, userDto.CreatedOn);
            Assert.AreEqual(user.LastModifiedBy, userDto.LastModifiedBy);
            Assert.AreEqual(user.LastModifiedOn, userDto.LastModifiedOn);
        }

        [TestMethod]
        public void ShouldUpdateEntityFromDto()
        {
            var userDto = GetDefaultUserDto();
            var user = GetDefaultUser();
            _userAssembler.UpdateEntityFromDto(user, userDto);

            Assert.IsNotNull(user);
            Assert.AreEqual(userDto.LoginId, user.LoginId);
            Assert.AreEqual(true, user.IsActive);
            Assert.AreEqual(false, user.IsDeleted);
        }


        private static UserDto GetDefaultUserDto()
        {
            return new UserDto
            {
                UserId = Guid.NewGuid(),
                CustomerId = CustomerId,
                LoginId = "ABCD",
                IsActive = true,
                IsDeleted = false,
                CreatedOn = DateTime.Now,
                CreatedBy = "System",
                LastModifiedBy = "System",
                LastModifiedOn = DateTime.Now
            };
        }

        private static User GetDefaultUser()
        {
            return new User
            {
                Id = Guid.NewGuid(),
                LoginId = "ABCD",
                IsActive = true,
                IsDeleted = false,
                CreatedOn = DateTime.Now,
                CreatedBy = "System2",
                LastModifiedBy = "System2",
                LastModifiedOn = DateTime.Now
            };
        }
    }
}
