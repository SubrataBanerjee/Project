﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using Henkel.Business.Security.Model;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.SupportForTests.Utils;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.SupportForTests.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Business.Security.Repository;
using Rhino.Mocks;
using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Security.Services;
using Henkel.Business.Security.Services.Impl;

namespace Henkel.Business.Security.Tests.Model
{
    [TestClass]
    public class UserTest : BaseTest
    {
        #region Field

        private IUserRepository _userRepository;

        #endregion
        #region Constructor

        public UserTest() : base(ObjectResolverType.InMemory)
        {

        }

        #endregion

        #region Setting

        [TestInitialize]
        public void TestInitilize()
        {
            Initialize();

            _userRepository = MockRepository.GenerateMock<IUserRepository>();
            
            var emailService = MockRepository.GenerateMock<IEmailingService>();
            emailService.Expect(x => x.SendEmail(null, null)).IgnoreArguments().Repeat.Any();
            ObjectLocator.RegisterObject<IEmailingService>(emailService);

            ObjectLocator.RegisterObject<IHashGeneratorService>(new SHAHashGeneratorService());

            IPasswordValidationService passwordValidationService = MockRepository.GenerateMock<IPasswordValidationService>();
            passwordValidationService.Expect(x => x.Validate(null, null, null, null)).IgnoreArguments().Repeat.Any();
            ObjectLocator.RegisterObject<IPasswordValidationService>(passwordValidationService);
        }

        #endregion

        #region tests

        #region Negetive Tests

        [TestMethod]
        public void ShouldThrowErrorForValidateForAddWithEmptyUserName()
        {
            var user = new User();
            user.LoginId = string.Empty;
            _userRepository.Expect(x => x.Add(null)).IgnoreArguments().Repeat.Any().Return(user);
            ObjectLocator.RegisterObject<IUserRepository>(_userRepository);

            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => user.Add());
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.UserNameCanNotBeEmpty, exception.Message);
        }

        [TestMethod]
        public void ShouldThrowErrorForValidateForUpdateWithEmptyUserName()
        {
            var user = new User();
            user.LoginId = string.Empty;
            _userRepository.Expect(x => x.Update(user)).IgnoreArguments().Repeat.Any();
            ObjectLocator.RegisterObject<IUserRepository>(_userRepository);

            var exception = TestHelperUtil.AssertThrows<ValidationException>(() => user.Update());
            Assert.IsNotNull(exception);
            Assert.IsTrue(exception is ValidationException);
            Assert.AreEqual(SecurityErrorMessage.UserNameCanNotBeEmpty, exception.Message);
        }

        #endregion

        #region Positive tests

        public void ShouldNotThrowErrorForValidateForAddWithValidData()
        {
            var user = new User();
            user.Id = Guid.NewGuid();
            user.LoginId = "ABC";

            _userRepository.Expect(x => x.Add(null)).IgnoreArguments().Repeat.Any().Return(user);
            ObjectLocator.RegisterObject<IUserRepository>(_userRepository);

            user.Add();
        }

        public void ShouldNotThrowErrorForValidateForUpdateWithValidData()
        {
            var user = new User();
            user.LoginId = "ABC";
            _userRepository.Expect(x => x.Update(null)).IgnoreArguments().Repeat.Any();
            ObjectLocator.RegisterObject<IUserRepository>(_userRepository);

            user.Update();
        }

        [TestMethod]
        public void ShouldMarkAsEnabled()
        {
            var user = new User();
            user.IsActive = false;
            user.MarkAsEnable();

            Assert.AreEqual(true, user.IsActive);
        }

        [TestMethod]
        public void ShouldMarkAsDisabled()
        {
            var user = new User();
            user.IsActive = true;
            user.MarkAsDisable();

            Assert.AreEqual(false, user.IsActive);
        }

        #endregion


        #endregion
    }
}
