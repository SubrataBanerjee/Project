﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Caching.Model
{
    public class CachingOptions
    {
        public CacheType CacheType { get; set; }
        public CacheItemPolicy CachePolicy { get; set; }
    }
}
