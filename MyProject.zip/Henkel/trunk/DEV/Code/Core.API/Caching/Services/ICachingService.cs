﻿using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Caching.Services
{
    public interface ICachingService : IBusinessService
    {
        T Get<T>(string cacheKey, Func<T> fallback, CachingOptions options) where T : class;
        void Remove(string key, CacheType cacheType);
        void RemoveAll(CacheType cacheType);
    }
}
