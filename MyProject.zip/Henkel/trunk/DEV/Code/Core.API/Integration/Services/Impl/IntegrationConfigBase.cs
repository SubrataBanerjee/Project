﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Integration.Services.Impl
{
    public abstract class IntegrationConfigBase : IRegisterWithUnityService
    {
        public abstract void RegisterTypes(IUnityContainer container);

        /// <summary>
        /// Property is used to get the Customer Suffix. Default value is Empty.
        /// This must be override in all the Customization projects with the hardcoded value of Customer Suffix coloum in AdminDB.
        /// </summary>
        protected virtual string CustomerSuffix
        {
            get { return string.Empty; }
        }

        /// <summary>
        /// Method used to get the Registry name for each service in Unity.
        /// </summary>
        /// <param name="registerName">service name specified for registration</param>
        /// <returns>Modified service name prefix with Customer Suffix value</returns>
        protected virtual string GetRegistryName(string registerName)
        {
            return GetRegistryName(CustomerSuffix, registerName);
        }


        /// <summary>
        /// Method used to get the Registry name for each service in Unity.
        /// </summary>
        /// <param name="customerSuffix">This is either blank value (for Product) or else Customer Suffix value in AdminDB for each individual customer</param>
        /// <param name="registerName"></param>
        /// <returns>Modified service name prefix with Customer Suffix value</returns>
        public static string GetRegistryName(string customerSuffix, string registerName)
        {
            if (string.IsNullOrWhiteSpace(customerSuffix))
                return registerName;
            if (!customerSuffix.StartsWith("#"))
                customerSuffix = GetCustomerPrefixForUnity(customerSuffix);
            registerName = string.Format("{0}{1}", customerSuffix, registerName);
            if (string.IsNullOrWhiteSpace(registerName))
                throw new Exception("Can not able to register Service in Unity. Customer Suffix and Service name both can not be empty.");
            return registerName;
        }

        /// <summary>
        /// Method used to manupulate the value of Customer Suffix in AdminDB start with '#' and end with '_' character.
        /// </summary>
        /// <param name="customerSuffix">This is either blank value (for Product) or else Customer Suffix value in AdminDB for each individual customer</param>
        /// <returns>emty string if prefix is blank elase return manupulated value of Customer Suffix in AdminDB start with '#' and end with '_' character.</returns>
        public static string GetCustomerPrefixForUnity(string customerSuffix)
        {
            if (string.IsNullOrWhiteSpace(customerSuffix))
                return string.Empty;
            return string.Format("#{0}_", customerSuffix.ToUpper());
        }
    }
}
