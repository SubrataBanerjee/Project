﻿using Microsoft.Practices.Unity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Integration.Services
{
    public interface IRegisterWithUnityService
    {
        void RegisterTypes(IUnityContainer container);
    }
}
