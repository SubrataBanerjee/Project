﻿using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Services
{
    public interface ICustomerAdminService : IBusinessService
    {
        CustomerAdminDetail GetCustomerAdminDetail();
        IList<CustomerAdminDetail> GetAllCustomerAdminDetails();
    }
}
