﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Henkel.Common.Core.API.Model
{
    public class CustomerAdminDetail
    {
        public virtual Guid CustomerId { get; set; }
        public virtual string Name { get; set; }
        public virtual string ConnectionString { get; set; }
        public virtual string SubDomain { get; set; }
        public virtual string Suffix { get; set; }
        public virtual IDictionary<string, string> CustomerAdminConfigs { get; set; }

        public virtual string GetConfigValue(string key)
        {
            var value = string.Empty;
            if (CustomerAdminConfigs != null && CustomerAdminConfigs.ContainsKey(key))
            {
                value = CustomerAdminConfigs[key];
            }
            return value;
        }
    }
}
