﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Utils
{
    public class CustomerAdminUtil
    {
        #region Public Methods

        public static CustomerAdminDetail GetCustomerAdminDetail()
        {
            var svc = ObjectLocator.GetService<ICustomerAdminService>();
            return svc.GetCustomerAdminDetail();
        }

        public static IList<CustomerAdminDetail> GetAllCustomerAdminDetails()
        {
            var svc = ObjectLocator.GetService<ICustomerAdminService>();
            return svc.GetAllCustomerAdminDetails();
        }

        #endregion
    }
}
