﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Utils
{
    public class ThreadUtils
    {
        public static void SetThreadData(Guid customerId, string customerName = null, Guid? userId = null, string userName = null, string ipAddress = null, string customData = null)
        {
            SetDataInThreadSlot("Context_CustomerId", customerId);
            
            if(customerName != null)
                SetDataInThreadSlot("Context_CustomerName", customerName);

            if(userId.HasValue)
                SetDataInThreadSlot("Context_UserId", userId.Value);

            if(userName != null)
                SetDataInThreadSlot("Context_UserName", userName);
            
            if(ipAddress != null)
                SetDataInThreadSlot("Context_IPAddress", ipAddress);

            if(customData != null)
                SetDataInThreadSlot("Context_CustomData", customData);
        }

        private static void SetDataInThreadSlot(string slotName, object data)
        {
            var threadDataStoreSlot = Thread.GetNamedDataSlot(slotName);
            Thread.SetData(threadDataStoreSlot, data);
        }
    }
}
