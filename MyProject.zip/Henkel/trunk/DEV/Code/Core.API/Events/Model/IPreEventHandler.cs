﻿using Henkel.Common.Core.API.Model;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Events.Model
{
    public interface IPreEventHandler<in T> where T : IEntity
    {
        void Handle(string eventType, T obj, NameValueCollection formCollection = null);
    }
}
