﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Events.Model
{
    public interface IEventHandler<out T> where T : BaseEvent
    {
        void Handle(object @event);
    }
}
