﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace Henkel.Common.Core.API.Events.Model
{
    [Serializable]
    public abstract class BaseEvent : IEvent
    {
        [NonSerialized]
        private Dictionary<IEntity, Action<BaseEvent, IEntity>> _actions;
        protected BaseEvent()
        {
            Actions = new Dictionary<IEntity, Action<BaseEvent, IEntity>>();

            var userContextService = ObjectLocator.GetService<IUserContextService>();
            CustomerId = userContextService.CustomerId;
            UserId = userContextService.CurrentUserId;
            UserName = userContextService.CurrentUserName;
        }

        [XmlIgnore]
        public Dictionary<IEntity, Action<BaseEvent, IEntity>> Actions
        {
            get { return _actions; }
            set { _actions = value; }
        }

        public Guid Id { get; set; }

        public Guid CustomerId { get; set; }

        public Guid UserId { get; set; }

        public string UserName { get; set; }

        public BaseEvent Add(IEntity obj, Action<BaseEvent, IEntity> action)
        {
            Actions.Add(obj, action);
            return this;
        }
    }
}
