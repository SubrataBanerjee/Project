﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.DTO.Pagination
{
    public class PageInfo
    {
        public int PageSize { get; set; }
        public int StartRow { get; set; }
        public string SortField { get; set; }
        public bool SortDirection { get; set; }

        public PageInfo(int pageSize = -1, int startRow = 0, string sortField = "", bool sortDirection = true)
        {
            PageSize = pageSize;
            StartRow = startRow;
            SortField = sortField;
            SortDirection = sortDirection;
        }
    }
}
