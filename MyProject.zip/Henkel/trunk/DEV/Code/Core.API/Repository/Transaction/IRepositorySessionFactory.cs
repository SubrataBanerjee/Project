﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Common.Core.API.Repository.Transaction
{
    public interface IRepositorySessionFactory
    {
        IRepositorySession GetNewSession(bool isReadWrite, bool actionFilterEnabled, Guid? customerId, IsolationLevel isolationLevel = IsolationLevel.ReadCommitted);
        bool RepositorySessionExists();
        void Unbind();
    }
}
