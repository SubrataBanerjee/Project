﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Resources
{
    public static class SecurityAdminConfigKey
    {
        public const string FailureLoginAttemptLimit = "FailureLoginAttemptLimit";
        public const string DefaultUserPassword = "DefaultUserPassword";
        public const string PasswordPolicy = "PasswordPolicy";
        public const string PasswordHistoryLimit = "PasswordHistoryLimit";
    }
}
