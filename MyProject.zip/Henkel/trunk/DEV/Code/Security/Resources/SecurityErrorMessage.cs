﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Resources
{
    public static class SecurityErrorMessage
    {
        public const string InvalidEmailIdFormat = "Key_InvalidEmailIdFormat";

        //Resource Related Errors
        public const string InvalidResourceIdForUpdate = "Key_InvalidResourceIdForUpdate";
        public const string CanNotCreateLoginAsResourceLoginAlreadyExist = "Key_CanNotCreateLoginAsResourceLoginAlreadyCreated";


        //User Related Errors
        public const string UserNameCanNotBeEmpty = "Key_UserNameCanNotBeEmpty"; //"User Name can not be empty."
        public const string UserLoginIdAlreadyExist = "Key_UserLoginIdAlreadyExist";
        public const string InvalidUserIdForUpdate = "Key_InvalidUserIdForUpdate"; //"Invalid UserId specified for Update operation."
        public const string UsernameOrPasswordIsIncorrect = "Key_UsernameOrPasswordIsIncorrect"; //"The user name or password provided is incorrect.";
        public const string NewPasswordAndConfirmPasswordNotMatched = "Key_NewPasswordAndConfirmPasswordNotMatched"; //"Specified new password and confirm password are not matched.";
        public const string UserIsLocked = "Key_UserIsLocked"; //"Can't Login into the system. User is Locked.";
        public const string UserIsDisabled = "Key_UserIsDisabled"; //"Can't Login into the system. User is Disabled.";
        public const string PasswordCanNotBeEmpty = "Key_PasswordCanNotBeEmpty"; //"Password can not be empty."
        public const string SpecifiedEmailIdIsNotPresent = "Key_SpecifiedEmailIdIsNotPresent"; // Specified EmailId is not present in the system.

        public const string InvalidPasswordFormatAsPerPasswordPolicy = "GenericKey_InvalidPasswordFormatAsPerPasswordPolicy"; // "Specified Password does not match with password policy : {0}." //where {0} -> is the description of Policy
        public const string NewPasswordShouldNotBeSameAsLastUsedPassword = "GenericKey_NewPasswordShouldNotBeSameAsLastUsedPassword"; // "Specified Password should not be same as last {0} number of used passwords." //Where {0} -> is the number of last passwords need to verify from History

        //Resource Related Errors
        public const string ResourceCodeCanNotBeEmpty = "Key_ResourceCodeCanNotBeEmpty";
        public const string ResourceEmailCanNotBeEmpty = "Key_ResourceEmailCanNotBeEmpty";
        public const string ResourceCodeAlreadyExist = "Key_ResourceCodeAlreadyExist";
        public const string ResourceEmailIdAlreadyExist = "Key_ResourceEmailIdAlreadyExist";

        //Role Related Errors
        public const string RoleNameCanNotBeEmpty = "Key_RoleNameCanNotBeEmpty";
        public const string RoleNameAlreadyExist = "Key_RoleNameAlreadyExist";
        public const string UserIdMustBeUniqueToUpdateSudoRole = "Key_UserIdMustBeUniqueToUpdateSudoRole";
        public const string RoleIdMustBeUniqueToUpdateSudoRole = "Key_RoleIdMustBeUniqueToUpdateSudoRole";
        public const string RoleNotDefineForTheUser = "Key_RoleNotDefineForTheUser";
        public const string InvalidUserIdForDetachedRoleFromUser = "Key_InvalidUserIdForDetachedRoleFromUser";
        public const string InvalidRoleIdForDetachedRoleFromUser = "Key_InvalidRoleIdForDetachedRoleFromUser";
        public const string InvalidUserIdToGetSudoRole = "Key_InvalidUserIdToGetSudoRole";
        public const string InvalidUserIdOrRoleIdToGetSudoRole = "Key_InvalidUserIdOrRoleIdToGetSudoRole";




        
    }
}
