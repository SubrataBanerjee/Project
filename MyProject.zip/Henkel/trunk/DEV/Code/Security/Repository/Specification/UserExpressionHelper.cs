﻿using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Business.Security.Model;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.Expressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.Specification
{
    public static class UserExpressionHelper
    {
        public static Expression<Func<User, bool>> GetSearchExpression(this UserSearchCriteria userSearchCriteria)
        {
            var expression = PredicateBuilder.True<User>();
            if (userSearchCriteria.IsActive.HasValue)
                expression = expression.AndAlso(x => x.IsActive == userSearchCriteria.IsActive.Value);

            if (userSearchCriteria.UserId.HasValue)
                expression = expression.AndAlso(x => x.Id == userSearchCriteria.UserId.Value);

            if (userSearchCriteria.UserName != null)
                expression = expression.AndAlso(x => x.LoginId.Contains(userSearchCriteria.UserName));

            return expression;
        }

        public static Expression<Func<User, object>> GetUserSortExpression(this PageInfo pageInfo)
        {
            var ss = PredicateBuilder.True<User>();
            switch (pageInfo.SortField)
            {
                case "Id":
                    { return x => x.Id; }
                case "Name":
                    { return x => x.LoginId; }
                case "IsAcive":
                    { return x => x.IsActive; }
                case "CreatedBy":
                    { return x => x.CreatedBy; }
                case "CreatedOn":
                    { return x => x.CreatedOn; }
                case "LastModifiedBy":
                    { return x => x.LastModifiedBy; }
                case "LastModifiedOn":
                    { return x => x.LastModifiedOn; }
                default:
                    { return x => x.CreatedOn; }
            }
        }
    }
}
