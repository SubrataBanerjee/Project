﻿using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Business.Security.Model;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.Expressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.Specification
{
    public static class RoleExpressionHelper
    {
        public static Expression<Func<Role, bool>> GetSearchExpression(this RoleSearchCriteria roleSearchCriteria)
        {
            var expression = PredicateBuilder.True<Role>();
            if (roleSearchCriteria.IsActive.HasValue)
                expression = expression.AndAlso(x => x.IsActive == roleSearchCriteria.IsActive.Value);
            
            if(roleSearchCriteria.RoleId.HasValue)
                expression = expression.AndAlso(x => x.Id == roleSearchCriteria.RoleId.Value);
            
            if (roleSearchCriteria.RoleName != null)
                expression = expression.AndAlso(x => x.Name.Contains(roleSearchCriteria.RoleName));

            if (roleSearchCriteria.UserId.HasValue)
                expression = expression.AndAlso(x => x.RoleUserMaps.Any(y => y.User.Id == roleSearchCriteria.UserId.Value));

            if (roleSearchCriteria.UserName != null)
                expression = expression.AndAlso(x => x.RoleUserMaps.Any(y=>y.User.LoginId.Contains(roleSearchCriteria.UserName)));

            return expression;
        }

        public static Expression<Func<Role, object>> GetRoleSortExpression(this PageInfo pageInfo)
        {
            var ss = PredicateBuilder.True<Role>();
            switch (pageInfo.SortField)
            {
                case "Id":
                    { return x => x.Id; }
                case "Name":
                    { return x => x.Name; }
                case "IsAcive":
                    { return x => x.IsActive; }
                case "CreatedBy":
                    { return x => x.CreatedBy; }
                case "CreatedOn":
                    { return x => x.CreatedOn; }
                case "LastModifiedBy":
                    { return x => x.LastModifiedBy; }
                case "LastModifiedOn":
                    { return x => x.LastModifiedOn; }
                default:
                    { return x => x.CreatedOn; }
            }
        }
    }
}
