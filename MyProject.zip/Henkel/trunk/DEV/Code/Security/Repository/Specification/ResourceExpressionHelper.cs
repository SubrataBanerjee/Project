﻿using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Business.Security.Model;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.Expressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.Specification
{
    public static class ResourceExpressionHelper
    {
        public static Expression<Func<Resource, bool>> GetSearchExpression(this ResourceSearchCriteria resourceSearchCriteria)
        {
            var expression = PredicateBuilder.True<Resource>();
            if (resourceSearchCriteria.IsActive.HasValue)
                expression = expression.AndAlso(x => x.IsActive == resourceSearchCriteria.IsActive.Value);

            if (resourceSearchCriteria.ResourceId.HasValue)
                expression = expression.AndAlso(x => x.Id == resourceSearchCriteria.ResourceId.Value);

            if (resourceSearchCriteria.ResourceCode != null)
                expression = expression.AndAlso(x => x.Code.Contains(resourceSearchCriteria.ResourceCode));

            return expression;
        }

        public static Expression<Func<Resource, object>> GetResourceSortExpression(this PageInfo pageInfo)
        {
            var ss = PredicateBuilder.True<Resource>();
            switch (pageInfo.SortField)
            {
                case "Id":
                    { return x => x.Id; }
                case "Code":
                    { return x => x.Code; }
                case "IsAcive":
                    { return x => x.IsActive; }
                case "CreatedBy":
                    { return x => x.CreatedBy; }
                case "CreatedOn":
                    { return x => x.CreatedOn; }
                case "LastModifiedBy":
                    { return x => x.LastModifiedBy; }
                case "LastModifiedOn":
                    { return x => x.LastModifiedOn; }
                default:
                    { return x => x.CreatedOn; }
            }
        }
    }
}
