﻿using Henkel.Business.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class UserConfiguration : EntityTypeConfiguration<User>, IEntityConfiguration
    {
        public UserConfiguration()
        {
            ToTable("Cust_User");
            HasKey(x => new { x.Id, x.CustomerId });

            Property(x => x.LoginId).IsRequired();
            Property(x => x.Password);
            Property(x => x.IsActive).IsRequired();
            Property(x => x.Locked);
            Property(x => x.ChangePwdOnLogin);
            Property(x => x.FailureLoginAttempt);
            Property(x => x.IsSuperAdmin);
            Property(x => x.CreatedBy).HasMaxLength(50).IsUnicode(true);
            Property(x => x.CreatedOn);
            Property(x => x.LastModifiedBy).HasMaxLength(50).IsUnicode(true);
            Property(x => x.LastModifiedOn);
            Property(x => x.IsDeleted).IsRequired();
            Ignore(e => e.UnHashedNewPassword);

            HasMany(x => x.PasswordHistories)
                .WithRequired()
                .HasForeignKey(y => new { y.UserId, y.CustomerId });

            HasMany(x => x.RoleUserMaps)
                .WithRequired()
                .HasForeignKey(y => new { y.UserId, y.CustomerId });

            HasMany(x => x.RoleFeatureUserMaps)
                .WithRequired()
                .HasForeignKey(y => new { y.UserId, y.CustomerId });
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
