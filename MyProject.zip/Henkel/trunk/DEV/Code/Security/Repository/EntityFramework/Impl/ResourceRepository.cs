﻿using Henkel.Business.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.EntityFramework.Impl
{
    public class ResourceRepository : EFReadWriteRepository<Resource>, IResourceRepository
    {
    }
}
