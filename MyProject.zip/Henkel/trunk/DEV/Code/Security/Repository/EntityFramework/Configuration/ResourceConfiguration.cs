﻿using Henkel.Business.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class ResourceConfiguration : EntityTypeConfiguration<Resource>, IEntityConfiguration
    {
        public ResourceConfiguration()
        {
            ToTable("Cust_Resource");

            HasKey(x => new { x.Id, x.CustomerId });
            
            Property(x => x.Code);
            Property(x => x.IsActive);
            Property(x => x.IsDeleted);
            Property(x => x.CreatedBy);
            Property(x => x.CreatedOn);
            Property(x => x.LastModifiedOn);
            Property(x => x.LastModifiedBy);
            HasOptional(x => x.User).WithMany().HasForeignKey(y => new { y.UserId, y.CustomerId });
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
