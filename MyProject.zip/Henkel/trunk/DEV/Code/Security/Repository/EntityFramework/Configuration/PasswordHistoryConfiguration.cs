﻿using Henkel.Business.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class PasswordHistoryConfiguration : EntityTypeConfiguration<PasswordHistory>, IEntityConfiguration
    {
        public PasswordHistoryConfiguration()
        {
            ToTable("Cust_PasswordHistory");
            HasKey(x => new { x.Id, x.CustomerId });
            
            Property(x => x.Password);
            Property(x => x.IsActive);
            Property(x => x.CreatedBy);
            Property(x => x.CreatedOn);
            HasRequired( x => x.User).WithMany().HasForeignKey( y => new { y.UserId, y.CustomerId});
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
