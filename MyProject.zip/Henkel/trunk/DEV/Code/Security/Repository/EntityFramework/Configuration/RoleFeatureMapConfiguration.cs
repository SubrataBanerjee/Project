﻿using Henkel.Business.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class RoleFeatureMapConfiguration : EntityTypeConfiguration<RoleFeatureMap>, IEntityConfiguration
    {
        public RoleFeatureMapConfiguration()
        {
            ToTable("Cust_RoleFeatureMap");
            HasKey(x => new {x.Id, x.CustomerId });

            HasRequired(x => x.Role).WithMany().HasForeignKey(y => new { y.RoleId, y.CustomerId });
            HasRequired(x => x.Feature).WithMany().HasForeignKey(y => y.FeatureId);

            Property(x => x.Add);
            Property(x => x.Edit);
            Property(x => x.View);
            Property(x => x.Delete);
            Property(x => x.Print);
            Property(x => x.Execute);
            Property(x => x.Activate);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
