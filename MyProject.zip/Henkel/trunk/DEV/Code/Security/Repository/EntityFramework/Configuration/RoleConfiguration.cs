﻿using Henkel.Business.Security.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class RoleConfiguration : EntityTypeConfiguration<Role>, IEntityConfiguration
    {
        public RoleConfiguration()
        {
            ToTable("Cust_Role");
            HasKey(x => new { x.Id, x.CustomerId });

            Property(x => x.Name).IsRequired();
            Property(x => x.IsActive).IsRequired();
            
            Property(x => x.CreatedBy).HasMaxLength(50).IsUnicode(true);
            Property(x => x.CreatedOn);
            Property(x => x.LastModifiedBy).HasMaxLength(50).IsUnicode(true);
            Property(x => x.LastModifiedOn);
            Property(x => x.IsDeleted).IsRequired();

            HasMany(x => x.RoleUserMaps)
                .WithRequired()
                .HasForeignKey(y => new { y.RoleId, y.CustomerId });

            HasMany(x => x.RoleFeatureMaps)
                .WithRequired()
                .HasForeignKey(y => new { y.RoleId, y.CustomerId });

            HasMany(x => x.RoleFeatureUserMaps)
                .WithRequired()
                .HasForeignKey(y => new { y.RoleId, y.CustomerId });
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
