﻿using Microsoft.Practices.Unity;
using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.Services;
using Henkel.Business.Security.Assembler;
using Henkel.Business.Security.Model;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Repository.EntityFramework.Impl;
using Henkel.Business.Security.Services;
using Henkel.Business.Security.Services.Impl;
using Henkel.Common.Core.API.Integration.Services.Impl;
using Henkel.Common.Core.Assembler;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Security.Notification.Resource;
using Henkel.Business.Security.Notification.Services.Impl;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Repository.EntityFramework.Impl;

namespace Henkel.Business.Security.Integration
{
    public class SecurityIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterRepository(container);
            RegisterAssemblers(container);
            RegisterServices(container);
            RegisterEmailTokens(container);
        }

        private void RegisterRepository(IUnityContainer container)
        {
            container.RegisterType<IUserRepository, UserRepository>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceRepository, ResourceRepository>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<Role>, EFReadWriteRepository<Role>>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<Feature>, EFReadWriteRepository<Feature>>(new ContainerControlledLifetimeManager());
        }

        private void RegisterAssemblers(IUnityContainer container)
        {
            container.RegisterType<IAssembler<User, UserDto>, UserAssembler>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAssembler<Resource, ResourceDto>, ResourceAssembler>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAssembler<Role, RoleDto>, RoleAssembler>(new ContainerControlledLifetimeManager());
            container.RegisterType<IAssembler<Role, SudoRoleDto>, SudoRoleAssembler>(new ContainerControlledLifetimeManager());
        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<IHashGeneratorService, SHAHashGeneratorService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUserManagementService, UserManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUserUniquenessValidationService, UserUniquenessValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceManagementService, ResourceManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceUniquenessValidationService, ResourceUniquenessValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IUserAuthenticationService, UserAuthenticationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IPasswordPolicyValidationService, PasswordPolicyValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IPasswordHistoryValidationService, PasswordHistoryValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IPasswordValidationService, PasswordValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IResourceManagementService, ResourceManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IRoleManagementService, RoleManagementService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IRoleUniquenessValidationService, RoleUniquenessValidationService>(new ContainerControlledLifetimeManager());
        }

        private void RegisterEmailTokens(IUnityContainer container)
        {
            container.RegisterType<IEmailTokenProvider, UserEmailTokenProvider>(EmailTokenRegisterKey.UserEmailTokenProvider, new ContainerControlledLifetimeManager());
        }
    }
}
