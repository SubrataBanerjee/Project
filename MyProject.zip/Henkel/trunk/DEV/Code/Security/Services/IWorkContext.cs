﻿using Henkel.Business.Security.API.DTO;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    /// <summary>
    /// Work context
    /// </summary>
    public interface IWorkContext : IBusinessService
    {
        /// <summary>
        /// Gets or sets the current customer
        /// </summary>
        UserToken CurrentUser { get; set; }
        
        /// <summary>
        /// Get or set value indicating whether we're in admin area
        /// </summary>
        bool IsAdmin { get; set; }
    }
}
