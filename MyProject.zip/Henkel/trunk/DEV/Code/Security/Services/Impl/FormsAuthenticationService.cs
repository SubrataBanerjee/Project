﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.Services;
using Henkel.Business.Security.Repository;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Web;
using System.Web.Security;
using System.Collections.Generic;
using System.Linq;
using Henkel.Business.Security.Model;

namespace Henkel.Business.Security.Services.Impl
{
    /// <summary>
    /// Authentication service
    /// </summary>
    public partial class FormsAuthenticationService : TransactionSupportBaseService, IAuthenticationService
    {
        private readonly HttpContextBase _httpContext;
        private readonly TimeSpan _expirationTimeSpan;
        private UserToken _cachedUser;

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="httpContext">HTTP context</param>
        public FormsAuthenticationService(HttpContextBase httpContext)
        {
            this._httpContext = httpContext;
            this._expirationTimeSpan = FormsAuthentication.Timeout;
        }

        public FormsAuthenticationService()
        {
            // TODO: Complete member initialization
        }


        public virtual void SignIn(UserToken user, bool createPersistentCookie)
        {
            var now = DateTime.UtcNow.ToLocalTime();

            var ticket = new FormsAuthenticationTicket(
                1 /*version*/,
                user.UserName,
                now,
                now.Add(_expirationTimeSpan),
                createPersistentCookie,
                user.UserName,
                FormsAuthentication.FormsCookiePath);

            var encryptedTicket = FormsAuthentication.Encrypt(ticket);

            var cookie = new HttpCookie(FormsAuthentication.FormsCookieName, encryptedTicket);
            cookie.HttpOnly = true;
            if (ticket.IsPersistent)
            {
                cookie.Expires = ticket.Expiration;
            }
            cookie.Secure = FormsAuthentication.RequireSSL;
            cookie.Path = FormsAuthentication.FormsCookiePath;
            if (FormsAuthentication.CookieDomain != null)
            {
                cookie.Domain = FormsAuthentication.CookieDomain;
            }

            _httpContext.Response.Cookies.Add(cookie);
            _cachedUser = user;
        }

        public virtual void SignOut()
        {
            _cachedUser = null;
            FormsAuthentication.SignOut();
        }

        public virtual UserToken GetAuthenticatedUser()
        {
            if (_cachedUser != null)
                return _cachedUser;

            if (_httpContext == null ||
                _httpContext.Request == null ||
                !_httpContext.Request.IsAuthenticated ||
                !(_httpContext.User.Identity is FormsIdentity))
            {
                return null;
            }

            var formsIdentity = (FormsIdentity)_httpContext.User.Identity;
            var user = GetAuthenticatedUserFromTicket(formsIdentity.Ticket);
            if (user != null && user.IsActive && !user.IsDeleted)
                _cachedUser = new UserToken
                {
                    UserName = user.LoginId,
                    CustomerId = user.CustomerId,
                    UserId = user.Id,
                    IsActive = user.IsActive,
                    IsDeleted = user.IsDeleted
                };
            return _cachedUser;
        }

        public virtual User GetAuthenticatedUserFromTicket(FormsAuthenticationTicket ticket)
        {
            if (ticket == null)
                throw new ArgumentNullException("ticket");

            var username = ticket.UserData;

            if (String.IsNullOrWhiteSpace(username))
                return null;

            var userRepository = ObjectLocator.GetObject<IUserRepository>();
            var user = userRepository.Find(x => x.LoginId == username).FirstOrDefault();
            return user;
        }
    }
}
