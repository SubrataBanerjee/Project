﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.Services;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Resources;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services.Impl
{
    public class UserAuthenticationService : TransactionSupportBaseService, IUserAuthenticationService
    {
        #region Fields

        private readonly IUserRepository _userRepository;

        #endregion

        #region Constructors

        public UserAuthenticationService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        #endregion

        #region Implementation of IUserAuthenticationService

        public UserToken SignIn(string loginId, string password, bool rememberMe = false)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.Find(x => x.LoginId == loginId).FirstOrDefault();
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.UsernameOrPasswordIsIncorrect);

                        user.ValidateAuthentication(password);
                        var token = user.GetToken();

                        var authenticationService = ObjectLocator.GetObject<IAuthenticationService>();
                        authenticationService.SignIn(token, rememberMe);

                        return token;
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                return new UserToken()
                {
                    SuccessLogin = false,
                    ErrorMessage = ex.Message
                };
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                return new UserToken()
                {
                    SuccessLogin = false,
                    ErrorMessage = CoreErrorMessage.ErrorProcessingRequest
                };
            }
        }

        public void SignOut()
        {
            try
            {
                var authenticationService = ObjectLocator.GetObject<IAuthenticationService>();
                authenticationService.SignOut();
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void ResetPassword(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.ResetPassword();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }


        public void ChangePassword(Guid userId, string oldPassword, string newPassword, string confirmPassword)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.ChangePassword(oldPassword, newPassword, confirmPassword);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }       
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }


        public void ForgotPassword(string emailId)
        {
            try
            {
                using(var session = RepositorySession)
                {
                    try
                    {
                        var resourceRepository = ObjectLocator.GetObject<IResourceRepository>();
                        var resource = resourceRepository.Find(x => x.Contact != null && x.Contact.Email == emailId && x.User != null).FirstOrDefault();
                        if (resource == null)
                            throw new ValidationException(SecurityErrorMessage.SpecifiedEmailIdIsNotPresent);

                        resource.User.ForgotPassword();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }



        public void LockUser(Guid userId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.Lock();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        
        public void UnlockUser(Guid userId)
        {
            try
            {
                using(var session  = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if (user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForUpdate);

                        user.Unlock();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        #endregion
    }
}
