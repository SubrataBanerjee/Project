﻿using Henkel.Business.Security.API.DTO;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Henkel.Business.Security.Services.Impl
{
    /// <summary>
    /// Work context for web application
    /// </summary>
    public partial class WebWorkContext : TransactionSupportBaseService, IWorkContext
    {
        #region Const

        private const string UserCookieName = "Henkel.User";

        #endregion

        #region Fields

        private readonly HttpContextBase _httpContext;
        private readonly IAuthenticationService _authenticationService;
        private UserToken _cachedUser;

        #endregion

        #region Ctor

        public WebWorkContext(HttpContextBase httpContext, IAuthenticationService authenticationService)
        {
            this._httpContext = httpContext;
            this._authenticationService = authenticationService;
        }

        #endregion

        #region Utilities

        protected virtual HttpCookie GetUserCookie()
        {
            if (_httpContext == null || _httpContext.Request == null)
                return null;

            return _httpContext.Request.Cookies[UserCookieName];
        }

        protected virtual void SetUserCookie(Guid UserGuid)
        {
            if (_httpContext != null && _httpContext.Response != null)
            {
                var cookie = new HttpCookie(UserCookieName);
                cookie.HttpOnly = true;
                cookie.Value = UserGuid.ToString();
                if (UserGuid == Guid.Empty)
                {
                    cookie.Expires = DateTime.Now.AddMonths(-1);
                }
                else
                {
                    int cookieExpires = 24 * 365; //TODO make configurable
                    cookie.Expires = DateTime.Now.AddHours(cookieExpires);
                }

                _httpContext.Response.Cookies.Remove(UserCookieName);
                _httpContext.Response.Cookies.Add(cookie);
            }
        }

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the current User
        /// </summary>
        public virtual UserToken CurrentUser
        {
            get
            {
                if (_cachedUser != null)
                    return _cachedUser;

                UserToken user = null;

                //registered user
                if (user == null || user.IsDeleted || !user.IsActive)
                {
                    user = _authenticationService.GetAuthenticatedUser();
                }

                //validation
                if (user != null && !user.IsDeleted && user.IsActive)
                {
                    SetUserCookie(user.UserId);
                    _cachedUser = user;
                }

                return _cachedUser;
            }
            set
            {
                SetUserCookie(value.UserId);
                _cachedUser = value;
            }
        }

        /// <summary>
        /// Get or set value indicating whether we're in admin area
        /// </summary>
        public virtual bool IsAdmin { get; set; }

        #endregion
    }
}
