﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.API.DTO.SearchCriteria;
using Henkel.Business.Security.API.Services;
using Henkel.Business.Security.Model;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.API.DTO.Pagination;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Resources;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Business.Security.Repository.Specification;

namespace Henkel.Business.Security.Services.Impl
{
    public class RoleManagementService : TransactionSupportBaseService, IRoleManagementService
    {
        #region Fields

        private readonly IUserRepository _userRepository;
        private readonly IReadWriteRepository<Role> _roleRepository;
        private readonly IReadWriteRepository<Feature>_featureRepository;
        private readonly IAssembler<Role, RoleDto> _roleAssembler;
        private readonly IAssembler<Role, SudoRoleDto> _sudoRoleAssembler;

        #endregion


        #region Constructors

        public RoleManagementService(IUserRepository userRepository, IReadWriteRepository<Role> roleRepository, IReadWriteRepository<Feature> featureRepository)
        {
            _userRepository = userRepository;
            _roleRepository = roleRepository;
            _featureRepository = featureRepository;
            _roleAssembler = ObjectLocator.GetObject<IAssembler<Role, RoleDto>>();
            _sudoRoleAssembler = ObjectLocator.GetObject<IAssembler<Role, SudoRoleDto>>();
        }

        #endregion


        #region Implementation of IRoleManagementService
        
        #region Queries

        public RoleDto GetRoleById(Guid roleId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var role = _roleRepository.GetById(roleId);
                    if (role == null)
                        return null;
                    
                    var roleDto = _roleAssembler.GetDtoFromEntity(role);
                    roleDto.RoleFeatureMapDtos = role.GetRoleFeatureMapDtos();

                    return roleDto;
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public SudoRoleDto GetSudoRoleById(Guid userId, Guid roleId)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var user = _userRepository.GetById(userId);
                    if (user == null)
                        throw new ValidationException(SecurityErrorMessage.InvalidUserIdToGetSudoRole);

                    var roleUserMap = user.RoleUserMaps.FirstOrDefault(x => x.Role.Id == roleId);
                    if (roleUserMap == null)
                        throw new ValidationException(SecurityErrorMessage.InvalidUserIdOrRoleIdToGetSudoRole);

                    var sudoRoleDto = _sudoRoleAssembler.GetDtoFromEntity(roleUserMap.Role);
                    sudoRoleDto.UserId = userId;
                    sudoRoleDto.RoleFeatureUserMapDtos = roleUserMap.Role.GetRoleFeatureUserMapDtos();

                    return sudoRoleDto;
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public Page<RoleDto> FindRoleByCriteria(RoleSearchCriteria roleSearchCriteria, PageInfo pageInfo)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var searchExp = roleSearchCriteria.GetSearchExpression();
                    var count = _roleRepository.GetCount(searchExp);
                    if (count > 0)
                    {
                        var pageExp = pageInfo.GetRoleSortExpression();
                        var result = _roleRepository.Find(searchExp, pageExp, pageInfo.StartRow, pageInfo.PageSize).ToList();
                        return new Page<RoleDto>(count, result.Select(x => _roleAssembler.GetDtoFromEntity(x)).ToList());
                    }
                    return new Page<RoleDto>(count, new List<RoleDto>());
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public IList<RoleDto> FindRoleByCriteria(RoleSearchCriteria roleSearchCriteria)
        {
            try
            {
                using (RepositoryReadOnlySession)
                {
                    var expression = roleSearchCriteria.GetSearchExpression();
                    var result = _roleRepository.Find(expression).ToList();
                    return result.Select(_roleAssembler.GetDtoFromEntity).ToList();
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        #endregion

        #region Commands

        public void AddRole(RoleDto roleDto)
        {
            try
            {
                using(var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleAssembler.GetEntityFromDto(roleDto);
                        role.Add();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void UpdateRole(RoleDto roleDto)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleDto.Id);
                        _roleAssembler.UpdateEntityFromDto(role, roleDto);

                        role.Update();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void UpdateSudoRole(SudoRoleDto sudoRole)
        {
            throw new NotImplementedException();
        }

        public void EnableRole(Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleId);
                        role.MarkAsEnable();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void DisableRole(Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleId);
                        role.MarkAsDisable();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void DeleteRole(Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var role = _roleRepository.GetById(roleId);
                        role.Delete();
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void AttachRoleToUser(Guid userId, Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        var role = _roleRepository.GetById(roleId);

                        role.AttachUser(user);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        public void DettachRoleFromUser(Guid userId, Guid roleId)
        {
            try
            {
                using (var session = RepositorySession)
                {
                    try
                    {
                        var user = _userRepository.GetById(userId);
                        if(user == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidUserIdForDetachedRoleFromUser);
                        var roleUserMap = user.RoleUserMaps.FirstOrDefault(x => x.User.Id == user.Id && x.Role.Id == roleId);
                        if (roleUserMap == null)
                            throw new ValidationException(SecurityErrorMessage.InvalidRoleIdForDetachedRoleFromUser);

                        roleUserMap.Role.DettachUser(user);
                    }
                    catch (Exception)
                    {
                        session.Rollback();
                        throw;
                    }
                }
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        //public void ModifyUserSudoRole(IList<RoleFeatureUserMapDto> roleFeatureUserMapDtos)
        //{
        //    try
        //    {
        //        using (var session = RepositorySession)
        //        {
        //            try
        //            {
        //                var userIds = roleFeatureUserMapDtos.Select(x => x.UserId).Distinct().ToArray();
        //                if(userIds.Any( x => x == null || x == Guid.Empty) || userIds.Length != 1)
        //                    throw new ValidationException(SecurityErrorMessage.UserIdMustBeUniqueToUpdateSudoRole);

        //                var userId = userIds[0];

        //                var roleIds = roleFeatureUserMapDtos.Select(x => x.RoleId).Distinct().ToArray();
        //                if ( roleIds.Any( x => x == null || x == Guid.Empty ) || roleIds.Length != 1)
        //                    throw new ValidationException(SecurityErrorMessage.RoleIdMustBeUniqueToUpdateSudoRole);

        //                var roleId = roleIds[0];

        //                var user = _userRepository.GetById(userId);
        //                var roleUserMap = user.RoleUserMaps.FirstOrDefault(x=> x.User.Id == user.Id && x.Role.Id == roleId);
        //                if (roleUserMap == null)
        //                    throw new ValidationException(SecurityErrorMessage.RoleNotDefineForThisUser);

        //                var roleFeatureUserMaps = new List<RoleFeatureUserMap>();

        //                foreach (var roleFeatureUserMapDto in roleFeatureUserMapDtos)
        //                {
        //                    var feature = _featureRepository.GetById(roleFeatureUserMapDto.FeatureId);
        //                    var roleFeatureUserMap = RoleFeatureUserMap.CreateNewInstance(user, roleUserMap.Role, feature, roleFeatureUserMapDto);
        //                    roleFeatureUserMaps.Add(roleFeatureUserMap);
        //                }

        //                roleUserMap.Role.UpdateSudoRole(user, roleFeatureUserMaps);
        //            }
        //            catch (Exception)
        //            {
        //                session.Rollback();
        //                throw;
        //            }
        //        }
        //    }
        //    catch (ValidationException ex)
        //    {
        //        Logger.Error(GetType().Name, ex.Message, ex.Args);
        //        throw;
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
        //        throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
        //    }


        //}

        #endregion

        #endregion


        #region Helper Methods

        #endregion









        

        
    }
}
