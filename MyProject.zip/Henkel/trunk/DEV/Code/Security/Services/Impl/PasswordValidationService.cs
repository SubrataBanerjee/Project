﻿using Henkel.Business.Security.Model;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Locator;
using Henkel.Common.Core.API.Locator;

namespace Henkel.Business.Security.Services.Impl
{
    public class PasswordValidationService : IPasswordValidationService
    {
        #region Constructors

        public PasswordValidationService()
        {
        }

        #endregion

        #region Implementation of IPasswordValidationService

        public void Validate(string loginId, string oldPassword, string newPassword, string confirmPassword)
        {
            var userRepository = ObjectLocator.GetObject<IUserRepository>();
            var user = userRepository.Find(x => x.LoginId == loginId).FirstOrDefault();
            if (user == null)
                throw new ValidationException(SecurityErrorMessage.UsernameOrPasswordIsIncorrect);

            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();
            var hashedPassword = hasGeneratorService.GetHashedDataString(oldPassword);

            if (user.Password != hashedPassword)
                throw new ValidationException(SecurityErrorMessage.UsernameOrPasswordIsIncorrect);

            if (newPassword != confirmPassword)
                throw new ValidationException(SecurityErrorMessage.NewPasswordAndConfirmPasswordNotMatched);

            var passwordPolicyValidationService = ObjectLocator.GetObject<IPasswordPolicyValidationService>();
            passwordPolicyValidationService.Validate(newPassword);

            //Matching User's last 'N' numbers of used password
            var passwordHistoryValidationService = ObjectLocator.GetObject<IPasswordHistoryValidationService>();
            passwordHistoryValidationService.Validate(user, newPassword);
        }

        #endregion
    }
}
