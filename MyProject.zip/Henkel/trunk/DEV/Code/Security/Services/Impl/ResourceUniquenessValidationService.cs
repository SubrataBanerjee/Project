﻿using Henkel.Business.Security.Model;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Expressions;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services.Impl
{
    public class ResourceUniquenessValidationService : IResourceUniquenessValidationService
    {
        #region Fields

        private readonly IResourceRepository _resourceRepository;

        #endregion

        #region Constructors

        public ResourceUniquenessValidationService(IResourceRepository resourceRepository)
        {
            _resourceRepository = resourceRepository;
        }

        #endregion

        #region Implementation of IResourceUniquenessValidationService

        public void ValidateCode(string code, Guid[] ignoreResourceIds = null)
        {
            var expression = PredicateBuilder.True<Resource>();
            expression = expression.AndAlso(x => x.Code == code);
            if (ignoreResourceIds != null)
                expression = expression.AndAlso(x => !ignoreResourceIds.Contains(x.Id));

            var count = _resourceRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.ResourceCodeAlreadyExist);
        }

        public void ValidateEmail(string email, Guid[] ignoreResourceIds = null)
        {
            var expression = PredicateBuilder.True<Resource>();
            expression = expression.AndAlso(x => x.Contact != null && x.Contact.Email == email);
            if (ignoreResourceIds != null)
                expression = expression.AndAlso(x => !ignoreResourceIds.Contains(x.Id));

            var count = _resourceRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.ResourceEmailIdAlreadyExist);
        }

        #endregion

        
    }
}
