﻿using Henkel.Business.Security.Model;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Expressions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services.Impl
{
    public class UserUniquenessValidationService : IUserUniquenessValidationService
    {
        #region Fields

        private readonly IUserRepository _userRepository;

        #endregion

        #region Constructors

        public UserUniquenessValidationService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        #endregion

        #region Implementation of IUserUniquenessValidationService

        public void ValidateUserLoginId(string loginId, Guid[] ignoreUserIds = null)
        {
            var expression = PredicateBuilder.True<User>();
            expression = expression.AndAlso(x => x.LoginId == loginId);
            if(ignoreUserIds != null)
                expression = expression.AndAlso(x => !ignoreUserIds.Contains(x.Id));

            var count = _userRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.UserLoginIdAlreadyExist);
        }

        #endregion
    }
}
