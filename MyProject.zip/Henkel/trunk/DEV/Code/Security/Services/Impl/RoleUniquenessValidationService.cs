﻿using Henkel.Business.Security.Model;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Expressions;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services.Impl
{
    public class RoleUniquenessValidationService : IRoleUniquenessValidationService
    {
        #region Fields

        private readonly IReadWriteRepository<Role> _roleRepository;

        #endregion

        #region Constructors

        public RoleUniquenessValidationService(IReadWriteRepository<Role> roleRepository)
        {
            _roleRepository = roleRepository;
        }

        #endregion

        #region Implementation of IRoleUniquenessValidationService

        public void ValidateRoleName(string roleName, Guid[] ignoreRoleIds = null)
        {
            var expression = PredicateBuilder.True<Role>();
            expression = expression.AndAlso(x => x.Name == roleName);
            if(ignoreRoleIds != null)
                expression = expression.AndAlso(x => !ignoreRoleIds.Contains(x.Id));

            var count = _roleRepository.GetCount(expression);
            if (count > 0)
                throw new ValidationException(SecurityErrorMessage.RoleNameAlreadyExist);
        }

        #endregion
    }
}
