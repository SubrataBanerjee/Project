﻿using Henkel.Business.Security.Model;
using Henkel.Business.Security.Resources;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services.Impl
{
    public class PasswordHistoryValidationService : IPasswordHistoryValidationService
    {
        #region Constructors

        public PasswordHistoryValidationService()
        {
        }

        #endregion

        #region Implementation of IPasswordHistoryValidationService

        public void Validate(User user, string password)
        {
            var customerDetail = CustomerAdminUtil.GetCustomerAdminDetail();
            var passwordHistoryLimitStr = customerDetail.GetConfigValue(SecurityAdminConfigKey.PasswordHistoryLimit);

            if (string.IsNullOrWhiteSpace(passwordHistoryLimitStr))
                return;

            Int16 passwordHistoryLimit;
            if (!Int16.TryParse(passwordHistoryLimitStr, out passwordHistoryLimit))
            {
                Logger.Warning(GetType().Name, "Invalid entry configured in AdminDB for CustomerId: {0} and Key: {1}. Exiting without validation of last N numbers of used passwords match.", ObjectLocator.GetService<IUserContextService>().CustomerId, SecurityAdminConfigKey.PasswordHistoryLimit);
                return;
            }

            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();

            var hashedPwd = hasGeneratorService.GetHashedDataString(password);
            var paswwordHistories = user.PasswordHistories.OrderByDescending(x => x.CreatedOn).Take(passwordHistoryLimit);
            if (paswwordHistories.Any(x => x.Password == hashedPwd))
                throw new ValidationException(SecurityErrorMessage.NewPasswordShouldNotBeSameAsLastUsedPassword, passwordHistoryLimit);
        }

        #endregion
    }
}
