﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    public interface IPasswordValidationService
    {
        /// <summary>
        /// Method to validate New Password. It perform the below task
        /// -- Validate existing credential
        /// -- Matched New Password and Confirm Password
        /// -- Validate New Password with Password Policy
        /// -- Validate New Password with Password History
        /// </summary>
        /// <param name="loginId">LoginId of the user whose new password need to be validate</param>
        /// <param name="oldPassword">Existing password of the user whose new password need to be validate</param>
        /// <param name="newPassword">New Password to validate</param>
        /// <param name="confirmPassword">Confirm Password to validate</param>
        void Validate(string loginId, string oldPassword, string newPassword, string confirmPassword);
    }
}
