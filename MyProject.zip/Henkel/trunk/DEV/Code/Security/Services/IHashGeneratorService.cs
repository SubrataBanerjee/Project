﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    /// <summary>
    /// Interface specifying methods that need implementation for Hashed string/bytes Generation
    /// </summary>
    public interface IHashGeneratorService
    {
        /// <summary>
        /// Gets the hashed data.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        byte[] GetHashedData(String data);

        /// <summary>
        /// Gets the hashed data string.
        /// </summary>
        /// <param name="data">The data.</param>
        /// <returns></returns>
        string GetHashedDataString(String data);
    }
}
