﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    public interface IResourceUniquenessValidationService
    {
        /// <summary>
        /// Method to Validate unique Code for Resource
        /// </summary>
        /// <param name="code">Code to Validate</param>
        /// <param name="ignoreResourceIds">ResourceIds to ignore</param>
        void ValidateCode(string code, Guid[] ignoreResourceIds = null);

        /// <summary>
        /// Method to Validate unique Email for Resource
        /// </summary>
        /// <param name="email">email</param>
        /// <param name="ignoreResourceIds">ResourceIds to ignore</param>
        void ValidateEmail(string email, Guid[] ignoreResourceIds = null);
    }
}
