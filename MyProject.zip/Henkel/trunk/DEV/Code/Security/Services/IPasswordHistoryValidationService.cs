﻿using Henkel.Business.Security.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    public interface IPasswordHistoryValidationService
    {
        /// <summary>
        /// Methods to validate Password History data i.e. New Password should not be same as last used 'N' passwords where 'N' is integer value configured in DB  
        /// </summary>
        /// <param name="user">User whose password need to be validate with history data</param>
        /// <param name="password">new password to validate with History data</param>
        void Validate(User user, string password);
    }
}
