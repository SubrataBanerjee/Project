﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    public interface IRoleUniquenessValidationService
    {
        /// <summary>
        /// Validate Unique RoleName in the system
        /// </summary>
        /// <param name="roleName">roleName to Validate</param>
        /// <param name="ignoreRoleIds">RoleIds to Ignore</param>
        void ValidateRoleName(string roleName, Guid[] ignoreRoleIds = null);
    }
}
