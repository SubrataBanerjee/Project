﻿using Henkel.Common.Core.API.Services;
using Henkel.Business.Security.API.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Services
{
    /// <summary>
    /// Authentication service interface
    /// </summary>
    public partial interface IAuthenticationService : IBusinessService
    {
        void SignIn(UserToken user, bool createPersistentCookie);
        void SignOut();
        UserToken GetAuthenticatedUser();
    }
}
