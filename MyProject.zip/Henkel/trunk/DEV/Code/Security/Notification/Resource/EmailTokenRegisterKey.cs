﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Notification.Resource
{
    public static class EmailTokenRegisterKey
    {
        public const string UserEmailTokenProvider = "UserEmailTokenProvider";
    }
}
