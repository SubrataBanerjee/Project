﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Notification.Resources
{
    public static class SecurityNotificationKey
    {
        public const string NewUser = "NewUser";
        public const string ResetPassword = "ResetPassword";
        public const string ChangePassword = "ChangePassword";
    }
}
