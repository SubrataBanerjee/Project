﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.Resources;
using Henkel.Business.Security.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Model;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Model
{
    public class Role : CustomerAuditEntityWithSoftDelete
    {
        public virtual string Name { get; set; }

        public virtual bool IsActive { get; set; }

        private ICollection<RoleUserMap> _roleUserMaps;
        public virtual ICollection<RoleUserMap> RoleUserMaps 
        {
            get { return _roleUserMaps ?? (_roleUserMaps = new HashSet<RoleUserMap>()); }
            set { _roleUserMaps = value; }
        }

        private ICollection<RoleFeatureMap> _roleFeatureMaps;
        public virtual ICollection<RoleFeatureMap> RoleFeatureMaps 
        {
            get { return _roleFeatureMaps ?? (_roleFeatureMaps = new HashSet<RoleFeatureMap>()); }
            set { _roleFeatureMaps = value; }
        }

        private ICollection<RoleFeatureUserMap> _roleFeatureUserMaps;
        public virtual ICollection<RoleFeatureUserMap> RoleFeatureUserMaps
        {
            get { return _roleFeatureUserMaps ?? (_roleFeatureUserMaps = new HashSet<RoleFeatureUserMap>()); }
            set { _roleFeatureUserMaps = value; }
        }

        #region Business Methods

        public virtual void Add()
        {
            ValidateForAdd();

            var roleRepository = ObjectLocator.GetObject<IReadWriteRepository<Role>>();
            roleRepository.Add(this);
        }

        public virtual void Update()
        {
            ValidateForUpdate();

            var roleRepository = ObjectLocator.GetObject<IReadWriteRepository<Role>>();
            roleRepository.Update(this);
        }

        public virtual void MarkAsEnable()
        {
            IsActive = true;
        }

        public virtual void MarkAsDisable()
        {
            IsActive = false;
        }

        public virtual void AttachUser(User user)
        {
            AddRoleFeatureUserMaps(user, RoleFeatureMaps);
            AddRoleUserMap(user, RoleUserMaps);
        }

        public virtual void DettachUser(User user)
        {
            RemoveRoleFeatureUserMaps(user);
            RemoveRoleUserMap(user);
        }

        public virtual void Delete()
        {
            ValidateForDelete();

            var roleRepository = ObjectLocator.GetObject<IReadWriteRepository<Role>>();
            roleRepository.Delete(this);
        }

        public virtual IList<RoleFeatureMapDto> GetRoleFeatureMapDtos()
        {
            var list = new List<RoleFeatureMapDto>();
            foreach(var roleFeatureMap in RoleFeatureMaps)
                list.Add(roleFeatureMap.GetDto());
            
            return list;
        }

        public virtual IList<RoleFeatureUserMapDto> GetRoleFeatureUserMapDtos()
        {
            var list = new List<RoleFeatureUserMapDto>();
            foreach (var roleFeatureUserMap in RoleFeatureUserMaps)
                list.Add(roleFeatureUserMap.GetDto());
            
            return list;
        }

        public virtual void UpdateSudoRole(User user, IList<RoleFeatureUserMap> newRoleFeatureUserMaps)
        {
            var existingSudoRoles = RoleFeatureUserMaps.Where(x => x.CustomerId == this.CustomerId && x.User.Id == user.Id && x.Role.Id == this.Id).ToList();

            foreach (var roleFeatureUserMap in existingSudoRoles)
            {
                RoleFeatureUserMaps.Remove(roleFeatureUserMap);
            }

            AddRoleFeatureUserMaps(user, newRoleFeatureUserMaps);
        }

        #endregion

        #region Helper Methods

        #region Validation Methods

        private void ValidateForAdd()
        {
            if (string.IsNullOrWhiteSpace(Name))
                throw new ValidationException(SecurityErrorMessage.RoleNameCanNotBeEmpty);

            var uniqueRoleValidationService = ObjectLocator.GetObject<IRoleUniquenessValidationService>();
            uniqueRoleValidationService.ValidateRoleName(Name);
        }

        private void ValidateForUpdate()
        {
            if (string.IsNullOrWhiteSpace(Name))
                throw new ValidationException(SecurityErrorMessage.RoleNameCanNotBeEmpty);

            var uniqueRoleNameValidationService = ObjectLocator.GetObject<IRoleUniquenessValidationService>();
            uniqueRoleNameValidationService.ValidateRoleName(Name, new[] { Id });
        }

        private void ValidateForDelete()
        {
            //TODO: Add Validation Here
        }

        private void AddRoleFeatureUserMaps(User user, ICollection<RoleFeatureMap> roleFeatureMaps)
        {
            foreach (var roleFeaturMap in roleFeatureMaps)
            {
                var roleFeatureUserMap = RoleFeatureUserMap.CreateNewInstance(user, roleFeaturMap);
                var existingRoleFeatureUserMap = RoleFeatureUserMaps.FirstOrDefault(x => x.CustomerId == this.CustomerId && x.User.Id == user.Id && x.Role.Id == this.Id && x.Feature.Id == roleFeaturMap.Feature.Id);
                if (existingRoleFeatureUserMap == null)
                    RoleFeatureUserMaps.Add(roleFeatureUserMap);
                else
                    existingRoleFeatureUserMap.Update(roleFeatureUserMap.Add, roleFeatureUserMap.Edit, roleFeatureUserMap.View, roleFeatureUserMap.Delete, roleFeatureUserMap.Print, roleFeatureUserMap.Execute, roleFeatureUserMap.Activate);
            }
        }

        private void AddRoleFeatureUserMaps(User user, ICollection<RoleFeatureUserMap> newRoleFeatureUserMaps)
        {
            foreach (var newRoleFeaturUserMap in newRoleFeatureUserMaps)
            {
                var existingRoleFeatureUserMap = RoleFeatureUserMaps.FirstOrDefault(x => x.CustomerId == this.CustomerId && x.User.Id == user.Id && x.Role.Id == this.Id && x.Feature.Id == newRoleFeaturUserMap.Feature.Id);
                if (existingRoleFeatureUserMap == null)
                    RoleFeatureUserMaps.Add(newRoleFeaturUserMap);
                else
                    existingRoleFeatureUserMap.Update(newRoleFeaturUserMap.Add, newRoleFeaturUserMap.Edit, newRoleFeaturUserMap.View, newRoleFeaturUserMap.Delete, newRoleFeaturUserMap.Print, newRoleFeaturUserMap.Execute, newRoleFeaturUserMap.Activate);
            }
        }

        private void AddRoleUserMap(User user, ICollection<RoleUserMap> roleUserMaps )
        {
            var roleUserMap = RoleUserMap.CreateNewInstance(user, this);
            var existingRoleUserMap = roleUserMaps.FirstOrDefault(x => x.CustomerId == this.CustomerId && x.User.Id == user.Id && x.Role.Id == this.Id);
            if (existingRoleUserMap == null)
                roleUserMaps.Add(roleUserMap);
        }

        private void RemoveRoleUserMap(User user)
        {
            var roleUserMapsToRemove = RoleUserMaps.Where(x => x.CustomerId == this.CustomerId && x.User.Id == user.Id && x.Role.Id == this.Id).ToList();
            foreach (var roleUserMap in roleUserMapsToRemove)
            {
                RoleUserMaps.Remove(roleUserMap);
            }
        }

        private void RemoveRoleFeatureUserMaps(User user)
        {
            var RoleFeatureUserMapsToRemove = RoleFeatureUserMaps.Where(x => x.CustomerId == this.CustomerId && x.User.Id == user.Id && x.Role.Id == this.Id).ToList();
            foreach (var RoleFeatureUserMap in RoleFeatureUserMapsToRemove)
            {
                RoleFeatureUserMaps.Remove(RoleFeatureUserMap);
            }
        }

        #endregion
        #endregion
    }
}
