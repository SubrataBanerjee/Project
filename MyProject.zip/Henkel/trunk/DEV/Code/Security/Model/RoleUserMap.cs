﻿using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Model
{
    public class RoleUserMap : CustomerEntity
    {
        #region Fields

        public virtual Guid UserId { get; set; }

        public virtual User User { get; set; }

        public virtual Guid RoleId { get; set; }

        public virtual Role Role { get; set; }

        #endregion

        #region Constructors


        #endregion

        #region Business Methods

        public static RoleUserMap CreateNewInstance(User user, Role role)
        {
            return new RoleUserMap
            {
                CustomerId = role.CustomerId,
                User = user,
                Role = role,
            };
        }

        #endregion


        #region Helper Methods


        #endregion



        
    }    
}
