﻿using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Security.Repository;
using Henkel.Business.Security.Resources;
using Henkel.Business.Security.Services;
using Henkel.Common.Core.API.DTO.ComplexType;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Model
{
    public class Resource : AggregateRootEntity
    {
        #region Fields

        #region private
        
        IResourceUniquenessValidationService _resourceUniquenessValidationService;
        IResourceUniquenessValidationService ResourceUniquenessValidationService
        {
            get
            {
                if(_resourceUniquenessValidationService == null)
                    _resourceUniquenessValidationService = ObjectLocator.GetObject<IResourceUniquenessValidationService>();

                return _resourceUniquenessValidationService;
            }
        }
        
        #endregion
        
        public virtual string Code { get; set; }

        public virtual Guid? UserId { get; set; }

        public virtual User User { get; set; }

        public virtual Contact Contact { get; set; }

        public virtual Address Address { get; set; }

        public virtual bool IsActive { get; set; }

        #endregion

        #region Business Methods

        public virtual void Add()
        {
            ValidateForAdd();

            var resourceRepository = ObjectLocator.GetObject<IResourceRepository>();
            Id = resourceRepository.Add(this).Id;
        }

        public virtual void Update()
        {
            ValidateForUpdate();
            var resourceRepository = ObjectLocator.GetObject<IResourceRepository>();
            resourceRepository.Update(this);
        }

        public virtual void Delete()
        {
            ValidateForDelete();

            if (User != null)
                User.Delete();

            var resourceRepository = ObjectLocator.GetObject<IResourceRepository>();
            resourceRepository.Delete(this);
        }

        public virtual void UpdateEmail(string email)
        {
            ValidateEmailForUpdate(email, new[] { Id });

            if (Contact == null)
                Contact = new Contact();

            Contact.Email = email;
        }

        
        public virtual void MarkAsEnable()
        {
            if (User != null)
                User.MarkAsEnable();
            IsActive = true;
        }

        public virtual void MarkAsDisable()
        {
            if (User != null)
                User.MarkAsDisable();
            IsActive = false;
        }

        public virtual void CreateLogin(string loginId)
        {
            if(User != null)
                throw new ValidationException(SecurityErrorMessage.CanNotCreateLoginAsResourceLoginAlreadyExist);

            var newUser = User.CreateNewInstance(loginId);
            User = newUser;
            newUser.Add();
        }

        public virtual void DeleteLogin()
        {
            if (User == null)
                return;

            User.Delete();
            User = null;
        }

        #endregion

        #region helper methods

        private void ValidateForAdd()
        {
            if (string.IsNullOrWhiteSpace(Code))
                throw new ValidationException(SecurityErrorMessage.ResourceCodeCanNotBeEmpty);
            ResourceUniquenessValidationService.ValidateCode(Code);

            if (Contact == null)
                throw new ValidationException(SecurityErrorMessage.ResourceEmailCanNotBeEmpty);

            ValidateEmailForUpdate(Contact.Email);
        }

        private void ValidateForUpdate()
        {
            if (Contact == null || string.IsNullOrWhiteSpace(Contact.Email))
                throw new ValidationException(SecurityErrorMessage.ResourceEmailCanNotBeEmpty);

            var resourceUniquenessValidationService = ObjectLocator.GetObject<IResourceUniquenessValidationService>();
            resourceUniquenessValidationService.ValidateEmail(Contact.Email);
        }

        private void ValidateEmailForUpdate(string email, Guid[] ignoreResourceIds = null)
        {
            if (string.IsNullOrWhiteSpace(email))
                throw new ValidationException(SecurityErrorMessage.ResourceEmailCanNotBeEmpty);

            var emailValidationService = ObjectLocator.GetService<IEmailValidationService>();
            if (!emailValidationService.IsValid(email))
                throw new ValidationException(SecurityErrorMessage.InvalidEmailIdFormat);

            ResourceUniquenessValidationService.ValidateEmail(email, ignoreResourceIds);
        }

        private void ValidateForDelete()
        {

        }

        #endregion

        
    }
}
