﻿using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Model
{
    public class Feature : Entity
    {
        public virtual string Name { get; set; }

        public virtual string Module { get; set; }

        public virtual string FeatureGroup { get; set; }

        public virtual bool Add { get; set; }

        public virtual bool Edit { get; set; }

        public virtual bool View { get; set; }

        public virtual bool Delete { get; set; }

        public virtual bool Print { get; set; }

        public virtual bool Execute { get; set; }

        public virtual bool Activate { get; set; }
    }
}
