﻿using Henkel.Business.Security.API.DTO;
using Henkel.Business.Security.Notification.Resources;
using Henkel.Business.Security.Resources;
using Henkel.Business.Security.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.API.Utils;
using Henkel.Common.Core.Assembler;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Model
{
    public partial class User : AggregateRootEntity
    {
        #region Fields

        private const string USER_DEFAULT_PASSWORD = "password@123";

        #endregion

        
        #region Public Methods

        public virtual void ResetPassword(string newPassword = "")
        {
            UnHashedNewPassword = newPassword;
            if (string.IsNullOrWhiteSpace(UnHashedNewPassword))
            {
                var customerAdminDetail = CustomerAdminUtil.GetCustomerAdminDetail();
                UnHashedNewPassword = customerAdminDetail.GetConfigValue(SecurityAdminConfigKey.DefaultUserPassword);
                if (string.IsNullOrWhiteSpace(UnHashedNewPassword))
                    UnHashedNewPassword = USER_DEFAULT_PASSWORD;
            }

            UpdatePassword(true);
            
        }


        public virtual void ChangePassword(string oldPassword, string newPassword, string confirmPassword)
        {
            UnHashedNewPassword = newPassword;
            var passwordValidationService = ObjectLocator.GetObject<IPasswordValidationService>();
            passwordValidationService.Validate(LoginId, oldPassword, UnHashedNewPassword, confirmPassword);

            UpdatePassword(false);
        }


        public virtual void ForgotPassword()
        {
            ResetPassword();
        }


        public virtual void Lock()
        {
            Locked = true;
        }


        public virtual void Unlock()
        {
            Locked = false;
        }


        public virtual void UpdateFailureLoginAttempt()
        {
            FailureLoginAttempt += 1;
        }


        public virtual void ResetFailureLoginAttempt()
        {
            FailureLoginAttempt = 0;
        }


        public virtual bool IsMaxLoginAttemptExceed()
        {
            var customerAdminDetail = CustomerAdminUtil.GetCustomerAdminDetail();
            var maxFailureLoginAttemptAllowed = customerAdminDetail.GetConfigValue(SecurityAdminConfigKey.FailureLoginAttemptLimit);
            if (string.IsNullOrWhiteSpace(maxFailureLoginAttemptAllowed))
                return false;

            int maxCount;
            if (!Int32.TryParse(maxFailureLoginAttemptAllowed, out maxCount))
                return false;

            if (maxCount == 0)
                return false;

            if (FailureLoginAttempt <= maxCount)
                return false;
            return true;
        }


        public virtual void ValidateAuthentication(string password)
        {
            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();
            var hashedPassword = hasGeneratorService.GetHashedDataString(password);

            if (Password != hashedPassword)
            {
                UpdateFailureLoginAttempt();
                throw new ValidationException(SecurityErrorMessage.UsernameOrPasswordIsIncorrect);
            }

            if (IsMaxLoginAttemptExceed())
                Lock();

            if (Locked)
                throw new ValidationException(SecurityErrorMessage.UserIsLocked);

            if (!IsActive)
                throw new ValidationException(SecurityErrorMessage.UserIsDisabled);
        }


        public virtual UserToken GetToken()
        {
            return new UserToken
            {
                SuccessLogin = true,
                UserId = Id,
                UserName = LoginId,
                CustomerId = CustomerId,
                IsActive = IsActive,
                IsDeleted = IsDeleted,
                IsSuperAdmin = IsSuperAdmin,
                Roles = GetTokenizedRoleDetails()
            };
        }

        
        #endregion

        #region Helper Methods


        private void UpdatePassword(bool changePwdOnLogin)
        {
            var hasGeneratorService = ObjectLocator.GetObject<IHashGeneratorService>();
            var hashedPassword = hasGeneratorService.GetHashedDataString(UnHashedNewPassword);
            
            Password = hashedPassword;
            ChangePwdOnLogin = changePwdOnLogin;

            UpdatePasswordHistory();
            SendEmail(changePwdOnLogin ? SecurityNotificationKey.ResetPassword : SecurityNotificationKey.ChangePassword);
        }


        private void UpdatePasswordHistory()
        {
            foreach(var passwordHistory in PasswordHistories.Where(x => x.IsActive))
            {
                passwordHistory.IsActive = false;
            }
            var newPasswordHistory = PasswordHistory.CreateNewIntance(this);
            PasswordHistories.Add(newPasswordHistory);
        }

        private IList<RoleFeatureUserMapDto> GetTokenizedRoleDetails()
        {
            if (IsSuperAdmin)
                return null;

            if (RoleUserMaps == null || !RoleUserMaps.Any())
                return null;

            var result = new List<RoleFeatureUserMapDto>();
            foreach(var roleUserMap in RoleUserMaps)
            {
                if (roleUserMap.Role.RoleFeatureUserMaps.Any())
                    result.AddRange(roleUserMap.Role.RoleFeatureUserMaps.Select(x=> x.GetDto()));
            }

            return result;
        }

        #endregion



        
    }
}
