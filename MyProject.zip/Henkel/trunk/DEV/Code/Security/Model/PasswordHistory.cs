﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Services;
using Henkel.Common.Core.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Security.Model
{
    public class PasswordHistory : CustomerEntity
    {
        public virtual Guid UserId { get; set; }

        public virtual User User { get; set; }

        public virtual string Password { get; set; }

        public virtual bool IsActive { get; set; }

        public virtual string CreatedBy { get; set; }

        public virtual DateTime CreatedOn { get; set; }

        public static PasswordHistory CreateNewIntance(User user)
        {
            return new PasswordHistory
            {
                Id = Guid.NewGuid(),
                CustomerId = user.CustomerId,
                User = user,
                UserId = user.Id,
                Password = user.Password,
                IsActive = true,
                CreatedBy = ObjectLocator.GetService<IUserContextService>().CurrentUserName,
                CreatedOn = DateTime.UtcNow
            };
        }
    }
}
