﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Model
{
    public enum NotificationStatus
    {
        Processed,
        Failed,
    }
}
