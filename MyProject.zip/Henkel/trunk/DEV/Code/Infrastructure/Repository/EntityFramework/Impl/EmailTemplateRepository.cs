﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.Repository.EntityFramework.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Repository.EntityFramework.Impl
{
    public class EmailTemplateRepository : EFReadWriteRepository<EmailTemplate>, IEmailTemplateRepository
    {
    }
}
