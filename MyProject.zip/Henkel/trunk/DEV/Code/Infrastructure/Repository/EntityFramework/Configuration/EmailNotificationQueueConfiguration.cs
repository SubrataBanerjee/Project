﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class EmailNotificationQueueConfiguration : EntityTypeConfiguration<EmailNotificationQueue>, IEntityConfiguration
    {
        public EmailNotificationQueueConfiguration()
        {
            this.ToTable("Infra_NotificationQueue");
            HasKey(et => new { et.Id , et.CustomerId });

            this.Property(et => et.EmailTemplateId).IsRequired();
            this.Property(et => et.To).IsRequired().HasMaxLength(200);
            this.Property(et => et.From).IsRequired().HasMaxLength(200);
            this.Property(et => et.CC).HasMaxLength(1000);
            this.Property(et => et.BCC).HasMaxLength(1000);
            this.Property(et => et.Subject).HasMaxLength(1000);
            this.Property(et => et.Body).IsRequired();
            this.Property(et => et.Attachments);
            this.Property(et => et.RaisedBy);
            this.Property(et => et.RaisedOn);
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
