﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.Repository.EntityFramework.Configuration;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity.ModelConfiguration.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Henkel.Business.Infrastructure.Repository.EntityFramework.Configuration
{
    [Export(typeof(IEntityConfiguration))]
    public class EmailTemplateConfiguration : EntityTypeConfiguration<EmailTemplate>, IEntityConfiguration
    {
        public EmailTemplateConfiguration()
        {
            this.ToTable("Infra_EmailTemplate");
            HasKey(et => new { et.Id, et.CustomerId });
            
            this.Property(et => et.Name).IsRequired().HasMaxLength(200);
            this.Property(et => et.To).IsRequired().HasMaxLength(200);
            this.Property(et => et.From).IsRequired().HasMaxLength(200);
            this.Property(et => et.CC).HasMaxLength(1000);
            this.Property(et => et.BCC).HasMaxLength(1000);
            this.Property(et => et.Subject).HasMaxLength(1000);
            this.Property(et => et.Body).IsRequired();
            this.Property(et => et.EmailTokenProviderName).HasMaxLength(200);
            this.Property(et => et.IsActive).IsRequired();
        }

        public void AddConfiguration(ConfigurationRegistrar registrar)
        {
            registrar.Add(this);
        }
    }
}
