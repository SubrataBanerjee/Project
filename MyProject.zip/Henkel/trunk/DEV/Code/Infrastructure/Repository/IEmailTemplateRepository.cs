﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Repository
{
    public interface IEmailTemplateRepository : IReadWriteRepository<EmailTemplate>
    {
    }
}
