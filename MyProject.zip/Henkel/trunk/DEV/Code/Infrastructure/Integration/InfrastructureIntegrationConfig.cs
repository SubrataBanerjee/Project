﻿using Microsoft.Practices.Unity;
using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Infrastructure.Repository;
using Henkel.Business.Infrastructure.Repository.EntityFramework.Impl;
using Henkel.Business.Infrastructure.Services;
using Henkel.Business.Infrastructure.Services.Impl;
using Henkel.Common.Core.API.Integration.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Repository.EntityFramework.Impl;

namespace Henkel.Business.Infrastructure.Integration
{
    public class InfrastructureIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterRepository(container);
            RegisterAssemblers(container);
            RegisterServices(container);
            RegisterScheduledTasks(container);
        }

        private void RegisterRepository(IUnityContainer container)
        {
            container.RegisterType<IEmailTemplateRepository, EmailTemplateRepository>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<EmailNotificationQueue>, EFReadWriteRepository<EmailNotificationQueue>>(new ContainerControlledLifetimeManager());
            container.RegisterType<IReadWriteRepository<EmailNotificationQueueHistory>, EFReadWriteRepository<EmailNotificationQueueHistory>>(new ContainerControlledLifetimeManager());
        }

        private void RegisterAssemblers(IUnityContainer container)
        {

        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<IEmailValidationService, EmailValidationService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailSender, EmailSender>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailTemplateService, EmailTemplateService>(new ContainerControlledLifetimeManager());
            container.RegisterType<ITokenizer, Tokenizer>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailingService, EmailingService>(new ContainerControlledLifetimeManager());
            container.RegisterType<IEmailNotificationQueueService, EmailNotificationQueueService>(new ContainerControlledLifetimeManager());
        }

        private void RegisterScheduledTasks(IUnityContainer container)
        {
            container.RegisterType<IEmailDispatchingService, EmailDispatchingService>(new ContainerControlledLifetimeManager());
        }
    }
}
