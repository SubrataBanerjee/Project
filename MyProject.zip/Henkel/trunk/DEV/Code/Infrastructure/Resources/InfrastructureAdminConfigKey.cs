﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Resources
{
    public static class InfrastructureAdminConfigKey
    {
        public const string SmtpHost = "SmtpHost"; 
        public const string SmtpPort = "SmtpPort";
        public const string SMTPEmailId = "SMTPEmailId";
        public const string SMTPPassword = "SMTPPassword";
    }
}
