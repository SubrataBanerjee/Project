﻿using Henkel.Business.Infrastructure.API.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services
{
    public interface ITokenizer
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="template"></param>
        /// <param name="tokens"></param>
        /// <param name="htmlEncode"></param>
        /// <returns></returns>
        string Replace(string template, IEnumerable<Token> tokens, bool htmlEncode);
    }
}
