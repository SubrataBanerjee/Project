﻿using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Infrastructure.Model;
using Henkel.Business.Infrastructure.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.Repository;
using Henkel.Common.Core.Resources;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services.Impl
{
    public class EmailDispatchingService : IEmailDispatchingService
    {
        #region Fields

        private readonly IReadWriteRepository<EmailNotificationQueue> _notificationQueueRepository;

        #endregion

        #region Constructors

        public EmailDispatchingService(IReadWriteRepository<EmailNotificationQueue> notificationQueueRepository)
        {
            _notificationQueueRepository = notificationQueueRepository;
        }

        #endregion

        #region Implemetation of IEmailDispatchingService

        public void DispatchQueuedEmail()
        {
            var emailNotificationQueueService = ObjectLocator.GetObject<IEmailNotificationQueueService>();
            var notificationQueues = emailNotificationQueueService.GetNotificationQueueEntries(50);

            foreach (var notificationQueue in notificationQueues)
            {
                notificationQueue.Dispatch();
                notificationQueue.Delete();
            }
        }

        public void DispatchEmail(Guid emailTemplateId, string fromEmail, string toEmail, string bccEmails, string ccEmails, string subject, string body, IDictionary<string, string> attachements = null)
        {
            var notificationQueue  = EmailNotificationQueue.CreateNewInstance(emailTemplateId, fromEmail, toEmail, bccEmails, ccEmails, subject, body, attachements);
            notificationQueue.Dispatch();
        }

        #endregion

        #region Helper Methods

        
        #endregion
    }
}
