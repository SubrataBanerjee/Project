﻿using Henkel.Business.Infrastructure.API.Services;
using Henkel.Business.Infrastructure.Model;
using Henkel.Business.Infrastructure.Resources;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Resources;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services.Impl
{
    public class EmailingService : IEmailingService
    {
        #region Fields

        #endregion

        #region Ctor

        public EmailingService()
        {
        }

        #endregion

        #region Implementation of IEmailService

        public virtual void SendEmail(string emailTemplateName, IEntity entity, IDictionary<string, string> attachements = null)
        {
            try
            {
                var emailTemplate = GetEmailTemplateByName(emailTemplateName);
                emailTemplate.SendEmail(entity, attachements);
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }
        #endregion

        #region Utilities

        private static EmailTemplate GetEmailTemplateByName(string emailTemplateName)
        {
            var emailTemplateService = ObjectLocator.GetObject<IEmailTemplateService>();
            var emailTemplate = emailTemplateService.GetEmailTemplateByName(emailTemplateName);
            if (emailTemplate == null)
                throw new ValidationException(InfrastructureErrorMessage.EmailTemplateIsNotExist);
            return emailTemplate;
        }

        #endregion
    }
}
