﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Business.Infrastructure.Repository;
using Henkel.Business.Infrastructure.Resources;
using Henkel.Common.Core.API.Caching.Model;
using Henkel.Common.Core.API.Caching.Services;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Resources;
using Henkel.Common.Core.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Caching;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services.Impl
{
    public partial class EmailTemplateService : IEmailTemplateService
    {
        #region Constants

        /// <summary>
        /// Key for caching
        /// </summary>
        private const string EmailTemplateS_ALL_KEY = "Henkel.emailtemplate.all";
        
        /// <summary>
        /// Key pattern to clear cache
        /// </summary>
        private const string EmailTemplateS_PATTERN_KEY = "Henkel.emailtemplate";

        #endregion

        #region Fields

        private readonly IEmailTemplateRepository _emailTemplateRepository;
        //private readonly ICachingService _cacheService;

        #endregion

        #region Ctor

        /// <summary>
        /// Ctor
        /// </summary>
        /// <param name="cacheService"></param>
        /// <param name="emailTemplateRepository"></param>
        public EmailTemplateService(IEmailTemplateRepository emailTemplateRepository)
        {
            _emailTemplateRepository = emailTemplateRepository;
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets a message template
        /// </summary>
        /// <param name="EmailTemplateName">Message template name</param>
        /// <returns>Message template</returns>
        public virtual EmailTemplate GetEmailTemplateByName(string emailTemplateName)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(emailTemplateName))
                    throw new ValidationException(InfrastructureErrorMessage.EmailTemplateNameCanNotBeBlank);
                
                return _emailTemplateRepository.Find(x=>x.Name == emailTemplateName).FirstOrDefault();
                //return GetAllEmailTemplates().FirstOrDefault(x => x.Name == emailTemplateName);
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        /// <summary>
        /// Gets all message templates
        /// </summary>
        /// <returns>Message template list</returns>
        public virtual IList<EmailTemplate> GetAllEmailTemplates()
        {
            string key = string.Format(EmailTemplateS_ALL_KEY);
            var cacheService = ObjectLocator.GetService<ICachingService>();
            return cacheService.Get(key, () => { return GetAllTemplates(); },
            new CachingOptions
            {
                CacheType = CacheType.Distributed,
                CachePolicy = new CacheItemPolicy { AbsoluteExpiration = DateTime.UtcNow.AddMinutes(5) }
            });
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public IList<EmailTemplate> GetAllTemplates()
        {
            try
            {
                var result = _emailTemplateRepository.Find().ToList();
                return result.Count == 0 ? null : result;
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        #endregion
    }
}
