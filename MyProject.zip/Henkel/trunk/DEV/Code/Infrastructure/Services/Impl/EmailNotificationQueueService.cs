﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services.Impl
{
    public class EmailNotificationQueueService : IEmailNotificationQueueService
    {
        #region fields
        #endregion

        #region Constructor

        public EmailNotificationQueueService()
        {
        }

        #endregion
        
        #region Implementation of IEmailNotificationQueueService

        public void AddNotificationQueue(EmailNotificationQueue notificationQueue)
        {
            try
            {
                notificationQueue.Add();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        public IList<EmailNotificationQueue> GetNotificationQueueEntries(int count)
        {
            try
            {
                var notificationQueueRepository = ObjectLocator.GetObject<IReadWriteRepository<EmailNotificationQueue>>();
                return notificationQueueRepository.Find(sortExpression: x => x.RaisedOn, maxRows: count).ToList();
            }
            catch(Exception ex)
            {
                return null;
            }
        }

        #endregion
    }
}
