﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Mail;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using Henkel.Common.Core.Resources;
using Henkel.Common.Core.API.Utils;
using Henkel.Business.Infrastructure.Resources;
using Henkel.Common.Core.API.Locator;
using Henkel.Business.Infrastructure.API.Services;
using Henkel.Common.Core.API.Logging.Model;

namespace Henkel.Business.Infrastructure.Services.Impl
{
    /// <summary>
    /// Email sender
    /// </summary>
    public partial class EmailSender : IEmailSender
    {
        #region Methods

        /// <summary>
        /// Sends an email
        /// </summary>
        /// <param name="subject">Subject</param>
        /// <param name="body">Body</param>
        /// <param name="fromAddress">From address</param>
        /// <param name="toAddress">To address</param>
        /// <param name="bcc">BCC addresses list</param>
        /// <param name="cc">CC addresses list</param>
        /// <param name="attachmentFilePath">Attachment file path</param>
        /// <param name="attachmentFileName">Attachment file name. If specified, then this file name will be sent to a recipient. Otherwise, "AttachmentFilePath" name will be used.</param>
        public void SendEmail(string subject, string body, string fromAddress, IList<string> toAddress, IList<string> bcc = null, IList<string> cc = null, IDictionary<string, string> attachements = null)
        {
            var emailValidationService = ObjectLocator.GetService<IEmailValidationService>();
            if (!emailValidationService.IsValid(fromAddress))
            {
                Logger.Warning(GetType().Name, "Invalid Email - From Address : [{0}] specified. Existing without sending Email.", fromAddress);
                return;
            }

            bool isAtleastOneValidAddrPresent = false;

            var toAddrList = new List<MailAddress>();
            foreach(var addr in toAddress)
            {
                if (emailValidationService.IsValid(addr))
                {
                    isAtleastOneValidAddrPresent = true;
                    toAddrList.Add(new MailAddress(addr,addr));
                }
                else
                {
                    Logger.Warning(GetType().Name, "Invalid Email - To Address : [{0}] specified..", addr);
                }
            }

            var bccAddrList = new List<string>();
            if(bcc != null)
            {
                foreach(var addr in bcc )
                {
                    if (emailValidationService.IsValid(addr))
                    {
                        isAtleastOneValidAddrPresent = true;
                        bccAddrList.Add(addr);
                    }
                    else
                    {
                        Logger.Warning(GetType().Name, "Invalid Email - BCC Address : [{0}] specified..", addr);
                    }
                }
            }

            var ccAddrList = new List<string>();
            if (cc != null)
            {
                foreach (var addr in cc)
                {
                    if (emailValidationService.IsValid(addr))
                    {
                        isAtleastOneValidAddrPresent = true;
                        ccAddrList.Add(addr);
                    }
                    else
                    {
                        Logger.Warning(GetType().Name, "Invalid Email - CC Address : [{0}] specified..", addr);
                    }
                }
            }

            if(!isAtleastOneValidAddrPresent)
            {
                Logger.Warning(GetType().Name, "Not a single Valid Email address present to send email. Exiting without sending Email.");
                return;
            }

            SendEmail(subject, body, new MailAddress(fromAddress, fromAddress), toAddrList, bccAddrList, ccAddrList, attachements);
        }

        /// <summary>
        /// Sends an email
        /// </summary>
        /// <param name="subject">Subject</param>
        /// <param name="body">Body</param>
        /// <param name="from">From address</param>
        /// <param name="to">To address</param>
        /// <param name="bcc">BCC addresses list</param>
        /// <param name="cc">CC addresses list</param>
        /// <param name="attachmentFilePath">Attachment file path</param>
        /// <param name="attachmentFileName">Attachment file name. If specified, then this file name will be sent to a recipient. Otherwise, "AttachmentFilePath" name will be used.</param>
        private void SendEmail(string subject, string body, MailAddress from, IEnumerable<MailAddress> to, IEnumerable<string> bcc = null, IEnumerable<string> cc = null, IDictionary<string, string> attachements = null)
        {
            var message = new MailMessage();
            
            message.From = from;
            foreach (var address in to)
            {
                message.To.Add(address);
            }

            if (bcc != null)
            {
                foreach (var address in bcc)
                {
                    message.Bcc.Add(address.Trim());
                }
            }
            if (cc != null)
            {
                foreach (var address in cc)
                {
                    message.CC.Add(address.Trim());
                }
            }
            message.Subject = subject;
            message.Body = body;
            message.IsBodyHtml = true;

            if(attachements != null)
            {
                //create  the file attachment for this e-mail message
                foreach(var filePathFileNamePair in attachements)
                {
                    var attachmentFilePath = filePathFileNamePair.Key;
                    var attachmentFileName = filePathFileNamePair.Value;

                    if (!String.IsNullOrEmpty(attachmentFilePath) && File.Exists(attachmentFilePath))
                    {
                        var attachment = new Attachment(attachmentFilePath);
                        attachment.ContentDisposition.CreationDate = File.GetCreationTime(attachmentFilePath);
                        attachment.ContentDisposition.ModificationDate = File.GetLastWriteTime(attachmentFilePath);
                        attachment.ContentDisposition.ReadDate = File.GetLastAccessTime(attachmentFilePath);
                        if (!String.IsNullOrEmpty(attachmentFileName))
                        {
                            attachment.Name = attachmentFileName;
                        }
                        message.Attachments.Add(attachment);
                    }
                }
            }

            var customerAdminDetail = CustomerAdminUtil.GetCustomerAdminDetail();
            var host = customerAdminDetail.GetConfigValue(InfrastructureAdminConfigKey.SmtpHost);
            var port = customerAdminDetail.GetConfigValue(InfrastructureAdminConfigKey.SmtpPort);
            var formEmailId = customerAdminDetail.GetConfigValue(InfrastructureAdminConfigKey.SMTPEmailId);
            var password = customerAdminDetail.GetConfigValue(InfrastructureAdminConfigKey.SMTPPassword);

            //TODO remove Return once SMTP Host/Port are configured
            return;

            using (var smtpClient = new SmtpClient())
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Host = host;
                smtpClient.Port = int.Parse(port);
                smtpClient.Credentials = new NetworkCredential(formEmailId, password);
                smtpClient.Send(message);
            }
        }

        #endregion
    }
}
