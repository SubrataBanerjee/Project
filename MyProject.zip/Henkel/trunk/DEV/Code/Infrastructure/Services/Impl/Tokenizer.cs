﻿using Henkel.Business.Infrastructure.API.DTO;
using Henkel.Business.Infrastructure.Resources;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.Exceptions;
using Henkel.Common.Core.Resources;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace Henkel.Business.Infrastructure.Services.Impl
{
    public partial class Tokenizer : ITokenizer
    {
        public string Replace(string template, IEnumerable<Token> tokens, bool htmlEncode)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(template))
                    throw new ValidationException(InfrastructureErrorMessage.EmailTemplateNameCanNotBeBlank);

                if (tokens == null)
                    throw new ValidationException(InfrastructureErrorMessage.TokenCanNotBeBlank);

                foreach (var token in tokens)
                {
                    string tokenValue = token.Value;
                    //do not encode URLs
                    if (htmlEncode && !token.NeverHtmlEncoded)
                        tokenValue = HttpUtility.HtmlEncode(tokenValue);
                    template = Replace(template, String.Format(@"%{0}%", token.Key), tokenValue);
                }
                return template;
            }
            catch (ValidationException ex)
            {
                Logger.Error(GetType().Name, ex.Message, ex.Args);
                throw;
            }
            catch (Exception ex)
            {
                Logger.Exception(GetType().Name, OperationStatus.CreateFromException(CoreErrorMessage.ExceptionOccurred, ex));
                throw new Exception(CoreErrorMessage.ErrorProcessingRequest);
            }
        }

        private string Replace(string original, string pattern, string replacement)
        {
            return original.Replace(pattern, replacement);
        }
    }
}
