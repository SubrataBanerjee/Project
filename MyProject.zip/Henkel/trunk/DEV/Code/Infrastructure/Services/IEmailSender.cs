﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services
{
    public interface IEmailSender
    {
        void SendEmail(string subject, string body, string fromAddress, IList<string> toAddress, IList<string> bcc = null, IList<string> cc = null, IDictionary<string, string> attachements = null);
    }
}
