﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Common.Core.API.Services;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services
{
    public interface IEmailNotificationQueueService
    {
        void AddNotificationQueue(EmailNotificationQueue notificationQueue);
        IList<EmailNotificationQueue> GetNotificationQueueEntries(int count);
    }
}
