﻿using Henkel.Business.Infrastructure.Model;
using Henkel.Business.Infrastructure.Services.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Business.Infrastructure.Services
{
    /// <summary>
    /// Email template service
    /// </summary>
    public partial interface IEmailTemplateService
    {
        /// <summary>
        /// Gets a email template by name
        /// </summary>
        /// <param name="EmailTemplateName">Email template name</param>
        /// <returns>Message template</returns>
        EmailTemplate GetEmailTemplateByName(string EmailTemplateName);

        /// <summary>
        /// Gets all email templates
        /// </summary>
        /// <returns>Email template list</returns>
        IList<EmailTemplate> GetAllEmailTemplates();
    }
}
