﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Model
{
    public class ScheduleJobConfigurationSection : ConfigurationSection
    {
        [ConfigurationProperty("ScheduleJobs", IsDefaultCollection = false)]
        [ConfigurationCollection(typeof(ScheduleJobCollection), AddItemName = "add")]
        public ScheduleJobCollection ScheduleJobs
        {
            get
            {
                return (ScheduleJobCollection)base["ScheduleJobs"];
            }
        }

        public static ScheduleJobConfigurationSection GetConfig()
        {
            return (ScheduleJobConfigurationSection)ConfigurationManager.GetSection("ScheduleJobSection") ?? new ScheduleJobConfigurationSection();
        }
    }
}
