﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Model
{
    public class ScheduleJobCollection : ConfigurationElementCollection
    {
        public ScheduleJobCollection()
        {

        }

        public ScheduleJob this[int index]
        {
            get { return (ScheduleJob)base.BaseGet(index); }
            set
            {
                if (base.BaseGet(index) != null)
                {
                    base.BaseRemoveAt(index);
                }
                this.BaseAdd(index, value);
            }
        }

        public void Add(ScheduleJob scheduleJob)
        {
            BaseAdd(scheduleJob);
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new ScheduleJob();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((ScheduleJob)element).Name;
        }
    }
}
