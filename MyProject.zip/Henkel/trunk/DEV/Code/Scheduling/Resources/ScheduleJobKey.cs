﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Resources
{
    public static class ScheduleJobKey
    {
        public const string Name = "name";
        public const string Group = "group";
        public const string CronExpression = "cronExpression";
        public const string JobType = "jobType";
        public const string CustomerId = "customerId";
        public const string Dependency = "dependency";
    }
}
