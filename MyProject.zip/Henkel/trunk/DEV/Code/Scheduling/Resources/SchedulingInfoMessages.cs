﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Resources
{
    public static class SchedulingInfoMessages
    {
        public const string InitializingScheduler = "Initializing Quartz Scheduler...";
        public const string SchedulerInitializationComplete = "Quartz Scheduler Initialization Complete. ";
        public const string StartingRegistrationForAllTasks = "Starting Registration for All Tasks...";
        public const string TotalTasksToRegisterGeneric1Args = "Total Tasks to Register: [{0}]";
        public const string RegisteringTaskGeneric2Args = " Registering Task[{0}]: [{1}]...";
        public const string CompletedRegisteringTaskGeneric2Args = " Completed Registering Task[{0}]: [{1}].";
        public const string RegistrationCompletedForAllTasks = "Registration Completed for All Tasks.";
        public const string TotalTaskRegisteredGeneric1Args = "Total Tasks Registered: [{0}]";
        public const string StopingScheduler = "Stoping Quartz Scheduler...";
        public const string SuccessfullyStopedScheduler = "Successfully Stopped Quartz Scheduler.";
        public const string StartExecutingMethodExecute = "Start Executing method: [Execute].";
        public const string FinishedExecutionOfMethodExecute = "Finished execution of method [Execute].";
        public const string NoCustomerConfiguredToExecuteThisJob = "No Customer configured to complete this Job. Exiting Job Execution.";
        public const string InvalidCustomerIdDefinedInConfigFileGeneric1Args = "Invalid CustomerId: [{0}] defined in Config file. Exiting Job Execution.";
        public const string DefinedCustomerIdNotPresentInDBGeneric1Args = "Defined CustomerId: [{0}] not present in DB. Exiting Job Execution.";
        public const string StartingExecutionJobForCustomerIdGeneric1Args = "Starting Execution Job for CustomerId: [{0}]";
    }
}
