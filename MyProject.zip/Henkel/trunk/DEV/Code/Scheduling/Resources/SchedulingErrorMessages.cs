﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Resources
{
    public static class SchedulingErrorMessages
    {
        public const string ErrorToCreateTypeObjectForTaskGeneric2Args = "Error occured to create Type object for Task: [{0}] and JobType: [{1}]";
        public const string FailedToRegisterTaskGeneric2Args = "Failed to register Task[{0}]: [{1}].";
        public const string ErrorOccuredToInitializeScheduler = "Error occured to Initialize Quartz Scheduler.";
        public const string ErrorOccuredInTaskRegistration = "Error occured in Task registration. Exiting without registration.";
        public const string ErrorOccuredInMethodExecute = "Error occured in method: [Execute].";
        public const string ErrorOccuredToExecuteJobForCustomerIdGeneric1Args = "Error occured to execute Job for CustomerId: [{0}]";
    }
}
