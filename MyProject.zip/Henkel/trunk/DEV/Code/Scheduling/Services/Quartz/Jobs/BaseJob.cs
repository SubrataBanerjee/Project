﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Model;
using Henkel.Common.Core.API.Repository.Transaction;
using Henkel.Common.Core.API.Utils;
using Henkel.Scheduler.Scheduling.Resources;
using Quartz;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Services.Quartz.Jobs
{
    public class BaseJob
    {
        #region Property fields

        public Guid CustomerId { get; protected set; }

        public IRepositorySessionFactory SessionFactory { get; set; }

        protected IRepositorySession RepositorySessionWithoutFilter
        {
            get
            {
                var session = SessionFactory.GetNewSession(true, false, null);
                return session;
            }
        }

        protected IRepositorySession RepositoryReadOnlySessionWithoutFilter
        {
            get
            {
                var session = SessionFactory.GetNewSession(false, false, null);
                return session;
            }
        }

        protected IRepositorySession RepositorySession
        {
            get
            {
                var session = SessionFactory.GetNewSession(true, true, CustomerId);
                return session;
            }
        }

        protected IRepositorySession RepositoryReadOnlySession
        {
            get
            {
                var session = SessionFactory.GetNewSession(false, true, CustomerId);
                return session;
            }
        }

        #endregion
        
        #region Constructor

        public BaseJob()
        {
            SessionFactory = ObjectLocator.GetObject<IRepositorySessionFactory>();
        }

        #endregion

        #region Protected Methods

        protected IList<CustomerAdminDetail> GetAllCustomers()
        {
            return CustomerAdminUtil.GetAllCustomerAdminDetails();
        }

        protected CustomerAdminDetail GetCustomer(Guid customerId)
        {
            return GetAllCustomers().FirstOrDefault(x => x.CustomerId == customerId);
        }

        protected IEnumerable<Guid> GetDependentExtensionIds(IJobExecutionContext context)
        {
            var s = context.JobDetail.JobDataMap.Get(ScheduleJobKey.Dependency);
            var dependency = s == null ? string.Empty : s.ToString();
            return string.IsNullOrWhiteSpace(dependency)
                ? new List<Guid>()
                : dependency.Split(new[] { "|" }, StringSplitOptions.RemoveEmptyEntries).Select(x => new Guid(x)).ToList();
        }


        #endregion

        #region Public Methods

        public void SetThreadData()
        {
            ThreadUtils.SetThreadData(CustomerId, userName: "Scheduler-System");
        }

        public static bool IsAllowedExecution(long counter)
        {
            try
            {
                if (counter <= 1)
                    return true;

                string value = ConfigurationManager.AppSettings["ExecuteOnce"];
                if (string.IsNullOrWhiteSpace(value))
                    return true;

                return !Convert.ToBoolean(value);
            }
            catch (Exception)
            {
                return true;
            }
        }

        #endregion
    }
}
