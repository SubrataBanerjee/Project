﻿using Henkel.Common.Core.API.Model;
using Quartz;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Common.Core.API.Utils;
using Henkel.Scheduler.Scheduling.Resources;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Common.Core.API.Locator;
using Henkel.Business.Infrastructure.API.Services;

namespace Henkel.Scheduler.Scheduling.Services.Quartz.Jobs
{
    public class EmailDispatchingJob : BaseJob, IJob
    {
        #region fields

        static long _counter;

        #endregion

        #region Constructors

        //NOTE: Don't remove this constructor as this has been Invoked through Quartz Job Scheduler 
        public EmailDispatchingJob()
        {
            _counter += 1;
        }

        #endregion

        #region Implementation of IJob

        public void Execute(IJobExecutionContext context)
        {
            var typeName = GetType().Name;
            Logger.Info(typeName, SchedulingInfoMessages.StartExecutingMethodExecute);

            try
            {
                IList<CustomerAdminDetail> customerAdminDetails;
                var customerIdObj = context.JobDetail.JobDataMap.Get(ScheduleJobKey.CustomerId);
                if (customerIdObj == null || string.IsNullOrWhiteSpace(customerIdObj.ToString()))
                {
                    customerAdminDetails = GetAllCustomers();
                    if (customerAdminDetails.Count == 0)
                    {
                        Logger.Warning(typeName, SchedulingInfoMessages.NoCustomerConfiguredToExecuteThisJob);
                        return;
                    }
                }
                else
                {
                    var customerIdStr = customerIdObj.ToString();
                    if (!customerIdStr.IsGuid())
                    {
                        Logger.Error(typeName, SchedulingInfoMessages.InvalidCustomerIdDefinedInConfigFileGeneric1Args, customerIdStr);
                        return;
                    }
                    var customerAdminDetail = GetCustomer(new Guid(customerIdStr));
                    if (customerAdminDetail == null)
                    {
                        Logger.Error(typeName, SchedulingInfoMessages.DefinedCustomerIdNotPresentInDBGeneric1Args, customerIdStr);
                        return;
                    }

                    customerAdminDetails = new List<CustomerAdminDetail> { customerAdminDetail };
                }

                var emailDispatchingService = ObjectLocator.GetObject<IEmailDispatchingService>();

                foreach(var customerAdminDetail in customerAdminDetails)
                {
                    //Must set CustomerId first as this has been used in every Repository session
                    CustomerId = customerAdminDetail.CustomerId;
                    SetThreadData();
                    Logger.Info(typeName, SchedulingInfoMessages.StartingExecutionJobForCustomerIdGeneric1Args, customerAdminDetail.CustomerId);
                    
                    using(var session = RepositorySession)
                    {
                        try
                        {
                            emailDispatchingService.DispatchQueuedEmail();
                        }
                        catch(Exception ex)
                        {
                            session.Rollback();
                            Logger.Exception(typeName, OperationStatus.CreateFromException(string.Format(SchedulingErrorMessages.ErrorOccuredToExecuteJobForCustomerIdGeneric1Args, customerAdminDetail.CustomerId),ex));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.Exception(typeName, OperationStatus.CreateFromException(SchedulingErrorMessages.ErrorOccuredInMethodExecute, ex));
            }

            Logger.Info(typeName, SchedulingInfoMessages.FinishedExecutionOfMethodExecute);
        }

        #endregion
    }
}
