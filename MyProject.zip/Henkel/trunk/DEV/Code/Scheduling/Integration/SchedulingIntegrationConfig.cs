﻿using Microsoft.Practices.Unity;
using Henkel.Common.Core.API.Integration.Services.Impl;
using Henkel.Scheduler.Scheduling.Services.Quartz;
using Henkel.Scheduler.Scheduling.Services.Quartz.Impl;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Henkel.Scheduler.Scheduling.Services;

namespace Henkel.Scheduler.Scheduling.Integration
{
    public class SchedulingIntegrationConfig : IntegrationConfigBase
    {
        public override void RegisterTypes(IUnityContainer container)
        {
            RegisterServices(container);
        }

        private void RegisterServices(IUnityContainer container)
        {
            container.RegisterType<ISchedulingService, QuartzSchedulingService>(new ContainerControlledLifetimeManager());
        }
    }
}
