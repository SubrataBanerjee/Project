﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration.Install;
using System.Linq;
using System.ServiceProcess;
using System.Threading.Tasks;

namespace Henkel.Scheduler.Scheduling.Server
{
    [RunInstaller(true)]
    public partial class ProjectInstaller : Installer
    {
        public ProjectInstaller()
        {
            InitializeComponent();
        }

        private void SetServicePropertiesFromCommandLine(ServiceInstaller serviceInstaller)
        {
            string[] commandlineArgs = Environment.GetCommandLineArgs();
            string servicename = ParseServiceNameSwitches(commandlineArgs);

            serviceInstaller.ServiceName = servicename;
            serviceInstaller.DisplayName = servicename;
        }

        private string ParseServiceNameSwitches(IEnumerable<string> commandlineArgs)
        {
            const string serviceName = "/servicename";
            var servicenameswitch = (from s in commandlineArgs where s.StartsWith(serviceName) select s).FirstOrDefault();

            if (servicenameswitch == null)
                return "Henkel-Scheduler";
            if (!(servicenameswitch.Contains('=') || servicenameswitch.Split('=').Length < 2))
                throw new ArgumentNullException(string.Format("The {0} switch is malformed", serviceName));

            return (servicenameswitch.Split('=')[1]).Trim('"');
        }
    }
}
