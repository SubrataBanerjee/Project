﻿using Henkel.Common.Core.API.Locator;
using Henkel.Common.Core.API.Logging.Model;
using Henkel.Scheduler.Scheduling.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace Henkel.Scheduler.Scheduling.Server
{
    public partial class SchedulingService : ServiceBase
    {
        #region Fields

        //private static readonly log4net.ILog log = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        private ISchedulingService _quartzSchedulingService;

        private static bool _executedOnce;
        readonly Timer _timer = new Timer();

        #endregion


        #region Constructors

        public SchedulingService()
        {
            InitializeComponent();
        }

        #endregion

        #region Implementation of ServiceBase class

        protected override void OnStart(string[] args)
        {
            _timer.AutoReset = true;
            _timer.Interval = 2000;
            _timer.Elapsed += timer_Elapsed;
            _timer.Start();
        }

        protected override void OnStop()
        {
            if (_quartzSchedulingService != null)
                _quartzSchedulingService.Stop();
        }

        #endregion


        #region Helper Methods

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (_executedOnce)
                return;

            _executedOnce = true;

            try
            {
                _quartzSchedulingService = ObjectLocator.GetService<ISchedulingService>();
                _quartzSchedulingService.Start();
            }
            catch (Exception ex)
            {
                Logger.Error(GetType().Name,ex.Message);
                if (ex.InnerException != null)
                    Logger.Error(GetType().Name, ex.InnerException.Message);
                Logger.Error(GetType().Name, ex.StackTrace);
            }
        }

        #endregion
    }
}
